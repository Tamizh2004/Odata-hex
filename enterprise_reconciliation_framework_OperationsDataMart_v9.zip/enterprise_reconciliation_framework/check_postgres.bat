@echo off
setlocal
cd /d "%~dp0"
if not defined ERF_VENV_DIR set "ERF_VENV_DIR=C:\.erf_venv"
if not exist "%ERF_VENV_DIR%\Scripts\python.exe" (
  echo Python environment not found. Run setup_and_run.bat first.
  pause
  exit /b 1
)
"%ERF_VENV_DIR%\Scripts\python.exe" check_postgres.py
pause
