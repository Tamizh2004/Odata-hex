@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Enterprise Streamlit Data Reconciliation Framework
if not defined ERF_VENV_DIR set "ERF_VENV_DIR=C:\.erf_venv"
echo ============================================================
echo   Enterprise Streamlit Data Reconciliation Framework
echo ============================================================
echo.
py -3 --version >nul 2>&1
if errorlevel 1 (echo ERROR: Python 3 not found.&pause&exit /b 1)
echo [1/3] Using short Python environment: %ERF_VENV_DIR%
if not exist "%ERF_VENV_DIR%\Scripts\python.exe" py -3 -m venv "%ERF_VENV_DIR%"
if not exist "%ERF_VENV_DIR%\Scripts\python.exe" (echo ERROR: Could not create environment.&pause&exit /b 1)
echo [2/3] Installing/checking dependencies...
"%ERF_VENV_DIR%\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (echo.&echo ERROR: Dependency installation failed.&pause&exit /b 1)
echo [3/3] Starting Streamlit...
echo Keep the external AWS SSM tunnel running.
echo This app does not request or store AWS credentials.
echo.
"%ERF_VENV_DIR%\Scripts\python.exe" -m streamlit run app\app.py
pause
