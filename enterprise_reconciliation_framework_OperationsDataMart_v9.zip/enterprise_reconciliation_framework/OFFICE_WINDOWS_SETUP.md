# Windows / Office Laptop Setup

The launcher intentionally keeps the Python virtual environment outside the project at `C:\.erf_venv` (without the space; the actual path is `C:\.erf_venv`). This prevents Windows `WinError 206` caused by deeply nested Streamlit package paths.

Double-click `setup_and_run.bat`. No VS Code is required.

If `C:\` is restricted, set `ERF_VENV_DIR` to a short approved path before launching.

AWS/SSM remains external. The app does not request or store AWS credentials.
