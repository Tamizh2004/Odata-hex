from pathlib import Path
import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / '.env')

cfg = {
    'host': os.getenv('ERF_PG_HOST', 'localhost'),
    'port': int(os.getenv('ERF_PG_PORT', '5434')),
    'database': os.getenv('ERF_PG_DATABASE', 'OperationsDataMart'),
    'username': os.getenv('ERF_PG_USER', 'dbadmin'),
    'password': os.getenv('ERF_PG_PASSWORD', ''),
}

print(f"Target: {cfg['host']}:{cfg['port']} / {cfg['database']} / {cfg['username']}")
if not cfg['password']:
    raise SystemExit('ERROR: ERF_PG_PASSWORD is empty in .env')

url = URL.create('postgresql+psycopg2', username=cfg['username'], password=cfg['password'],
                 host=cfg['host'], port=cfg['port'], database=cfg['database'])
engine = create_engine(url, connect_args={'connect_timeout': 5})

try:
    with engine.connect() as con:
        row = con.execute(text('SELECT current_database(), current_user, version()')).one()
        print('CONNECTED:')
        print('  database:', row[0])
        print('  user:', row[1])
        print('  server:', row[2].split(',')[0])
        schemas = con.execute(text("""
            SELECT nspname FROM pg_namespace
            WHERE nspname NOT IN ('pg_catalog','information_schema')
              AND nspname NOT LIKE 'pg_toast%'
              AND nspname NOT LIKE 'pg_temp_%'
            ORDER BY CASE WHEN nspname='public' THEN 0 ELSE 1 END, nspname
        """)).scalars().all()
        print('USER SCHEMAS:', ', '.join(schemas) if schemas else '(none)')
        for schema in schemas:
            tables = con.execute(text("""
                SELECT c.relname
                FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
                WHERE n.nspname=:s AND c.relkind='r' AND NOT c.relispartition
                ORDER BY c.relname
            """), {'s': schema}).scalars().all()
            if tables:
                print(f'  {schema}: {len(tables)} table(s)')
                print('    ' + ', '.join(tables[:25]) + (' ...' if len(tables) > 25 else ''))
except Exception as exc:
    print('CONNECTION FAILED:')
    print(str(exc))
    raise SystemExit(1)
