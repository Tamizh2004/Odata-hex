# Enterprise Data Reconciliation & Automation Framework — OperationsDataMart

This build is focused on the PostgreSQL connection shown in DBeaver:

- Host: `localhost`
- Port: `5434`
- Database: `OperationsDataMart`
- User: `dbadmin`
- Password: stored locally in `.env` and never rendered in the UI

## What was fixed in this build

### PostgreSQL / connection
- One shared SQLAlchemy engine is reused by Dashboard, Connection Status, Database Explorer, Table Data Explorer and all reconciliation pages.
- No duplicate authentication attempt is made when navigating between pages.
- SQLAlchemy `URL.create()` is used so passwords containing special characters are handled safely.
- A fast TCP probe checks `localhost:5434` before authentication.
- The UI never displays or logs the password.

### Database Explorer
- The active database is the actual `OperationsDataMart` database.
- `information_schema`, `pg_catalog`, temporary schemas and TOAST schemas are hidden.
- `public` is preferred automatically when it exists.
- Every user schema is listed with table/view counts.
- Tables are read directly from PostgreSQL system catalogs.
- Selecting a table sets the target for the rest of the workflow.
- Switching databases is supported explicitly instead of pretending that changing a dropdown changes the live connection.

### Table Data Explorer
- Shows row count, column count, primary keys and indexes.
- Shows column metadata before the data.
- Uses stable ordering by primary key when available.
- Provides pagination and CSV/Excel/JSON exports.

### Auto Table Prediction
- Scans all non-system schemas, not just `information_schema`.
- Uses a single metadata query for speed.
- Scores exact column-name matches strongly and adds fuzzy matching.
- Shows schema, table, confidence, exact matches, matching columns and primary key.
- Allows the top suggestion to be selected directly.

### Reconciliation workflow
Upload → Profile → Predict → Select Table → Column Mapping → Compare → Differences → Recommendations → SQL Review → Approval → Transactional Execution → Audit/Reports.

## Start

1. Start the external AWS SSM/local tunnel.
2. Run `setup_and_run.bat`.
3. The application automatically connects to `OperationsDataMart`.
4. Open **Database Explorer**. User schemas should appear, with `public` preferred when present.
5. Select a real user table, then open **Table Data Explorer**.
6. Upload your source file and use **Auto Table Prediction**.

## Connection diagnostic

If anything looks wrong, run `check_postgres.bat`. It prints the connected database/user and lists user schemas and tables without printing the password.

## Security

The included `.env` contains a database credential supplied for this local test build. Do not commit `.env` to GitHub or upload it publicly. Rotate the database password after testing if the credential has been exposed.

AWS/SSM credentials are intentionally not stored in this application.
