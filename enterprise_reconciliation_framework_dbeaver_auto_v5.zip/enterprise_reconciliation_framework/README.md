# Enterprise Streamlit Data Reconciliation & Data Management Framework

## Architecture

External PowerShell/AWS SSM
        |
        v
Local TCP PostgreSQL tunnel
        |
        v
Streamlit auto-discovery
        |
        v
PostgreSQL
        |
        +--> Database Explorer
        +--> Table Browser
        +--> File Upload
        +--> Profiling
        +--> Table Prediction
        +--> Column Mapping
        +--> Reconciliation
        +--> Difference Viewer
        +--> Recommendations
        +--> SQL Generator
        +--> Approval
        +--> Transactional Execution
        +--> Audit
        +--> Reports

The application does NOT request, store, or manage AWS credentials, bastion
IDs, AWS region, or remote RDS endpoint. AWS SSM remains an external concern.

It does NOT assume localhost:13391. It probes configured local ports and
allows you to add any local tunnel port through .env.

## Start

Double-click:

    setup_and_run.bat

After first setup, use the same file every time. VS Code is not required.

## PostgreSQL authentication

The app automatically reads **non-secret** PostgreSQL connection metadata from
DBeaver's `data-sources.json` when available. This includes host, port, database
and username. For the shown DBeaver connection this means the app can discover
`localhost:13391`, database `postgres`, and the configured PostgreSQL username
without asking you to type them.

DBeaver stores saved passwords separately in encrypted secure storage. The app
**does not decrypt or copy that password**. PostgreSQL password authentication
still requires a legitimate libpq credential source such as `PGPASSWORD`,
`PGPASSFILE`/`.pgpass` (Windows commonly `pgpass.conf`), `PGSERVICE`, or an
allowed server-side passwordless authentication rule.

When the Dashboard establishes a working PostgreSQL connection, that same
SQLAlchemy engine is reused by Connection Status and the rest of the app.
Opening Connection Status does not perform a second authentication attempt.

## Workflow

1. Start external SSM tunnel in PowerShell.
2. Double-click setup_and_run.bat.
3. Connection Status -> Refresh Detection.
4. Select any detected local PostgreSQL endpoint.
5. Connect.
6. Database Explorer -> schema -> table.
7. File Upload -> CSV/Excel/Parquet/JSON.
8. Data Profiling.
9. Auto Table Prediction.
10. Column Mapping.
11. CSV <-> PostgreSQL Comparison.
12. Difference Viewer / AI Recommendations.
13. Query Generator.
14. Approval Center: type APPROVE.
15. Execution Center.
16. Reports / Audit / Rollback.

## Security

Never place AWS access keys, secret keys or session tokens in this project.
If temporary AWS credentials were exposed publicly or to an unintended party,
revoke/rotate them.


## Automatic Local PostgreSQL Connection

The application now detects local TCP listeners and automatically attempts PostgreSQL authentication. The Connection Status page no longer asks for username, password, database, or SSL mode. It uses the existing PostgreSQL/libpq authentication available to the process, then displays the connected database and available databases. AWS/SSM remains external to the application.
