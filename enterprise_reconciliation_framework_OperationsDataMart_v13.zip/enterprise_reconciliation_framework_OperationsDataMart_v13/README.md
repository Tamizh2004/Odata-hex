# Enterprise Data Reconciliation & Automation Framework — OperationsDataMart

This build is focused on the PostgreSQL connection shown in DBeaver:

- Host: `localhost`
- Port: `5434`
- Database: `OperationsDataMart`
- User: `dbadmin`
- Password: stored locally in `.env` and never rendered in the UI

## What was fixed in this build

### PostgreSQL / connection
- One shared SQLAlchemy engine is reused by Dashboard, Connection Status, Database Explorer, Table Data Explorer and all reconciliation pages.
- No duplicate authentication attempt is made when navigating between pages.
- SQLAlchemy `URL.create()` is used so passwords containing special characters are handled safely.
- A fast TCP probe checks `localhost:5434` before authentication.
- The UI never displays or logs the password.

### Database Explorer
- The active database is the actual `OperationsDataMart` database.
- `information_schema`, `pg_catalog`, temporary schemas and TOAST schemas are hidden.
- `public` is preferred automatically when it exists.
- Every user schema is listed with table/view counts.
- Tables are read directly from PostgreSQL system catalogs.
- Selecting a table sets the target for the rest of the workflow.
- Switching databases is supported explicitly instead of pretending that changing a dropdown changes the live connection.

### Table Data Explorer
- Shows row count, column count, primary keys and indexes.
- Shows column metadata before the data.
- Uses stable ordering by primary key when available.
- Provides pagination and CSV/Excel/JSON exports.

### Auto Table Prediction
- Scans all non-system schemas, not just `information_schema`.
- Uses a single metadata query for speed.
- Scores exact column-name matches strongly and adds fuzzy matching.
- Shows schema, table, confidence, exact matches, matching columns and primary key.
- Allows the top suggestion to be selected directly.

### Reconciliation workflow
Upload → Profile → Predict → Select Table → Column Mapping → Compare → Differences → Recommendations → SQL Review → Approval → Transactional Execution → Audit/Reports.

## Start

1. Start the external AWS SSM/local tunnel.
2. Run `setup_and_run.bat`.
3. The application automatically connects to `OperationsDataMart`.
4. Open **Database Explorer**. User schemas should appear, with `public` preferred when present.
5. Select a real user table, then open **Table Data Explorer**.
6. Upload your source file and use **Auto Table Prediction**.

## Connection diagnostic

If anything looks wrong, run `check_postgres.bat`. It prints the connected database/user and lists user schemas and tables without printing the password.

## Security

The included `.env` contains a database credential supplied for this local test build. Do not commit `.env` to GitHub or upload it publicly. Rotate the database password after testing if the credential has been exposed.

AWS/SSM credentials are intentionally not stored in this application.

## v10 fixes in this build

### Excel export fix
- Excel export now strips timezone information from `datetime` / `pandas.Timestamp` values before writing XLSX.
- Handles timezone-aware values inside object columns as well.
- Adds freeze panes, filters and sensible column widths.
- This fixes `ValueError: Excel does not support datetimes with timezones`.

### Auto Table Prediction fix
- Prediction remains metadata-only and fast; it does not scan full table data.
- Exact column matches, one-to-one fuzzy matches, primary-key matches and filename/table-name similarity are scored.
- Duplicate fuzzy matches cannot inflate the score.
- The UI now lets you choose any returned candidate instead of silently forcing the first row.
- Matching and unmatched source-column counts are displayed so a `0`/low score is explainable.

### CSV → Parquet → PostgreSQL validation fix
- Validates CSV/Parquet round-trip row count and column order.
- Validates that mapped target columns actually exist in the selected PostgreSQL table.
- Checks PostgreSQL mapped-column null counts without loading the entire target table into memory.
- No full-table read is performed for this validation page.

### Reconciliation comparison fix
- Timestamp comparisons normalize timezone-aware values to UTC-naive values before equality checks.
- Pandas/numpy scalar values are normalized safely.
- Null handling is explicit, reducing false differences between CSV and PostgreSQL timestamp fields.

The existing PostgreSQL connection, database explorer, table explorer and live table-data workflow are intentionally preserved.


## v13 multi-million-row reconciliation

This version adds an adaptive comparison path for very large PostgreSQL tables.

- Tables with **1,000,000+ rows** automatically use database-side reconciliation.
- The mapped source is copied once into a PostgreSQL temporary staging table.
- PostgreSQL performs the key joins and full-table INSERT/UPDATE/DELETE counts inside the database.
- No `LIMIT/OFFSET` pagination is used for the multi-million-row path.
- The temporary source table is analyzed before joins so PostgreSQL has useful cardinality statistics.
- Only a bounded sample of detailed differences (default 10,000) is returned to Streamlit; the reconciliation counts are calculated across the full table.
- Multiple uploaded source files are still combined before reconciliation.
- Smaller tables retain the existing retryable keyset-pagination workflow.
- The working connection, Database Explorer and Table Data Explorer are unchanged.

For a table such as `CustomerProfile.LoyaltyProfile` containing about **4,722,752 rows**, the application automatically selects the database-side path. Keep the SSM/SSH tunnel open for the duration of the source staging and database comparison.
