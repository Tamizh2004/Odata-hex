@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul || (echo Python is required. & pause & exit /b 1)
if not exist .venv py -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
