from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable
import json
import pandas as pd

DEFAULT_IGNORE_COLUMNS = {"_source_file", "_source_row", "action", "rpg", "Hierarchy", "hierarchy"}


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    if path.suffix.lower() in {".csv", ".txt"}:
        return pd.read_csv(path, low_memory=False)
    raise ValueError(f"Unsupported file type: {path.name}. Use CSV or Parquet.")


def write_parquet(df: pd.DataFrame, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)


def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    return out


def norm(v) -> str:
    if pd.isna(v):
        return "<NULL>"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    s = str(v).strip()
    # Treat numeric IDs read as 123.0 as 123.
    if s.endswith(".0"):
        try:
            return str(int(float(s)))
        except Exception:
            pass
    return s


def make_key(df: pd.DataFrame, key_columns: list[str]) -> pd.Series:
    missing = [c for c in key_columns if c not in df.columns]
    if missing:
        raise ValueError(f"Key columns missing from file: {', '.join(missing)}")
    return df[key_columns].map(norm).astype(str).agg("||".join, axis=1)


def compare_tables(
    ifly: pd.DataFrame,
    odh: pd.DataFrame,
    key_columns: list[str],
    event_type: str = "RECONCILIATION",
    compare_columns: Iterable[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ifly = clean_columns(ifly)
    odh = clean_columns(odh)
    if not key_columns:
        raise ValueError("At least one match-key column is required.")

    ifly["__recon_key"] = make_key(ifly, key_columns)
    odh["__recon_key"] = make_key(odh, key_columns)

    if ifly["__recon_key"].duplicated().any():
        raise ValueError("Step 1 still has duplicate rows for the selected match key. Add another identifying column.")
    if odh["__recon_key"].duplicated().any():
        raise ValueError("Step 3 still has duplicate rows for the selected match key. Add another identifying column.")

    if compare_columns is None:
        compare_columns = [c for c in ifly.columns if c in odh.columns and c not in set(key_columns) and c != "__recon_key" and c not in DEFAULT_IGNORE_COLUMNS]
    compare_columns = list(compare_columns)
    if not compare_columns:
        raise ValueError("No common non-key columns are available for comparison.")

    i = ifly.set_index("__recon_key", drop=False)
    o = odh.set_index("__recon_key", drop=False)
    common = i.index.intersection(o.index)
    only_i = i.index.difference(o.index)
    only_o = o.index.difference(i.index)

    detail_rows = []
    change_rows = []
    mismatch_by_field = {c: 0 for c in compare_columns}
    null_odh = {c: 0 for c in compare_columns}
    null_ifly = {c: 0 for c in compare_columns}

    for k in common:
        mismatches = []
        for c in compare_columns:
            iv, ov = i.at[k, c], o.at[k, c]
            if pd.isna(ov): null_odh[c] += 1
            if pd.isna(iv): null_ifly[c] += 1
            if norm(iv) != norm(ov):
                mismatch_by_field[c] += 1
                mismatches.append(c)
        row = {"ChangeType": "UPDATE" if mismatches else "MATCH"}
        for c in key_columns:
            row[c] = i.at[k, c]
        for c in compare_columns:
            row[f"{c}_ODH"] = o.at[k, c]
            row[c] = i.at[k, c]
        row["MismatchedFields"] = ", ".join(mismatches)
        change_rows.append(row)

    for k in only_i:
        row = {"ChangeType": "INSERT"}
        for c in key_columns:
            row[c] = i.at[k, c]
        for c in compare_columns:
            row[f"{c}_ODH"] = pd.NA
            row[c] = i.at[k, c]
        row["MismatchedFields"] = ""
        change_rows.append(row)

    for k in only_o:
        row = {"ChangeType": "DELETE"}
        for c in key_columns:
            row[c] = o.at[k, c]
        for c in compare_columns:
            row[f"{c}_ODH"] = o.at[k, c]
            row[c] = pd.NA
        row["MismatchedFields"] = ""
        change_rows.append(row)

    for c in compare_columns:
        count = mismatch_by_field[c]
        detail_rows.append({
            "EventType": event_type,
            "FieldName": c,
            "MismatchCount": count,
            "MismatchPercentage": round((count / max(len(common), 1)) * 100, 2),
            "ODH_NullCount": null_odh[c],
            "iFly_NullCount": null_ifly[c],
            "ImpactRank": None,
        })

    detail = pd.DataFrame(detail_rows)
    if not detail.empty:
        ranked = detail["MismatchCount"].rank(method="min", ascending=False)
        detail.loc[detail["MismatchCount"] > 0, "ImpactRank"] = ranked[detail["MismatchCount"] > 0]
        detail["ImpactRank"] = detail["ImpactRank"].astype("Int64")
        detail = detail.sort_values(["MismatchCount", "FieldName"], ascending=[False, True]).reset_index(drop=True)

    matched_count = sum(r["ChangeType"] == "MATCH" for r in change_rows)
    update_count = sum(r["ChangeType"] == "UPDATE" for r in change_rows)
    top = detail.iloc[0] if not detail.empty else None
    summary = pd.DataFrame([{
        "EventType": event_type,
        "TotalRecords": len(odh),
        "MatchedRecords": matched_count,
        "MismatchedRecords": update_count,
        "MissingInODH": len(only_i),
        "MissingInIFly": len(only_o),
        "TopAffectedField": top["FieldName"] if top is not None and top["MismatchCount"] > 0 else "",
        "TopAffectedFieldMismatchPercentage": float(top["MismatchPercentage"]) if top is not None and top["MismatchCount"] > 0 else 0.0,
        "RunTimestamp": datetime.now().isoformat(timespec="seconds"),
    }])

    changes = pd.DataFrame(change_rows)
    return summary, detail, changes


def run_reconciliation(
    step1_path: str | Path,
    step3_path: str | Path,
    output_dir: str | Path,
    key_columns: list[str],
    event_type: str = "RECONCILIATION",
) -> dict[str, Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ifly = clean_columns(read_table(step1_path))
    odh = clean_columns(read_table(step3_path))

    # Persist the normalized source data as the Step 1 / Step 3 parquet stage.
    step1_parquet = output_dir / "step1_ifly.parquet"
    step3_parquet = output_dir / "step3_odh.parquet"
    write_parquet(ifly, step1_parquet)
    write_parquet(odh, step3_parquet)

    summary, detail, changes = compare_tables(ifly, odh, key_columns=key_columns, event_type=event_type)
    step4_summary = output_dir / "step4_recon_stats_summary.csv"
    step4_detail = output_dir / "step4_recon_detailed_results.csv"
    step5 = output_dir / "step5_match_missed_odh_report.csv"

    summary.to_csv(step4_summary, index=False)
    detail.to_csv(step4_detail, index=False)
    changes.to_csv(step5, index=False)

    # A filtered file is useful for automations that only need actual changes.
    changed = changes[changes["ChangeType"] != "MATCH"].copy()
    step5_changes = output_dir / "step5_odh_changes_only.csv"
    changed.to_csv(step5_changes, index=False)

    return {
        "step1_parquet": step1_parquet,
        "step3_parquet": step3_parquet,
        "step4_summary": step4_summary,
        "step4_detail": step4_detail,
        "step5_match_missed": step5,
        "step5_changes_only": step5_changes,
    }
