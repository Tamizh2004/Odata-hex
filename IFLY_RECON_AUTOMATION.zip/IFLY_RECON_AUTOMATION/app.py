from pathlib import Path
import tempfile
import zipfile
import streamlit as st
from reconcile import read_table, run_reconciliation

st.set_page_config(page_title="iFly ODH Reconciliation", page_icon="🔎", layout="centered")

st.title("iFly → ODH Reconciliation")
st.caption("Minimal automation: Step 1 + Step 3 → Step 4 reports + Step 5 ODH result")

step1 = st.file_uploader("Step 1 — iFly file", type=["csv", "parquet"])
step3 = st.file_uploader("Step 3 — ODH file", type=["csv", "parquet"])

if step1 and step3:
    with tempfile.TemporaryDirectory() as td:
        p1 = Path(td) / step1.name
        p3 = Path(td) / step3.name
        p1.write_bytes(step1.getbuffer())
        p3.write_bytes(step3.getbuffer())
        try:
            d1 = read_table(p1)
            d3 = read_table(p3)
        except Exception as e:
            st.error(f"Could not read the uploaded files: {e}")
            st.stop()

        keys = [c for c in d1.columns if c in d3.columns]
        default_keys = [c for c in ["membershipNumber", "uniqueAccountID", "cardType", "cardHolderType", "updateTime"] if c in keys]
        if not default_keys and keys:
            default_keys = [keys[0]]
        key_columns = st.multiselect("Match key", keys, default=default_keys, disabled=not keys)
        event_type = st.text_input("Event type", value=Path(step1.name).stem.split()[0].upper() or "RECONCILIATION")

        if not keys:
            st.error("No common column exists between Step 1 and Step 3.")
            st.stop()
        if not key_columns:
            st.warning("Select at least one match-key column.")
            st.stop()

        if st.button("Run reconciliation", type="primary", use_container_width=True):
            out = Path(td) / "output"
            try:
                files = run_reconciliation(p1, p3, out, key_columns=key_columns, event_type=event_type)
                summary = __import__("pandas").read_csv(files["step4_summary"])
                st.success("Reconciliation completed.")
                st.dataframe(summary, use_container_width=True, hide_index=True)

                bundle = Path(td) / "iFly_ODH_reconciliation_results.zip"
                with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as z:
                    for f in out.iterdir():
                        z.write(f, arcname=f.name)
                st.download_button("Download all results", bundle.read_bytes(), bundle.name, "application/zip", use_container_width=True)
            except Exception as e:
                st.error(str(e))
else:
    st.info("Upload the Step 1 iFly file and Step 3 ODH file to begin.")
