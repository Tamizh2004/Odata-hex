# iFly ODH Reconciliation Automation

Minimal Streamlit automation built from the supplied sample files.

## Flow

1. Upload **Step 1 — iFly** CSV/Parquet.
2. Upload **Step 3 — ODH** CSV/Parquet.
3. Select the matching key. `membershipNumber + uniqueAccountID + cardType + cardHolderType + updateTime` is selected automatically because the supplied sample contains repeated `uniqueAccountID` values.
4. The app writes normalized Step 1 and Step 3 Parquet stages.
5. Step 1 and Step 3 are compared.
6. **Step 4** files are generated:
   - `step4_recon_stats_summary.csv`
   - `step4_recon_detailed_results.csv`
7. **Step 5** files are generated:
   - `step5_match_missed_odh_report.csv` — MATCH / UPDATE / INSERT / DELETE
   - `step5_odh_changes_only.csv` — only actual ODH changes/misses

### Change meanings

- `MATCH`: key exists in both and all compared fields match.
- `UPDATE`: key exists in both but one or more fields differ.
- `INSERT`: present in iFly/Step 1 but missing in ODH/Step 3.
- `DELETE`: present in ODH/Step 3 but missing in iFly/Step 1.

## Run

### Windows

Double-click `setup_and_run.bat` or run `setup_and_run.ps1`.

### Linux/macOS

Run `./setup_and_run.sh`.

The setup script creates a local virtual environment, installs the required packages, and starts Streamlit.

## Intentionally excluded

No database connection, login, scheduling, dashboards, charts, unrelated Step 2 processing, or unnecessary configuration is included. The default comparison ignores technical/source fields `action`, `rpg`, and `Hierarchy`; all other common non-key fields are compared, including `isLinked` automatically if it exists in both inputs. The framework focuses only on the supplied reconciliation flow.
