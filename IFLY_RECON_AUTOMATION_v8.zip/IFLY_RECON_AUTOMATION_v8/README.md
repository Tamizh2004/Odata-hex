# IFLY_RECON_AUTOMATION v8

Minimal Streamlit iFly → ODH reconciliation automation.

## Comparison flow
- Records are matched by the selected business key; default: membershipNumber + referenceNumber + ticketNumber when available.
- Duplicate business keys stop the run rather than producing false matches.
- Blank equivalence: None / pd.NA / NaN / NaT / empty / whitespace-only are all blank and compare equal to each other.
- Literal text NULL, NaN and NaT are real values and are not blank.
- Step 4 is the **value-only business reconciliation**.
- Step 5 produces two separate CSVs from the same matched records:
  1. `step5_value_only_comparison.csv` — compares the logical value without requiring the datatype to match.
  2. `step5_datatype_comparison.csv` — compares both the logical value and the logical datatype.
- In value-only mode, equivalent numeric/date representations can match (for example 453 and "453", or a date object and its ISO date text).
- In datatype-aware mode, non-blank datatype differences are mismatches (for example integer 453 vs string "453"). Blank representations remain equivalent.
- Strings are otherwise strict; no arbitrary trimming or NULL coercion.
- Same record + no field differences = MATCH.
- Same record + genuine field differences = UPDATE.
- iFly-only = INSERT (missing in ODH).
- ODH-only = DELETE (missing in iFly).
- All counts are whole numbers.

## Outputs
- step1_ifly.parquet
- step3_odh.parquet
- step4_recon_stats_summary.csv
- step4_recon_detailed_results.csv
- step5_value_only_comparison.csv
- step5_datatype_comparison.csv

Run with `setup_and_run.bat` on Windows.
