from __future__ import annotations

from datetime import datetime, date, time
from pathlib import Path
from typing import Iterable
import math
import re
import numbers
import pandas as pd

DEFAULT_KEY_CANDIDATES = [
    ["membershipNumber", "referenceNumber", "ticketNumber"],
    ["membershipNumber", "referenceNumber"],
    ["membershipNumber", "ticketNumber"],
    ["membershipNumber", "uniqueAccountID", "cardType", "cardHolderType", "updateTime"],
]
IGNORE_COLUMNS = {"_source_file", "_source_row", "action", "rpg", "Hierarchy", "hierarchy", "__recon_key"}


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path, engine="pyarrow")
    if path.suffix.lower() in {".csv", ".txt"}:
        # Keep literal NULL as text. Only actual empty cells are blank.
        return pd.read_csv(path, low_memory=False, keep_default_na=False, na_filter=False)
    raise ValueError(f"Unsupported file type: {path.name}. Use CSV or Parquet.")


def write_parquet(df: pd.DataFrame, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False, engine="pyarrow")


def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    return out


def is_blank(v) -> bool:
    """Return True only for genuine missing/blank values.

    Reconciliation rule:
      * None / pd.NA / NaN / NaT are blank.
      * Empty strings and whitespace-only strings are blank.
      * Literal text such as ``"NULL"``, ``"NaN"`` or ``"NaT"`` is NOT blank.
      * Strings containing a real value are never trimmed or normalized.
    """
    if v is None:
        return True

    # pd.isna() returns numpy.bool_ for scalars and can return an array for
    # list-like values.  Convert only scalar results safely; using
    # ``is True`` misses numpy.bool_(True), which was the source of the
    # earlier NaN/NaT comparison problem.
    try:
        missing = pd.isna(v)
        if isinstance(missing, bool):
            if missing:
                return True
        else:
            try:
                if bool(missing):
                    return True
            except (TypeError, ValueError):
                pass
    except (TypeError, ValueError):
        pass

    return isinstance(v, str) and v.strip() == ""


def scalar_text(v) -> str:
    """Exact-ish representation for keys; does not trim real strings."""
    if is_blank(v):
        return "<BLANK>"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if math.isfinite(v) and v.is_integer():
            return str(int(v))
        return repr(v)
    return str(v)


def _is_number(v) -> bool:
    return isinstance(v, numbers.Number) and not isinstance(v, (bool, complex))


def _canonical_numeric_text(v) -> str | None:
    """Return a canonical numeric string only for unambiguous integer/decimal text.

    Leading-zero identifiers are deliberately not converted (except the literal 0),
    so identifiers such as 00123 do not silently become 123.
    """
    if not isinstance(v, str) or v == "" or v != v.strip():
        return None
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d+)?|\.\d+)", v):
        return None
    unsigned = v.lstrip("+-")
    if unsigned.isdigit() and len(unsigned) > 1 and unsigned.startswith("0"):
        return None
    try:
        n = float(v)
        if math.isfinite(n):
            return format(n, ".15g")
    except ValueError:
        return None
    return None


def _temporal_value(v):
    """Return a comparable ISO temporal value for actual temporal values or ISO text.

    We only parse exact ISO-style date/datetime strings. We do not strip arbitrary
    strings, preserving the rule that meaningful spaces remain significant.
    """
    if isinstance(v, pd.Timestamp):
        if pd.isna(v):
            return None
        return ("datetime", v.to_pydatetime().replace(tzinfo=None).isoformat())
    if isinstance(v, datetime):
        return ("datetime", v.replace(tzinfo=None).isoformat())
    if isinstance(v, date) and not isinstance(v, datetime):
        return ("date", v.isoformat())
    if isinstance(v, time):
        return ("time", v.replace(tzinfo=None).isoformat())
    if isinstance(v, str):
        # Do not strip: surrounding whitespace is significant for real strings.
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
            try:
                return ("date", pd.Timestamp(v).date().isoformat())
            except Exception:
                return None
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?", v):
            try:
                ts = pd.Timestamp(v)
                return ("datetime", ts.to_pydatetime().replace(tzinfo=None).isoformat())
            except Exception:
                return None
    return None


def values_equal(a, b) -> bool:
    """Compare two field values logically while preserving meaningful data.

    Blank equivalence is the only broad normalization:
      None / pd.NA / NaN / NaT / empty / whitespace-only are equal to each other.
    Literal NULL/NaN/NaT strings are values, not blanks.

    Beyond blanks, values are compared by semantic scalar type so that Parquet
    schema differences do not create false mismatches (e.g. Timestamp vs ISO date
    text, or int vs float). Real strings remain strict unless the other side is an
    unambiguous numeric/temporal representation of the same value.
    """
    ab, bb = is_blank(a), is_blank(b)
    if ab or bb:
        return ab and bb

    # Temporal values: date/datetime objects vs exact ISO text.
    ta, tb = _temporal_value(a), _temporal_value(b)
    if ta is not None and tb is not None:
        # Date and midnight datetime represent the same calendar value.
        if ta[0] == tb[0]:
            return ta[1] == tb[1]
        try:
            if ta[0] == "date" and tb[0] == "datetime":
                return tb[1].split("T", 1)[0] == ta[1]
            if ta[0] == "datetime" and tb[0] == "date":
                return ta[1].split("T", 1)[0] == tb[1]
        except Exception:
            pass

    # Numeric schema differences (int/float/NumPy numeric) are equal by value.
    if _is_number(a) and _is_number(b):
        try:
            return bool(a == b)
        except Exception:
            pass

    # A numeric value may be represented as an unambiguous numeric string.
    if _is_number(a) and isinstance(b, str):
        nb = _canonical_numeric_text(b)
        if nb is not None:
            try:
                return float(a) == float(nb)
            except Exception:
                pass
    if _is_number(b) and isinstance(a, str):
        na = _canonical_numeric_text(a)
        if na is not None:
            try:
                return float(na) == float(b)
            except Exception:
                pass

    # Strings are otherwise strict: no trimming, case folding, or NULL coercion.
    if isinstance(a, str) or isinstance(b, str):
        return type(a) is type(b) and a == b

    try:
        result = a == b
        if hasattr(result, "item"):
            result = result.item()
        return bool(result)
    except (TypeError, ValueError):
        return scalar_text(a) == scalar_text(b)


def _value_kind(v) -> str:
    """Logical scalar datatype used only by the datatype-aware report."""
    if is_blank(v):
        return "BLANK"
    if isinstance(v, bool):
        return "BOOLEAN"
    if isinstance(v, numbers.Integral) and not isinstance(v, bool):
        return "INTEGER"
    if isinstance(v, numbers.Real) and not isinstance(v, bool):
        return "DECIMAL"
    if isinstance(v, pd.Timestamp) or isinstance(v, datetime):
        return "DATETIME"
    if isinstance(v, date) and not isinstance(v, datetime):
        return "DATE"
    if isinstance(v, time):
        return "TIME"
    if isinstance(v, str):
        # Text remains text even when it looks numeric/date-like.
        return "STRING"
    return type(v).__name__.upper()


def values_equal_datatype(a, b) -> bool:
    """Datatype-aware comparison.

    Blank representations are intentionally equivalent. For non-blank values,
    the logical datatype must match AND the value must match under the same
    semantic comparison rules. Thus 453 (integer) and "453" (string) are
    different here, while the value-only mode can treat them as equal.
    """
    if is_blank(a) or is_blank(b):
        return is_blank(a) and is_blank(b)
    if _value_kind(a) != _value_kind(b):
        return False
    return values_equal(a, b)


def make_key(df: pd.DataFrame, key_columns: list[str]) -> pd.Series:
    missing = [c for c in key_columns if c not in df.columns]
    if missing:
        raise ValueError(f"Match-key columns missing: {', '.join(missing)}")
    return df[key_columns].apply(lambda row: "||".join(scalar_text(v) for v in row), axis=1)


def choose_default_keys(columns: list[str]) -> list[str]:
    s = set(columns)
    for candidate in DEFAULT_KEY_CANDIDATES:
        if all(c in s for c in candidate):
            return candidate.copy()
    # Safe fallback: one identifier-like field, not an arbitrary first column if possible.
    for c in columns:
        if "reference" in c.lower() or "id" in c.lower() or "number" in c.lower():
            return [c]
    return [columns[0]] if columns else []


def compare_tables(
    ifly: pd.DataFrame,
    odh: pd.DataFrame,
    key_columns: list[str],
    event_type: str = "RECONCILIATION",
    compare_columns: Iterable[str] | None = None,
    datatype_aware: bool = False,
):
    ifly, odh = clean_columns(ifly), clean_columns(odh)
    ifly["__recon_key"] = make_key(ifly, key_columns)
    odh["__recon_key"] = make_key(odh, key_columns)

    # A business key must identify one record on each side. Silent many-to-many
    # pairing creates false UPDATEs, so fail clearly instead.
    di = ifly["__recon_key"].duplicated(keep=False)
    do = odh["__recon_key"].duplicated(keep=False)
    if di.any() or do.any():
        msgs = []
        if di.any(): msgs.append(f"Step 1 contains {int(di.sum())} rows with duplicate match keys")
        if do.any(): msgs.append(f"Step 3 contains {int(do.sum())} rows with duplicate match keys")
        raise ValueError("; ".join(msgs) + ". Add the missing business-key column(s) so each record matches exactly one record.")

    if compare_columns is None:
        key_set = set(key_columns)
        compare_columns = [
            c for c in ifly.columns
            if c in odh.columns and c not in key_set and c not in IGNORE_COLUMNS
        ]
    compare_columns = list(compare_columns)
    if not compare_columns:
        raise ValueError("No common fields remain for comparison after excluding the match key.")

    i = ifly.set_index("__recon_key", drop=False)
    o = odh.set_index("__recon_key", drop=False)
    common = i.index.intersection(o.index)
    only_i = i.index.difference(o.index)
    only_o = o.index.difference(i.index)

    rows = []
    field_counts = {c: 0 for c in compare_columns}
    blank_i = {c: 0 for c in compare_columns}
    blank_o = {c: 0 for c in compare_columns}

    def keys_from(src, k):
        return {c: src.at[k, c] for c in key_columns}

    for k in common:
        mismatches = []
        row = {"ChangeType": "MATCH", **keys_from(i, k)}
        for c in compare_columns:
            iv, ov = i.at[k, c], o.at[k, c]
            if is_blank(iv): blank_i[c] += 1
            if is_blank(ov): blank_o[c] += 1
            row[c] = iv
            row[f"{c}_ODH"] = ov
            equal = values_equal_datatype(iv, ov) if datatype_aware else values_equal(iv, ov)
            if not equal:
                mismatches.append(c)
                field_counts[c] += 1
        if mismatches:
            row["ChangeType"] = "UPDATE"
        row["MismatchedFields"] = ", ".join(mismatches)
        rows.append(row)

    # iFly-only means ODH is missing the record -> INSERT into ODH.
    for k in only_i:
        row = {"ChangeType": "INSERT", **keys_from(i, k)}
        for c in compare_columns:
            row[c] = i.at[k, c]
            row[f"{c}_ODH"] = pd.NA
        row["MismatchedFields"] = ""
        rows.append(row)

    # ODH-only means the record is absent from iFly -> DELETE from ODH.
    for k in only_o:
        row = {"ChangeType": "DELETE", **keys_from(o, k)}
        for c in compare_columns:
            row[c] = pd.NA
            row[f"{c}_ODH"] = o.at[k, c]
        row["MismatchedFields"] = ""
        rows.append(row)

    changes = pd.DataFrame(rows)
    if not changes.empty:
        # Stable, logical ordering: inserts/updates/matches/deletes by key.
        order = {"INSERT": 0, "UPDATE": 1, "MATCH": 2, "DELETE": 3}
        changes["__order"] = changes["ChangeType"].map(order).fillna(9)
        changes = changes.sort_values(["__order"] + key_columns, kind="stable").drop(columns="__order").reset_index(drop=True)

    detail = pd.DataFrame([
        {
            "EventType": event_type,
            "FieldName": c,
            "MismatchCount": int(field_counts[c]),
            "iFlyBlankCount": int(blank_i[c]),
            "ODHBlankCount": int(blank_o[c]),
        }
        for c in compare_columns
    ])
    if not detail.empty:
        detail = detail.sort_values(["MismatchCount", "FieldName"], ascending=[False, True], kind="stable").reset_index(drop=True)

    matched = int((changes["ChangeType"] == "MATCH").sum()) if not changes.empty else 0
    updated = int((changes["ChangeType"] == "UPDATE").sum()) if not changes.empty else 0
    inserted = int((changes["ChangeType"] == "INSERT").sum()) if not changes.empty else 0
    deleted = int((changes["ChangeType"] == "DELETE").sum()) if not changes.empty else 0

    summary = pd.DataFrame([{
        "EventType": event_type,
        "Step1_iFly_Records": int(len(ifly)),
        "Step3_ODH_Records": int(len(odh)),
        "MATCH": matched,
        "UPDATE": updated,
        "MissingInODH": inserted,
        "MissingInIFly": deleted,
        "INSERT": inserted,
        "DELETE": deleted,
        "TotalComparedRecords": int(len(common)),
        "TotalOutputRecords": int(len(changes)),
        "RunTimestamp": datetime.now().isoformat(timespec="seconds"),
    }])
    return summary, detail, changes


def run_reconciliation(step1_path, step3_path, output_dir, key_columns, event_type="RECONCILIATION"):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    ifly = clean_columns(read_table(step1_path))
    odh = clean_columns(read_table(step3_path))

    step1_parquet = output_dir / "step1_ifly.parquet"
    step3_parquet = output_dir / "step3_odh.parquet"
    write_parquet(ifly, step1_parquet)
    write_parquet(odh, step3_parquet)

    # Compare the actual generated Parquet stages, as required by the process.
    ifly_p = read_table(step1_parquet)
    odh_p = read_table(step3_parquet)
    # Produce both requested Step 5 views from the same correctly matched records:
    # 1) value-only: semantic value comparison, ignoring datatype representation
    # 2) datatype-aware: semantic value + logical datatype must agree
    summary_value, detail_value, changes_value = compare_tables(
        ifly_p, odh_p, key_columns, event_type, datatype_aware=False
    )
    summary_type, detail_type, changes_type = compare_tables(
        ifly_p, odh_p, key_columns, event_type, datatype_aware=True
    )

    files = {
        "step1_parquet": step1_parquet,
        "step3_parquet": step3_parquet,
        "step4_summary": output_dir / "step4_recon_stats_summary.csv",
        "step4_detail": output_dir / "step4_recon_detailed_results.csv",
        "step5_value_only": output_dir / "step5_value_only_comparison.csv",
        "step5_datatype_comparison": output_dir / "step5_datatype_comparison.csv",
    }
    # Step 4 remains the value-only reconciliation, which is the business-value view.
    summary_value.to_csv(files["step4_summary"], index=False)
    detail_value.to_csv(files["step4_detail"], index=False)
    changes_value.to_csv(files["step5_value_only"], index=False)
    changes_type.to_csv(files["step5_datatype_comparison"], index=False)
    return files, summary_value, detail_value, changes_value, changes_type
