from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable
import pandas as pd

DEFAULT_KEY_COLUMNS = [
    "membershipNumber",
    "uniqueAccountID",
    "cardType",
    "cardHolderType",
    "updateTime",
]
DEFAULT_IGNORE_COLUMNS = {
    "_source_file", "_source_row", "action", "rpg", "Hierarchy", "hierarchy"
}


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(path, engine="pyarrow")
    if suffix in {".csv", ".txt"}:
        return pd.read_csv(path, low_memory=False)
    raise ValueError(f"Unsupported file type: {path.name}. Use CSV or Parquet.")


def write_parquet(df: pd.DataFrame, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False, engine="pyarrow")


def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    return out


def norm(v) -> str:
    if pd.isna(v):
        return "<NULL>"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    s = str(v).strip()
    if s.endswith(".0"):
        try:
            return str(int(float(s)))
        except Exception:
            pass
    return s


def make_key(df: pd.DataFrame, key_columns: list[str]) -> pd.Series:
    missing = [c for c in key_columns if c not in df.columns]
    if missing:
        raise ValueError(f"Match-key columns missing: {', '.join(missing)}")
    return df[key_columns].map(norm).astype(str).agg("||".join, axis=1)


def compare_tables(
    ifly: pd.DataFrame,
    odh: pd.DataFrame,
    key_columns: list[str],
    event_type: str,
    compare_columns: Iterable[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ifly = clean_columns(ifly)
    odh = clean_columns(odh)

    ifly["__recon_key"] = make_key(ifly, key_columns)
    odh["__recon_key"] = make_key(odh, key_columns)

    dup_i = ifly["__recon_key"].duplicated(keep=False)
    dup_o = odh["__recon_key"].duplicated(keep=False)
    if dup_i.any() or dup_o.any():
        details = []
        if dup_i.any(): details.append(f"Step 1 has {int(dup_i.sum())} duplicate rows for the selected key")
        if dup_o.any(): details.append(f"Step 3 has {int(dup_o.sum())} duplicate rows for the selected key")
        raise ValueError("; ".join(details) + ". Select a more specific match key.")

    if compare_columns is None:
        compare_columns = [
            c for c in ifly.columns
            if c in odh.columns
            and c not in set(key_columns)
            and c != "__recon_key"
            and c not in DEFAULT_IGNORE_COLUMNS
        ]
    compare_columns = list(compare_columns)
    if not compare_columns:
        raise ValueError("No common non-key columns are available for comparison.")

    i = ifly.set_index("__recon_key", drop=False)
    o = odh.set_index("__recon_key", drop=False)
    common = i.index.intersection(o.index)
    only_i = i.index.difference(o.index)
    only_o = o.index.difference(i.index)

    changes = []
    mismatch_by_field = {c: 0 for c in compare_columns}
    null_odh = {c: 0 for c in compare_columns}
    null_ifly = {c: 0 for c in compare_columns}

    def base_row(source, key):
        return {c: source.at[key, c] for c in key_columns}

    for k in common:
        mismatches = []
        row = {"ChangeType": "MATCH", **base_row(i, k)}
        for c in compare_columns:
            iv, ov = i.at[k, c], o.at[k, c]
            if pd.isna(ov): null_odh[c] += 1
            if pd.isna(iv): null_ifly[c] += 1
            row[c] = iv
            row[f"{c}_ODH"] = ov
            if norm(iv) != norm(ov):
                mismatch_by_field[c] += 1
                mismatches.append(c)
        if mismatches:
            row["ChangeType"] = "UPDATE"
        row["MismatchedFields"] = ", ".join(mismatches)
        changes.append(row)

    for k in only_i:
        row = {"ChangeType": "INSERT", **base_row(i, k)}
        for c in compare_columns:
            row[c] = i.at[k, c]
            row[f"{c}_ODH"] = pd.NA
        row["MismatchedFields"] = ""
        changes.append(row)

    for k in only_o:
        row = {"ChangeType": "DELETE", **base_row(o, k)}
        for c in compare_columns:
            row[c] = pd.NA
            row[f"{c}_ODH"] = o.at[k, c]
        row["MismatchedFields"] = ""
        changes.append(row)

    # Step 4 detailed report: mismatch percentage is measured against all ODH rows,
    # matching the reference report supplied with this automation.
    detail_rows = []
    total_odh = max(len(odh), 1)
    for c in compare_columns:
        count = mismatch_by_field[c]
        detail_rows.append({
            "EventType": event_type,
            "FieldName": c,
            "MismatchCount": count,
            "MismatchPercentage": round((count / total_odh) * 100, 2),
            "ODH_NullCount": null_odh[c],
            "iFly_NullCount": null_ifly[c],
            "ImpactRank": None,
        })
    detail = pd.DataFrame(detail_rows)
    if not detail.empty:
        ranked = detail["MismatchCount"].rank(method="min", ascending=False)
        detail.loc[detail["MismatchCount"] > 0, "ImpactRank"] = ranked[detail["MismatchCount"] > 0]
        detail["ImpactRank"] = detail["ImpactRank"].astype("Int64")
        detail = detail.sort_values(["MismatchCount", "FieldName"], ascending=[False, True]).reset_index(drop=True)

    change_df = pd.DataFrame(changes)
    matched_count = int((change_df["ChangeType"] == "MATCH").sum()) if not change_df.empty else 0
    update_count = int((change_df["ChangeType"] == "UPDATE").sum()) if not change_df.empty else 0
    top = detail.iloc[0] if not detail.empty else None
    summary = pd.DataFrame([{
        "EventType": event_type,
        "TotalRecords": len(odh),
        "MatchedRecords": matched_count,
        "MismatchedRecords": update_count,
        "MissingInODH": len(only_i),
        "MissingInIFly": len(only_o),
        "TopAffectedField": top["FieldName"] if top is not None and top["MismatchCount"] > 0 else "",
        "TopAffectedFieldMismatchPercentage": float(top["MismatchPercentage"]) if top is not None and top["MismatchCount"] > 0 else 0.0,
        "RunTimestamp": datetime.now().isoformat(timespec="seconds"),
    }])
    return summary, detail, change_df


def run_reconciliation(
    step1_path: str | Path,
    step3_path: str | Path,
    output_dir: str | Path,
    key_columns: list[str] | None = None,
    event_type: str = "RECONCILIATION",
) -> dict[str, Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    key_columns = key_columns or DEFAULT_KEY_COLUMNS

    ifly = clean_columns(read_table(step1_path))
    odh = clean_columns(read_table(step3_path))

    step1_parquet = output_dir / "step1_ifly.parquet"
    step3_parquet = output_dir / "step3_odh.parquet"
    write_parquet(ifly, step1_parquet)
    write_parquet(odh, step3_parquet)

    # The actual reconciliation is deliberately performed on the normalized
    # Step 1 / Step 3 parquet stages, matching the requested process.
    ifly_parquet = read_table(step1_parquet)
    odh_parquet = read_table(step3_parquet)
    summary, detail, changes = compare_tables(ifly_parquet, odh_parquet, key_columns, event_type)

    step4_summary = output_dir / "step4_recon_stats_summary.csv"
    step4_detail = output_dir / "step4_recon_detailed_results.csv"
    step5 = output_dir / "step5_match_and_missed_odh_report.csv"
    step5_changes = output_dir / "step5_odh_changes_only.csv"

    summary.to_csv(step4_summary, index=False)
    detail.to_csv(step4_detail, index=False)
    changes.to_csv(step5, index=False)
    changes[changes["ChangeType"] != "MATCH"].to_csv(step5_changes, index=False)

    return {
        "step1_parquet": step1_parquet,
        "step3_parquet": step3_parquet,
        "step4_summary": step4_summary,
        "step4_detail": step4_detail,
        "step5_match_missed": step5,
        "step5_changes_only": step5_changes,
    }
