import io
import os
import re
import pandas as pd
import streamlit as st
from db import PG
from prediction import predict
from comparison import compare
from exports import excel_bytes, csv_bytes

st.set_page_config(page_title='Enterprise Data Reconciliation', page_icon='🔄', layout='wide', initial_sidebar_state='expanded')
st.markdown('''<style>
.block-container{padding-top:1rem;max-width:1500px}
.workflow{border:1px solid #d8dee9;border-radius:12px;padding:12px;margin-bottom:14px;background:#f8fafc}
.small{font-size:.88rem;color:#64748b}
</style>''', unsafe_allow_html=True)

DEFAULTS = {
    'host': os.getenv('PGHOST','localhost'),
    'port': int(os.getenv('PGPORT','5434')),
    'database': os.getenv('PGDATABASE','OperationsDataMart'),
    'user': os.getenv('PGUSER','dbadmin'),
    'password': os.getenv('PGPASSWORD',''),
}
for key, default in {
    'db': None, 'src': None, 'src_name': None, 'pred': None, 'cmp': None,
    'selected_schema': None, 'selected_target': None, 'candidate_tables': [],
    'mapping': None, 'audit': []
}.items():
    if key not in st.session_state:
        st.session_state[key] = default


def db_label(db):
    return f'{db.host}:{db.port}/{db.database}' if db else 'Not connected'


def invalidate_workflow():
    st.session_state.pred = None
    st.session_state.cmp = None
    st.session_state.mapping = None


def connect_now(host, port, database, user, password):
    x = PG(host, int(port), database, user, password)
    ok, msg, version = x.test()
    if ok:
        st.session_state.db = x
        st.session_state.selected_target = None
        st.session_state.selected_schema = None
        st.session_state.candidate_tables = []
        invalidate_workflow()
        st.session_state.audit.append(f'Connected to {database} as {user}')
        return True, msg, version
    st.session_state.db = None
    return False, msg, None


def require_db():
    if not st.session_state.db:
        st.error('Connect to PostgreSQL first.')
        return False
    return True


def require_source():
    if st.session_state.src is None:
        st.info('Upload a CSV, Excel or Parquet source first.')
        return False
    return True


def current_target_options():
    db = st.session_state.db
    if not db:
        return []
    schema = st.session_state.selected_schema
    if not schema:
        return []
    return db.tables(schema)


def target_gate():
    """Require the user-approved target from Auto Table Prediction."""
    target = st.session_state.selected_target
    if not target:
        st.warning('No target table has been approved yet. Go to 🎯 Auto Table Prediction, select the tables to consider, run prediction, then click Proceed with Selected Table.')
        return False
    st.success(f'Approved target: **{target[0]}.{target[1]}**')
    return True


# ---------------- Sidebar ----------------
with st.sidebar:
    st.header('🔌 PostgreSQL Connection')
    host = st.text_input('Host', DEFAULTS['host'], key='conn_host')
    port = st.number_input('Port', 1, 65535, DEFAULTS['port'], key='conn_port')
    database = st.text_input('Database', DEFAULTS['database'], key='conn_database')
    user = st.text_input('Username', DEFAULTS['user'], key='conn_user')
    password = st.text_input('Password', DEFAULTS['password'], type='password', key='conn_password')
    if st.button('🔗 Connect / Refresh', type='primary', use_container_width=True):
        ok, msg, _ = connect_now(host, port, database, user, password)
        (st.success if ok else st.error)(msg)
    if st.session_state.db:
        st.success(f'Connected\n{db_label(st.session_state.db)}')
    else:
        st.warning('Not connected')

    st.divider()
    st.subheader('📌 Workflow')
    st.write('1. 📁 Upload source')
    st.write('2. 🔌 Connect PostgreSQL')
    st.write('3. 🎯 Select candidate tables')
    st.write('4. 🎯 Predict + approve ONE target')
    st.write('5. 🔗 Map columns')
    st.write('6. ⚖️ Compare / validate / export')
    if st.session_state.src is not None:
        st.caption(f'📄 Source: {st.session_state.src_name} · {len(st.session_state.src):,} rows')
    if st.session_state.selected_target:
        st.caption(f'🎯 Target: {st.session_state.selected_target[0]}.{st.session_state.selected_target[1]}')

    page = st.radio('Navigation', [
        '🏠 Dashboard','🔌 Connection Status','📁 File Upload','🗄️ Database Explorer',
        '📊 Table Data Explorer','🔬 Data Profiling','🎯 Auto Table Prediction','🔗 Column Mapping',
        '⚖️ CSV ↔ PostgreSQL','🔄 CSV → Parquet → PostgreSQL','🔎 Difference Viewer','🧾 SQL Console',
        '🤖 AI Recommendations','📝 Query Generator','✅ Approval Center','▶️ Execution Center',
        '↩️ Rollback Center','📜 Audit History','📈 Reports','⚙️ Settings'
    ])


db = st.session_state.db

# ---------------- Dashboard ----------------
if page == '🏠 Dashboard':
    st.title('🔄 Enterprise Data Reconciliation')
    st.caption('A controlled, read-only PostgreSQL reconciliation workflow with explicit target-table selection.')
    st.markdown('<div class="workflow"><b>Recommended run order</b><br>Upload → Connect → Select candidate tables → Predict → Approve target → Map → Compare → Export</div>', unsafe_allow_html=True)
    if db:
        schemas = db.schemas()
        total = sum(len(db.tables(s)) for s in schemas)
        a,b,c,d = st.columns(4)
        a.metric('Database', db.database)
        b.metric('Schemas', len(schemas))
        c.metric('Tables / Views', total)
        d.metric('Status', 'ONLINE')
    else:
        st.info('Default target: localhost:5434 / OperationsDataMart / dbadmin. Enter the password in the sidebar and connect.')
    if st.session_state.selected_target:
        st.subheader('Approved target')
        st.info(f'{st.session_state.selected_target[0]}.{st.session_state.selected_target[1]}')

elif page == '🔌 Connection Status':
    st.header('Connection Status')
    if require_db():
        ok,msg,version = db.test()
        (st.success if ok else st.error)(msg)
        if ok:
            st.json({'host':db.host,'port':db.port,'database':db.database,'user':db.user,'status':'authenticated'})
            st.code(version)

# ---------------- File Upload ----------------
elif page == '📁 File Upload':
    st.header('📁 Source File Upload')
    st.caption('Upload the source dataset that will be mapped/reconciled against PostgreSQL.')
    f = st.file_uploader('CSV / Excel / Parquet', type=['csv','xlsx','xls','parquet'])
    if f:
        try:
            if f.name.lower().endswith('.csv'):
                df = pd.read_csv(f)
            elif f.name.lower().endswith('.parquet'):
                df = pd.read_parquet(f)
            else:
                df = pd.read_excel(f)
            st.session_state.src = df
            st.session_state.src_name = f.name
            st.session_state.pred = None
            st.session_state.cmp = None
            st.session_state.mapping = None
            st.session_state.audit.append(f'Loaded source {f.name} ({len(df):,} rows)')
            st.success(f'Loaded {len(df):,} rows × {len(df.columns)} columns')
        except Exception as e:
            st.error(f'Could not load file: {e}')
    if st.session_state.src is not None:
        df = st.session_state.src
        a,b,c = st.columns(3)
        a.metric('Rows', f'{len(df):,}')
        b.metric('Columns', len(df.columns))
        c.metric('File', st.session_state.src_name or 'Source')
        st.dataframe(df.head(100), use_container_width=True, height=450)
        st.download_button('Export current source as CSV', csv_bytes(df), 'source.csv', 'text/csv')

# ---------------- Database Explorer ----------------
elif page == '🗄️ Database Explorer':
    st.header('🗄️ Database Explorer')
    if require_db():
        schemas = db.schemas()
        if not schemas:
            st.warning('No non-system schemas were returned.')
        else:
            default_idx = schemas.index(st.session_state.selected_schema) if st.session_state.selected_schema in schemas else 0
            schema = st.selectbox('Schema', schemas, index=default_idx, key='explorer_schema')
            objects = db.objects(schema)
            q = st.text_input('🔎 Search tables / views', key='explorer_search')
            objects = objects[objects['table_name'].str.contains(q, case=False, na=False)] if q else objects
            st.write(f'{len(objects)} matching objects')
            if len(objects):
                obj = st.selectbox('Table / View', objects['table_name'].tolist())
                meta = db.meta(schema, obj)
                st.dataframe(meta, use_container_width=True, hide_index=True)
                if st.button('📊 Open Table Data', type='primary'):
                    st.session_state.selected_schema = schema
                    st.session_state.selected_target = (schema,obj)
                    st.rerun()

# ---------------- Table Data ----------------
elif page == '📊 Table Data Explorer':
    st.header('📊 Table Data Explorer')
    if require_db():
        schemas = db.schemas()
        schema = st.selectbox('Schema', schemas, index=schemas.index(st.session_state.selected_schema) if st.session_state.selected_schema in schemas else 0)
        tables = db.tables(schema)
        preferred = st.session_state.selected_target[1] if st.session_state.selected_target and st.session_state.selected_target[0]==schema else None
        t = st.selectbox('Table / View', tables, index=tables.index(preferred) if preferred in tables else 0)
        total = db.count(schema,t)
        m = db.meta(schema,t)
        a,b,c,d = st.columns(4)
        a.metric('Rows', f'{total:,}'); b.metric('Columns', len(m)); c.metric('Primary Keys', int(m.is_primary_key.sum())); d.metric('Indexes', db.indexes(schema,t))
        size = st.selectbox('Rows per page', [25,50,100,250,500], index=1)
        pages = max(1,(total+size-1)//size)
        pg = st.number_input('Page', 1, pages, 1)
        df = db.fetch(schema,t,int(size),(int(pg)-1)*int(size))
        st.dataframe(df,use_container_width=True,height=520)
        x,y = st.columns(2)
        x.download_button('Export CSV',csv_bytes(df),'table_page.csv','text/csv',use_container_width=True)
        y.download_button('Export Excel',excel_bytes(df),'table_page.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',use_container_width=True)

# ---------------- Profiling ----------------
elif page == '🔬 Data Profiling':
    st.header('🔬 Data Profiling')
    if require_source():
        df = st.session_state.src
        report = pd.DataFrame({
            'column':df.columns,
            'dtype':[str(df[c].dtype) for c in df.columns],
            'nulls':[int(df[c].isna().sum()) for c in df.columns],
            'null_%':[round(float(df[c].isna().mean()*100),2) for c in df.columns],
            'unique':[int(df[c].nunique(dropna=True)) for c in df.columns]
        })
        st.dataframe(report,use_container_width=True,hide_index=True)

# ---------------- Auto prediction ----------------
elif page == '🎯 Auto Table Prediction':
    st.header('🎯 Auto Table Prediction')
    st.caption('You control the search scope. Prediction runs ONLY against the tables you select below.')
    if not require_db() or not require_source():
        pass
    else:
        schemas = db.schemas()
        schema = st.selectbox('1️⃣ Target schema', schemas, index=schemas.index(st.session_state.selected_schema) if st.session_state.selected_schema in schemas else 0, key='predict_schema')
        all_tables = db.tables(schema)
        search = st.text_input('🔎 Filter available tables', placeholder='Type part of a table name...')
        visible = [t for t in all_tables if not search or search.lower() in t.lower()]
        previous = [t for t in st.session_state.candidate_tables if t in visible]
        selected = st.multiselect(
            '2️⃣ Tables to consider for prediction (select one or more)',
            visible,
            default=previous if previous else [],
            help='Only these selected tables will be inspected and scored.'
        )
        st.session_state.selected_schema = schema
        st.session_state.candidate_tables = selected
        if selected:
            st.info(f'{len(selected)} table(s) selected for prediction. No other table will be considered.')
        else:
            st.warning('Select at least one table before running prediction.')

        if st.button('🎯 3️⃣ Predict ONLY Selected Tables', type='primary', disabled=not selected, use_container_width=False):
            with st.spinner('Comparing source columns with the selected PostgreSQL tables...'):
                st.session_state.pred = predict(db, schema, st.session_state.src, selected)
            st.session_state.audit.append(f'Predicted target from {len(selected)} selected table(s)')

        if st.session_state.pred is not None:
            r = st.session_state.pred
            st.subheader('Prediction results')
            st.dataframe(r, use_container_width=True, hide_index=True)
            if len(r):
                st.divider()
                names = r['table'].tolist()
                current = st.session_state.selected_target[1] if st.session_state.selected_target and st.session_state.selected_target[0]==schema and st.session_state.selected_target[1] in names else names[0]
                final = st.selectbox('4️⃣ Select the final target table from the prediction results', names, index=names.index(current))
                row = r[r['table']==final].iloc[0]
                st.write(f"**{final}** — {row['confidence']:.1f}% confidence · {int(row['matching_columns'])} matching columns")
                if st.button('✅ 5️⃣ Proceed with Selected Table', type='primary'):
                    st.session_state.selected_target = (schema, final)
                    st.session_state.mapping = None
                    st.session_state.cmp = None
                    st.session_state.audit.append(f'Approved target {schema}.{final}')
                    st.success(f'Approved target: {schema}.{final}. All downstream mapping/comparison pages now use this target.')
                    st.rerun()

# ---------------- Column mapping ----------------
elif page == '🔗 Column Mapping':
    st.header('🔗 Column Mapping')
    if require_db() and require_source() and target_gate():
        schema, table = st.session_state.selected_target
        target_cols = db.columns(schema,table)
        src = st.session_state.src
        target_norm = {re.sub(r'[^a-z0-9]','',str(c).lower()):c for c in target_cols}
        rows=[]
        for c in src.columns:
            key=re.sub(r'[^a-z0-9]','',str(c).lower())
            rows.append({'source_column':c,'target_column':target_norm.get(key,''),'mapped':bool(target_norm.get(key,''))})
        mapping_df=pd.DataFrame(rows)
        st.caption(f'Only approved target **{schema}.{table}** is available here.')
        edited=st.data_editor(mapping_df,use_container_width=True,hide_index=True,column_config={
            'target_column': st.column_config.SelectboxColumn('Target column', options=['']+target_cols),
            'mapped': st.column_config.CheckboxColumn('Mapped', disabled=True)
        },disabled=['source_column','mapped'],key='mapping_editor')
        if st.button('💾 Save Mapping',type='primary'):
            st.session_state.mapping=edited
            st.session_state.audit.append(f'Saved column mapping for {schema}.{table}')
            st.success('Column mapping saved for the approved target.')
        if st.session_state.mapping is not None:
            st.download_button('Export mapping CSV',csv_bytes(st.session_state.mapping),'column_mapping.csv','text/csv')

# ---------------- Comparison ----------------
elif page == '⚖️ CSV ↔ PostgreSQL':
    st.header('⚖️ CSV ↔ PostgreSQL Comparison')
    if require_db() and require_source() and target_gate():
        schema, table = st.session_state.selected_target
        src = st.session_state.src
        target_cols = db.columns(schema,table)
        by_norm={str(c).strip().lower():c for c in target_cols}
        common=[]
        for c in src.columns:
            tc=by_norm.get(str(c).strip().lower())
            if tc: common.append(c)
        pk=db.primary_keys(schema,table)
        default_keys=[c for c in common if str(c).strip().lower() in {x.strip().lower() for x in pk}]
        st.caption(f'Comparison is locked to approved target **{schema}.{table}**.')
        keys=st.multiselect('Primary / business keys',common,default=default_keys or common[:1])
        limit=st.number_input('Maximum target rows to read',1000,1000000,250000,1000)
        if st.button('⚖️ Run Comparison',type='primary'):
            try:
                with st.spinner('Reading target data and comparing keys...'):
                    st.session_state.cmp=compare(src,db.fetch_all_limited(schema,table,int(limit)),keys)
                st.session_state.audit.append(f'Compared source with {schema}.{table}')
            except Exception as e: st.error(str(e))
        r=st.session_state.cmp
        if r:
            a,b,c,d,e,f,g=st.columns(7)
            a.metric('Source',f"{r['source_rows']:,}"); b.metric('Target',f"{r['target_rows']:,}"); c.metric('Matched',f"{r['matched']:,}"); d.metric('Missing target',f"{r['missing_in_target']:,}"); e.metric('Missing source',f"{r['missing_in_source']:,}"); f.metric('Changed',f"{r['changed_rows']:,}"); g.metric('Duplicate key rows',f"{r['duplicate_source_key_rows']+r['duplicate_target_key_rows']:,}")
            st.dataframe(r['differences'],use_container_width=True,height=450)
            st.download_button('Export differences to Excel',excel_bytes(r['differences']),'differences.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

# ---------------- Parquet validation ----------------
elif page == '🔄 CSV → Parquet → PostgreSQL':
    st.header('🔄 CSV → Parquet → PostgreSQL')
    if require_source():
        if st.button('🔄 Validate Pipeline',type='primary'):
            try:
                df=st.session_state.src
                b=io.BytesIO(); df.to_parquet(b,index=False); out=pd.read_parquet(io.BytesIO(b.getvalue()))
                checks=[
                    ('row_count',len(df),len(out)),('column_count',len(df.columns),len(out.columns)),
                    ('null_count',int(df.isna().sum().sum()),int(out.isna().sum().sum())),('column_order',list(df.columns),list(out.columns))
                ]
                rep=pd.DataFrame({'check':[x[0] for x in checks],'source':[x[1] for x in checks],'parquet':[x[2] for x in checks]})
                rep['status']=['PASS' if x[1]==x[2] else 'FAIL' for x in checks]
                st.dataframe(rep,use_container_width=True,hide_index=True)
            except Exception as e: st.error(f'Pipeline validation failed: {e}')

# ---------------- Difference viewer ----------------
elif page == '🔎 Difference Viewer':
    st.header('🔎 Difference Viewer')
    r=st.session_state.cmp
    if not r: st.info('Run a comparison first.')
    else:
        st.dataframe(r['differences'],use_container_width=True)
        st.download_button('Export differences',excel_bytes(r['differences']),'differences.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

# ---------------- SQL ----------------
elif page == '🧾 SQL Console':
    st.header('🧾 SQL Console (read-only)')
    if require_db():
        q=st.text_area('SQL',height=220,placeholder='SELECT * FROM public.my_table LIMIT 100;')
        if st.button('▶ Run SQL',type='primary'):
            try:
                df=db.query(q); st.dataframe(df,use_container_width=True,height=500); st.download_button('Export CSV',csv_bytes(df),'sql_result.csv','text/csv')
            except Exception as e: st.error(str(e))

# ---------------- AI recommendations ----------------
elif page == '🤖 AI Recommendations':
    st.header('🤖 Data Quality Recommendations')
    if require_source():
        df=st.session_state.src; rec=[]
        for c in df.columns:
            p=float(df[c].isna().mean()*100)
            if p>20: rec.append(f'`{c}` has {p:.1f}% nulls; review completeness.')
            if len(df)>10 and df[c].nunique(dropna=True)==len(df): rec.append(f'`{c}` is unique across the source and may be a business-key candidate.')
        if rec:
            for x in rec: st.write('•',x)
        else: st.success('No basic data-quality recommendations triggered.')

# ---------------- Query generator ----------------
elif page == '📝 Query Generator':
    st.header('📝 Query Generator')
    if require_db():
        if st.session_state.selected_target:
            schema, table=st.session_state.selected_target
            st.info(f'Using approved target: {schema}.{table}')
        else:
            schemas=db.schemas(); schema=st.selectbox('Schema',schemas); table=st.selectbox('Table',db.tables(schema))
        cols=db.columns(schema,table); chosen=st.multiselect('Columns',cols,default=cols[:10]); lim=st.number_input('LIMIT',1,100000,100); where=st.text_input('Optional WHERE clause')
        esc=lambda x:'"'+x.replace('"','""')+'"'
        q='SELECT '+(', '.join(esc(x) for x in chosen) if chosen else '*')+f' FROM {esc(schema)}.{esc(table)}'+((' WHERE '+where) if where.strip() else '')+f' LIMIT {int(lim)};'
        st.code(q,language='sql')

# ---------------- Placeholders / audit ----------------
elif page == '✅ Approval Center':
    st.header('✅ Approval Center')
    if st.session_state.selected_target: st.success(f'Approved: {st.session_state.selected_target[0]}.{st.session_state.selected_target[1]}')
    else: st.info('No target approved yet.')
    st.warning('This build is read-only; no production write operation is enabled.')

elif page == '▶️ Execution Center':
    st.header('▶️ Execution Center'); st.warning('Write operations are disabled in this safety build.'); st.code('READ-ONLY MODE')

elif page == '↩️ Rollback Center':
    st.header('↩️ Rollback Center'); st.info('No write operations are executed, so there is nothing to roll back.')

elif page == '📜 Audit History':
    st.header('📜 Audit History')
    if st.session_state.audit: st.dataframe(pd.DataFrame({'event':st.session_state.audit}),use_container_width=True,hide_index=True)
    else: st.info('No actions recorded in this session. Credentials are never added to the audit log.')

elif page == '📈 Reports':
    st.header('📈 Reports')
    if st.session_state.cmp:
        r=st.session_state.cmp
        x=pd.DataFrame([{k:r[k] for k in ['source_rows','target_rows','matched','missing_in_target','missing_in_source','changed_rows','duplicate_source_key_rows','duplicate_target_key_rows']}])
        st.dataframe(x,use_container_width=True)
        st.download_button('Download report',excel_bytes(x),'reconciliation_report.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    else: st.info('Run a comparison first.')

elif page == '⚙️ Settings':
    st.header('⚙️ Settings')
    st.code('PGHOST=localhost\nPGPORT=5434\nPGDATABASE=OperationsDataMart\nPGUSER=dbadmin\nPGPASSWORD=YOUR_PASSWORD')
    st.info('For Windows, double-click START_HERE.bat. It creates the virtual environment, installs dependencies and starts Streamlit. Database passwords are entered in the UI and are not written into the application code.')
