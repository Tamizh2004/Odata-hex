@echo off
call "%~dp0START_HERE.bat"
