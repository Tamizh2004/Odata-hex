import pandas as pd

def compare(source, target, keys):
    if not keys:
        raise ValueError('Select at least one primary/business key.')
    s, t = source.copy(), target.copy()
    # Case-insensitive column resolution.
    target_by_norm = {str(c).strip().lower(): c for c in t.columns}
    source_by_norm = {str(c).strip().lower(): c for c in s.columns}
    resolved_keys = []
    for k in keys:
        sk, tk = source_by_norm.get(str(k).strip().lower()), target_by_norm.get(str(k).strip().lower())
        if sk is None or tk is None:
            raise ValueError(f'Key column "{k}" is missing from source or target.')
        if sk != tk:
            t = t.rename(columns={tk: sk})
        resolved_keys.append(sk)

    common = [c for c in s.columns if c in t.columns]
    non = [c for c in common if c not in resolved_keys]
    for k in resolved_keys:
        s[k] = s[k].astype('string').fillna('<NULL>')
        t[k] = t[k].astype('string').fillna('<NULL>')

    source_dup = int(s.duplicated(resolved_keys, keep=False).sum())
    target_dup = int(t.duplicated(resolved_keys, keep=False).sum())
    # Keep the first occurrence so comparison remains deterministic, while reporting duplicates.
    sm = s.drop_duplicates(resolved_keys, keep='first').set_index(resolved_keys, drop=False)
    tm = t.drop_duplicates(resolved_keys, keep='first').set_index(resolved_keys, drop=False)
    sk, tk = set(sm.index), set(tm.index)
    both = sk & tk
    changed = []

    def equal(a, b):
        if pd.isna(a) and pd.isna(b):
            return True
        return str(a) == str(b)

    for key in both:
        a, b = sm.loc[key], tm.loc[key]
        dif = {}
        for c in non:
            if not equal(a[c], b[c]):
                dif[c] = {'source': a[c], 'target': b[c]}
        if dif:
            changed.append({'key': str(key), 'differences': str(dif)})

    return {
        'source_rows': len(s), 'target_rows': len(t), 'matched': len(both),
        'missing_in_target': len(sk - tk), 'missing_in_source': len(tk - sk),
        'changed_rows': len(changed), 'duplicate_source_key_rows': source_dup,
        'duplicate_target_key_rows': target_dup, 'differences': pd.DataFrame(changed)
    }
