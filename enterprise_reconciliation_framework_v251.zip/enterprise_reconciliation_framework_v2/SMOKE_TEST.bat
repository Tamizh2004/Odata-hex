@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run START_HERE.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m py_compile app.py db.py prediction.py comparison.py exports.py
if errorlevel 1 (
  echo [FAIL] Python syntax/import compilation failed.
) else (
  echo [PASS] Framework Python files compiled successfully.
)
pause
