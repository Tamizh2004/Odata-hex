$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.venv\Scripts\python.exe')) {
    py -3 -m venv .venv
}
.\.venv\Scripts\python.exe -m pip install --disable-pip-version-check -q --upgrade pip
.\.venv\Scripts\python.exe -m pip install --disable-pip-version-check -q -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
