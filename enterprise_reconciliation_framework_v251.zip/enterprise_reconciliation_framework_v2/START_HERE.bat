@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title Enterprise Data Reconciliation - Start

echo ============================================================
echo   Enterprise Data Reconciliation Framework
echo   One-click Windows launcher
echo ============================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PY=python"
    ) else (
        echo [ERROR] Python 3 was not found.
        echo Install Python 3.10+ from python.org and run this file again.
        pause
        exit /b 1
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating local Python environment...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
)

echo [2/3] Installing / updating required packages...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q --upgrade pip
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 goto :fail

echo [3/3] Starting application...
echo.
echo The browser will open at http://localhost:8501
echo Keep this window open while using the application.
echo.
".venv\Scripts\python.exe" -m streamlit run app.py
if errorlevel 1 goto :fail
exit /b 0

:fail
echo.
echo [ERROR] Setup/start failed. Read the message above.
pause
exit /b 1
