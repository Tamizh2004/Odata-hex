import pandas as pd
import psycopg2
from psycopg2 import sql

class PG:
    def __init__(self, host, port, database, user, password):
        self.host, self.port, self.database, self.user, self.password = host, int(port), database, user, password

    def conn(self):
        return psycopg2.connect(
            host=self.host, port=self.port, dbname=self.database, user=self.user,
            password=self.password, connect_timeout=5,
            application_name='EnterpriseReconciliationFramework'
        )

    def test(self):
        try:
            with self.conn() as c, c.cursor() as cur:
                cur.execute('select current_database(), current_user, version()')
                db, user, version = cur.fetchone()
            return True, f'Connected to {db} as {user}.', version
        except Exception as e:
            return False, str(e), None

    def version(self):
        with self.conn() as c, c.cursor() as cur:
            cur.execute('select version()')
            return cur.fetchone()[0]

    def schemas(self):
        q = """
        select schema_name
        from information_schema.schemata
        where schema_name not in ('pg_catalog','information_schema')
          and schema_name not like 'pg_toast%'
        order by schema_name
        """
        with self.conn() as c:
            return pd.read_sql_query(q, c)['schema_name'].tolist()

    def objects(self, schema):
        q = """
        select table_name, table_type
        from information_schema.tables
        where table_schema=%s
        union all
        select table_name, 'VIEW' as table_type
        from information_schema.views
        where table_schema=%s
        order by table_name
        """
        with self.conn() as c:
            return pd.read_sql_query(q, c, params=[schema, schema])

    def tables(self, schema):
        return self.objects(schema)['table_name'].tolist()

    def columns(self, schema, table):
        q = """
        select column_name
        from information_schema.columns
        where table_schema=%s and table_name=%s
        order by ordinal_position
        """
        with self.conn() as c:
            return pd.read_sql_query(q, c, params=[schema, table])['column_name'].tolist()

    def meta(self, schema, table):
        # Aggregate PK membership so each column appears exactly once.
        q = """
        select c.column_name,
               c.data_type,
               c.udt_name,
               c.is_nullable,
               c.ordinal_position,
               exists (
                   select 1
                   from information_schema.key_column_usage k
                   join information_schema.table_constraints tc
                     on tc.constraint_schema=k.constraint_schema
                    and tc.constraint_name=k.constraint_name
                    and tc.table_name=k.table_name
                   where k.table_schema=c.table_schema
                     and k.table_name=c.table_name
                     and k.column_name=c.column_name
                     and tc.constraint_type='PRIMARY KEY'
               ) as is_primary_key
        from information_schema.columns c
        where c.table_schema=%s and c.table_name=%s
        order by c.ordinal_position
        """
        with self.conn() as c:
            return pd.read_sql_query(q, c, params=[schema, table])

    def primary_keys(self, schema, table):
        m = self.meta(schema, table)
        return m.loc[m['is_primary_key'].fillna(False), 'column_name'].tolist()

    def count(self, schema, table):
        q = sql.SQL('select count(*) from {}.{}').format(sql.Identifier(schema), sql.Identifier(table))
        with self.conn() as c, c.cursor() as cur:
            cur.execute(q)
            return int(cur.fetchone()[0])

    def indexes(self, schema, table):
        with self.conn() as c, c.cursor() as cur:
            cur.execute('select count(*) from pg_indexes where schemaname=%s and tablename=%s', [schema, table])
            return int(cur.fetchone()[0])

    def fetch(self, schema, table, limit=100, offset=0):
        q = sql.SQL('select * from {}.{} limit %s offset %s').format(sql.Identifier(schema), sql.Identifier(table))
        with self.conn() as c:
            return pd.read_sql_query(q.as_string(c), c, params=[int(limit), int(offset)])

    def fetch_all_limited(self, schema, table, limit=250000):
        q = sql.SQL('select * from {}.{} limit %s').format(sql.Identifier(schema), sql.Identifier(table))
        with self.conn() as c:
            return pd.read_sql_query(q.as_string(c), c, params=[int(limit)])

    def query(self, q):
        stripped = q.strip().lower()
        if not stripped.startswith(('select','with','show','explain')):
            raise ValueError('SQL Console is read-only. Use SELECT, WITH, SHOW or EXPLAIN.')
        with self.conn() as c:
            return pd.read_sql_query(q, c)
