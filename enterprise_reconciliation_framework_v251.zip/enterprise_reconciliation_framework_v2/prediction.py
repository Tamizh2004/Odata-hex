import re
import pandas as pd

def norm(x):
    return re.sub(r'[^a-z0-9]', '', str(x).strip().lower())

def _best_name_match(src, target):
    return norm(src) == norm(target)

def predict(db, schema, df, allowed_tables=None):
    """Rank only the tables explicitly selected by the user when allowed_tables is supplied."""
    candidates = allowed_tables if allowed_tables is not None else db.tables(schema)
    src_cols = list(df.columns)
    src_norm = {norm(x): x for x in src_cols}
    rows = []
    for table in candidates:
        meta = db.meta(schema, table)
        target_cols = meta['column_name'].tolist()
        target_norm = {norm(x): x for x in target_cols}
        matched_norm = sorted(set(src_norm) & set(target_norm))
        matched_source = [src_norm[x] for x in matched_norm]
        matched_target = [target_norm[x] for x in matched_norm]
        pk = meta.loc[meta['is_primary_key'].fillna(False), 'column_name'].tolist()
        pk_norm = {norm(x) for x in pk}
        pk_hits = sorted(set(matched_norm) & pk_norm)

        overlap = len(matched_norm) / max(len(src_cols), 1)
        coverage = len(matched_norm) / max(len(target_cols), 1)
        key_score = len(pk_hits) / max(len(pk_norm), 1) if pk_norm else 0.0
        # Name overlap is the main signal; PK agreement boosts confidence.
        score = 0.55 * overlap + 0.25 * coverage + 0.20 * key_score
        rows.append({
            'table': table,
            'confidence': round(score * 100, 1),
            'matching_columns': len(matched_norm),
            'matched_source_columns': ', '.join(matched_source[:30]),
            'matched_target_columns': ', '.join(matched_target[:30]),
            'primary_key_columns': len(pk),
            'source_pk_hits': len(pk_hits),
            'primary_key_columns_list': ', '.join(pk),
        })
    if not rows:
        return pd.DataFrame(columns=['table','confidence','matching_columns','matched_source_columns','matched_target_columns','primary_key_columns','source_pk_hits','primary_key_columns_list'])
    return pd.DataFrame(rows).sort_values(
        ['confidence','matching_columns','source_pk_hits','primary_key_columns'],
        ascending=False
    ).reset_index(drop=True)
