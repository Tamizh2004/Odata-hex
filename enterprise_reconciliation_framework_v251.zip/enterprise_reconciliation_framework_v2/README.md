# Enterprise Data Reconciliation Framework v3

## Windows: easiest way

**Double-click `START_HERE.bat`.**

It will:
1. Check for Python 3.
2. Create `.venv` automatically if needed.
3. Install/update the packages from `requirements.txt`.
4. Start Streamlit.
5. Open/use `http://localhost:8501`.

Keep the black command window open while using the application.

## PostgreSQL defaults

- Host: `localhost`
- Port: `5434`
- Database: `OperationsDataMart`
- Username: `dbadmin`
- Password: enter it in the sidebar

If your SSH/tunnel endpoint is `localhost:13391`, change only the port in the sidebar.

## Correct workflow

1. **File Upload** — upload CSV/Excel/Parquet.
2. **Connect** — authenticate against PostgreSQL. The app does not call a connection successful just because a port is open.
3. **Auto Table Prediction** — choose the schema.
4. Filter the table list if needed.
5. **Select the exact tables you want considered.** Prediction is restricted to those tables only.
6. Run prediction.
7. Select the final table from the prediction results.
8. Click **Proceed with Selected Table**.
9. **Column Mapping**, **CSV ↔ PostgreSQL**, Query Generator and downstream workflow are then locked to that approved table.

## Safety

The current build is read-only. SQL console accepts SELECT/WITH/SHOW/EXPLAIN only. No insert/update/delete/drop/truncate operation is performed.

## Excel export

Timezone-aware timestamps are converted to timezone-naive timestamps before Excel export, avoiding pandas/openpyxl's `Excel does not support datetimes with timezones` error.

## Notes

The prediction engine is deterministic metadata matching, not an external AI service. It scores column-name overlap, target coverage and primary-key agreement.
