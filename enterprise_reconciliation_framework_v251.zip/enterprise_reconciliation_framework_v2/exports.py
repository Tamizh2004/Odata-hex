import io
import pandas as pd

def safe(df):
    x = df.copy()
    for c in x.columns:
        s = x[c]
        if pd.api.types.is_datetime64tz_dtype(s):
            x[c] = s.dt.tz_localize(None)
        elif s.dtype == 'object':
            def clean(v):
                if isinstance(v, pd.Timestamp) and v.tzinfo is not None:
                    return v.tz_localize(None)
                return v
            x[c] = s.map(clean)
    return x

def excel_bytes(df):
    b = io.BytesIO()
    with pd.ExcelWriter(b, engine='openpyxl') as w:
        safe(df).to_excel(w, index=False, sheet_name='Data')
    return b.getvalue()

def csv_bytes(df):
    return df.to_csv(index=False).encode('utf-8-sig')
