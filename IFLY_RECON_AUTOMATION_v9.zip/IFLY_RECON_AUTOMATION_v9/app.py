from pathlib import Path
import tempfile, zipfile
import pandas as pd
import streamlit as st
from reconcile import read_table, choose_default_keys, run_reconciliation

st.set_page_config(page_title="iFly → ODH Reconciliation", page_icon="🔎", layout="centered")
st.title("iFly → ODH Reconciliation")
st.caption("Step 1 iFly → Step 3 ODH → Parquet comparison → Step 4 + Step 5")

step1 = st.file_uploader("Step 1 — iFly", type=["csv", "parquet"])
step3 = st.file_uploader("Step 3 — ODH", type=["csv", "parquet"])

if not step1 or not step3:
    st.info("Upload the Step 1 iFly file and Step 3 ODH file.")
    st.stop()

with tempfile.TemporaryDirectory() as tmp:
    td = Path(tmp)
    p1, p3 = td / step1.name, td / step3.name
    p1.write_bytes(step1.getbuffer()); p3.write_bytes(step3.getbuffer())
    try:
        d1, d3 = read_table(p1), read_table(p3)
    except Exception as e:
        st.error(f"Unable to read input: {e}"); st.stop()

    common = [c for c in d1.columns if c in d3.columns]
    default = choose_default_keys(common)
    with st.expander("Match key", expanded=False):
        keys = st.multiselect("Select the business key used to identify the same record", common, default=default)
        st.caption("The key must identify exactly one record in each file. The framework will stop rather than create false many-to-many matches.")

    event_type = st.text_input("Event type", value=Path(step1.name).stem.upper())

    if st.button("Run reconciliation", type="primary", use_container_width=True):
        if not keys:
            st.error("Select at least one match-key field."); st.stop()
        try:
            out = td / "output"
            files, summary, detail, changes, changes_type = run_reconciliation(p1, p3, out, keys, event_type)
            st.success("Comparison completed.")
            st.dataframe(summary, use_container_width=True, hide_index=True)

            # No changes-only file: Step 5 contains MATCH/UPDATE/INSERT/DELETE.
            bundle = td / "iFly_ODH_reconciliation_results.zip"
            with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as z:
                for name in ["step1_ifly.parquet", "step3_odh.parquet", "step4_recon_stats_summary.csv", "step4_recon_detailed_results.csv", "step5_value_only_comparison.csv", "step5_datatype_comparison.csv"]:
                    z.write(out / name, arcname=name)
            st.download_button("Download results", bundle.read_bytes(), bundle.name, "application/zip", use_container_width=True)
            st.caption("Step 5 includes two CSVs: value-only comparison and datatype-aware comparison.")
        except Exception as e:
            st.error(str(e))
