# IFLY ODH Reconciliation Automation

Minimal Streamlit automation for the required flow:

1. Upload Step 1 (iFly) and Step 3 (ODH).
2. Convert both inputs to Step 1 / Step 3 Parquet.
3. Compare the Parquet stages.
4. Generate Step 4 summary + detailed reconciliation reports.
5. Generate one Step 5 Match/Missed ODH report.

## Comparison rule

- Missing values, empty strings, and whitespace-only values are treated as the same **only when both sides are blank**.
- A literal `NULL` is a real value and is **not** treated as blank.
- Non-blank strings are compared exactly. For example, `ABC` and ` ABC ` are different.
- Numeric values such as `453` and `453.0` are considered equal when represented as numeric values.

The downloaded result ZIP contains only the required output files; the separate `step5_odh_changes_only.csv` file is not generated.

## Run

Windows: double-click `setup_and_run.bat`.

The setup script installs only prebuilt binary packages for dependencies, preventing PyArrow from falling back to a local C++/CMake build.
