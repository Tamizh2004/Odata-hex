from __future__ import annotations

import io
import json
import os
import re
import socket
import sqlite3
import time
from datetime import date, datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from rapidfuzz import fuzz
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import URL

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE / ".env")
DATA = BASE / "data"
REPORTS = BASE / os.getenv("REPORT_DIR", "reports")
BACKUPS = BASE / os.getenv("BACKUP_DIR", "backups")
for p in (DATA, REPORTS, BACKUPS):
    p.mkdir(exist_ok=True)

st.set_page_config(page_title="Enterprise Data Reconciliation", page_icon="🔄", layout="wide")

# -----------------------------------------------------------------------------
# Session state
# -----------------------------------------------------------------------------
DEFAULTS = {
    "engine": None,
    "conn": None,
    "available_databases": [],
    "file_df": None,
    "file_name": None,
    "file_names": [],
    "file_count": 0,
    "schema": None,
    "table": None,
    "mapping": None,
    "comparison": None,
    "recommendations": None,
    "sql": [],
    "approved": False,
    "execution": None,
    "last_profile": None,
    "last_connection_error": None,
    "prediction": None,
}
for k, v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

# -----------------------------------------------------------------------------
# PostgreSQL connection
# -----------------------------------------------------------------------------
def target_config() -> dict:
    return {
        "host": os.getenv("ERF_PG_HOST", "localhost"),
        "port": int(os.getenv("ERF_PG_PORT", "5434")),
        "database": os.getenv("ERF_PG_DATABASE", "OperationsDataMart"),
        "username": os.getenv("ERF_PG_USER", "dbadmin"),
        "password": os.getenv("ERF_PG_PASSWORD", ""),
    }


def tcp_probe(host: str, port: int) -> tuple[bool, float | None]:
    started = time.perf_counter()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(float(os.getenv("ERF_PROBE_TIMEOUT", "0.45")))
    try:
        s.connect((host, int(port)))
        return True, round((time.perf_counter() - started) * 1000, 2)
    except OSError:
        return False, None
    finally:
        s.close()


@st.cache_data(ttl=5, show_spinner=False)
def endpoint_status(host: str, port: int) -> dict:
    probe_host = "127.0.0.1" if host in {"localhost", "127.0.0.1"} else host
    ok, latency = tcp_probe(probe_host, port)
    return {"reachable": ok, "latency_ms": latency, "host": host, "port": port}


def make_engine(cfg: dict, database: str | None = None):
    database = database or cfg["database"]
    url = URL.create(
        drivername="postgresql+psycopg2",
        username=str(cfg["username"]),
        password=str(cfg["password"]),
        host=str(cfg["host"]),
        port=int(cfg["port"]),
        database=str(database),
    )
    return create_engine(
        url,
        pool_pre_ping=True,
        pool_recycle=300,
        pool_size=2,
        max_overflow=3,
        connect_args={"connect_timeout": int(float(os.getenv("ERF_CONNECT_TIMEOUT", "5")))},
    )


def safe_error(exc: Exception) -> str:
    msg = str(exc)
    # Never display the configured secret if a driver includes a URL in an error.
    pw = target_config().get("password", "")
    if pw:
        msg = msg.replace(pw, "***")
    return msg[:2500]


def pg_info(engine) -> dict:
    started = time.perf_counter()
    with engine.connect() as c:
        row = dict(
            c.execute(
                text(
                    """
                    SELECT current_database() AS database,
                           current_user AS current_user,
                           version() AS version,
                           inet_server_addr()::text AS server_addr,
                           inet_server_port() AS server_port
                    """
                )
            ).mappings().one()
        )
    row["latency_ms"] = round((time.perf_counter() - started) * 1000, 2)
    return row


def connect_to_database(database: str | None = None):
    cfg = target_config()
    probe = endpoint_status(cfg["host"], cfg["port"])
    if not probe["reachable"]:
        return None, {
            "ok": False,
            "stage": "network",
            "error": f"PostgreSQL endpoint {cfg['host']}:{cfg['port']} is not reachable.",
            "probe": probe,
        }
    if not cfg["username"] or not cfg["password"]:
        return None, {
            "ok": False,
            "stage": "credentials",
            "error": "PostgreSQL username/password is not configured in the local .env file.",
            "probe": probe,
        }
    database = database or cfg["database"]
    engine = None
    try:
        engine = make_engine(cfg, database)
        info = pg_info(engine)
        info.update(
            {
                "host": cfg["host"],
                "port": cfg["port"],
                "configured_database": database,
                "configured_username": cfg["username"],
                "connection_mode": "Dedicated OperationsDataMart configuration",
            }
        )
        return engine, {"ok": True, **info}
    except Exception as exc:
        if engine is not None:
            engine.dispose()
        return None, {
            "ok": False,
            "stage": "authentication_or_postgres",
            "error": safe_error(exc),
            "probe": probe,
            "database": database,
            "username": cfg["username"],
        }


def ensure_connection() -> bool:
    if st.session_state.engine is not None:
        try:
            info = pg_info(st.session_state.engine)
            st.session_state.conn = {
                "host": target_config()["host"],
                "port": info.get("server_port") or target_config()["port"],
                **info,
            }
            return True
        except Exception:
            try:
                st.session_state.engine.dispose()
            except Exception:
                pass
            st.session_state.engine = None
            st.session_state.conn = None

    engine, result = connect_to_database()
    st.session_state.last_connection_error = None if result.get("ok") else result
    if engine is None:
        return False
    st.session_state.engine = engine
    st.session_state.conn = result
    try:
        st.session_state.available_databases = list_databases(engine)
    except Exception:
        st.session_state.available_databases = []
    audit(
        "CONNECT",
        "SUCCESS",
        json.dumps(
            {
                "host": result.get("host"),
                "port": result.get("port"),
                "database": result.get("database"),
                "latency_ms": result.get("latency_ms"),
            }
        ),
    )
    return True


def switch_database(database: str) -> bool:
    engine, result = connect_to_database(database)
    if engine is None:
        st.session_state.last_connection_error = result
        return False
    old = st.session_state.engine
    st.session_state.engine = engine
    st.session_state.conn = result
    st.session_state.schema = None
    st.session_state.table = None
    st.session_state.mapping = None
    st.session_state.comparison = None
    st.session_state.prediction = None
    try:
        st.session_state.available_databases = list_databases(engine)
    except Exception:
        pass
    try:
        if old is not None:
            old.dispose()
    except Exception:
        pass
    return True


# -----------------------------------------------------------------------------
# PostgreSQL metadata and table access
# -----------------------------------------------------------------------------
SYSTEM_SCHEMAS = {"pg_catalog", "information_schema"}


def qid(value: str) -> str:
    return '"' + str(value).replace('"', '""') + '"'


def list_databases(engine) -> list[str]:
    return pd.read_sql(
        text("SELECT datname FROM pg_database WHERE datallowconn=true ORDER BY datname"), engine
    )["datname"].tolist()


def user_schemas(engine) -> list[str]:
    df = pd.read_sql(
        text(
            """
            SELECT n.nspname AS schema_name,
                   COUNT(c.oid) FILTER (WHERE c.relkind='r') AS table_count
            FROM pg_namespace n
            LEFT JOIN pg_class c ON c.relnamespace=n.oid
            WHERE n.nspname NOT IN ('pg_catalog','information_schema')
              AND n.nspname NOT LIKE 'pg_toast%'
              AND n.nspname NOT LIKE 'pg_temp_%'
            GROUP BY n.nspname
            ORDER BY CASE WHEN n.nspname='public' THEN 0 ELSE 1 END, n.nspname
            """
        ),
        engine,
    )
    return df["schema_name"].astype(str).tolist()


def schema_table_counts(engine) -> pd.DataFrame:
    return pd.read_sql(
        text(
            """
            SELECT n.nspname AS schema_name,
                   COUNT(c.oid) FILTER (WHERE c.relkind='r')::int AS tables,
                   COUNT(c.oid) FILTER (WHERE c.relkind IN ('v','m'))::int AS views
            FROM pg_namespace n
            LEFT JOIN pg_class c ON c.relnamespace=n.oid
            WHERE n.nspname NOT IN ('pg_catalog','information_schema')
              AND n.nspname NOT LIKE 'pg_toast%'
              AND n.nspname NOT LIKE 'pg_temp_%'
            GROUP BY n.nspname
            ORDER BY CASE WHEN n.nspname='public' THEN 0 ELSE 1 END, n.nspname
            """
        ),
        engine,
    )


def tables(engine, schema: str) -> list[str]:
    return pd.read_sql(
        text(
            """
            SELECT c.relname AS table_name
            FROM pg_class c
            JOIN pg_namespace n ON n.oid=c.relnamespace
            WHERE n.nspname=:schema
              AND c.relkind='r'
              AND NOT c.relispartition
            ORDER BY c.relname
            """
        ),
        engine,
        params={"schema": schema},
    )["table_name"].astype(str).tolist()


def all_user_tables(engine) -> pd.DataFrame:
    return pd.read_sql(
        text(
            """
            SELECT n.nspname AS schema_name, c.relname AS table_name
            FROM pg_class c
            JOIN pg_namespace n ON n.oid=c.relnamespace
            WHERE c.relkind='r'
              AND NOT c.relispartition
              AND n.nspname NOT IN ('pg_catalog','information_schema')
              AND n.nspname NOT LIKE 'pg_toast%'
              AND n.nspname NOT LIKE 'pg_temp_%'
            ORDER BY CASE WHEN n.nspname='public' THEN 0 ELSE 1 END,
                     n.nspname, c.relname
            """
        ),
        engine,
    )


def metadata(engine, schema: str, table: str):
    ins = inspect(engine)
    cols = ins.get_columns(table, schema=schema)
    pk = ins.get_pk_constraint(table, schema=schema).get("constrained_columns", []) or []
    idx = ins.get_indexes(table, schema=schema) or []
    return cols, pk, idx


def count_rows(engine, schema: str, table: str) -> int:
    with engine.connect() as c:
        return int(c.execute(text(f"SELECT COUNT(*) FROM {qid(schema)}.{qid(table)}")).scalar())


def read_table(engine, schema: str, table: str, limit: int = 500, offset: int = 0, order_cols=None):
    order_cols = order_cols or []
    order_sql = ", ".join(qid(x) for x in order_cols)
    if not order_sql:
        order_sql = "1"
    sql = text(
        f"SELECT * FROM {qid(schema)}.{qid(table)} ORDER BY {order_sql} LIMIT :n OFFSET :o"
    )
    return pd.read_sql(sql, engine, params={"n": int(limit), "o": int(offset)})


def table_columns(engine, schema: str, table: str) -> list[str]:
    cols, _, _ = metadata(engine, schema, table)
    return [str(c["name"]) for c in cols]


# -----------------------------------------------------------------------------
# Files / profiling / mapping
# -----------------------------------------------------------------------------
def load_upload(f):
    """Load one uploaded source file without changing the PostgreSQL workflow."""
    n = f.name.lower()
    if n.endswith(".csv"):
        return pd.read_csv(f)
    if n.endswith((".xlsx", ".xls")):
        return pd.read_excel(f)
    if n.endswith(".parquet"):
        return pd.read_parquet(f)
    if n.endswith(".json"):
        return pd.read_json(f)
    raise ValueError("Unsupported file type.")


def load_multiple_uploads(files):
    """Combine multiple uploaded files into one reconciliation source.

    Files with the same logical schema are appended row-wise. If a file has a
    missing column, pandas preserves the column and fills that file's rows with
    nulls. The original filename is retained separately for audit/display and
    is never injected into the reconciliation columns.
    """
    frames = []
    names = []
    for f in files:
        df = load_upload(f)
        # Normalize duplicate column labels so mapping/comparison remains stable.
        if df.columns.duplicated().any():
            seen = {}
            new_cols = []
            for col in map(str, df.columns):
                n = seen.get(col, 0)
                new_cols.append(col if n == 0 else f"{col}.{n}")
                seen[col] = n + 1
            df.columns = new_cols
        else:
            df.columns = [str(c) for c in df.columns]
        frames.append(df)
        names.append(f.name)
    if not frames:
        raise ValueError("Select at least one source file.")
    combined = pd.concat(frames, ignore_index=True, sort=False)
    return combined, names


def profile(df: pd.DataFrame) -> dict:
    rows = []
    for c in df.columns:
        s = df[c]
        rows.append(
            {
                "column": c,
                "dtype": str(s.dtype),
                "null_count": int(s.isna().sum()),
                "null_pct": round(float(s.isna().mean() * 100), 2),
                "unique": int(s.nunique(dropna=True)),
                "sample": ", ".join(map(str, s.dropna().head(3).tolist())),
            }
        )
    null_pct = 100 * df.isna().sum().sum() / max(df.size, 1)
    dup = int(df.duplicated().sum())
    quality = max(0, 100 - null_pct - (dup / max(len(df), 1)) * 100)
    return {
        "rows": len(df),
        "columns": len(df.columns),
        "nulls": int(df.isna().sum().sum()),
        "duplicates": dup,
        "missing_pct": round(null_pct, 2),
        "quality": round(quality, 2),
        "columns_df": pd.DataFrame(rows),
    }


def norm(x) -> str:
    return re.sub(r"[^a-z0-9]", "", str(x).lower())


def best_column_match(source: str, targets: list[str]):
    best = ("", 0.0, "Unmapped")
    for target in targets:
        a, b = norm(source), norm(target)
        if a == b:
            score, method = 100.0, "Exact Match"
        else:
            score = float(fuzz.ratio(a, b))
            method = "Fuzzy Match"
        if score > best[1]:
            best = (target, score, method)
    return best


def auto_mapping(src, target):
    used = set()
    out = []
    for s in src:
        candidates = [t for t in target if t not in used]
        best, score, method = best_column_match(s, candidates)
        if score < 62:
            best, method = "", "Unmapped"
        else:
            used.add(best)
        out.append(
            {
                "source_column": s,
                "target_column": best,
                "confidence": round(score, 1),
                "method": method,
            }
        )
    return pd.DataFrame(out)


# -----------------------------------------------------------------------------
# Prediction
# -----------------------------------------------------------------------------
def predict_target_tables(engine, source_columns: list[str], limit: int = 25, source_name: str = "") -> pd.DataFrame:
    """Fast, explainable target-table prediction using PostgreSQL catalog metadata.

    The predictor deliberately does not read table data. It scores exact column overlap,
    one-to-one fuzzy matches, primary-key coverage and source/table-name similarity.
    This keeps prediction fast even when the target tables are large.
    """
    catalog = pd.read_sql(
        text(
            """
            SELECT
                c.oid AS table_oid,
                n.nspname AS schema_name,
                c.relname AS table_name,
                a.attname AS column_name,
                a.attnum AS ordinal_position,
                EXISTS (
                    SELECT 1
                    FROM pg_index i
                    WHERE i.indrelid=c.oid AND i.indisprimary
                      AND a.attnum = ANY(i.indkey)
                ) AS is_primary_key
            FROM pg_class c
            JOIN pg_namespace n ON n.oid=c.relnamespace
            JOIN pg_attribute a ON a.attrelid=c.oid
            WHERE c.relkind='r'
              AND a.attnum > 0
              AND NOT a.attisdropped
              AND NOT c.relispartition
              AND n.nspname NOT IN ('pg_catalog','information_schema')
              AND n.nspname NOT LIKE 'pg_toast%'
              AND n.nspname NOT LIKE 'pg_temp_%'
            ORDER BY CASE WHEN n.nspname='public' THEN 0 ELSE 1 END,
                     n.nspname, c.relname, a.attnum
            """
        ),
        engine,
    )
    columns = ["schema", "table", "confidence", "exact_matches", "matching_columns",
               "primary_key", "target_columns", "matched_source_columns", "unmatched_source_columns",
               "reason"]
    if catalog.empty:
        return pd.DataFrame(columns=columns)

    source_columns = [str(c) for c in source_columns]
    source_norm = {norm(c): c for c in source_columns if norm(c)}
    source_stem = norm(Path(source_name).stem) if source_name else ""
    rows = []

    for (schema_name, table_name), g in catalog.groupby(["schema_name", "table_name"], sort=False):
        cols = g["column_name"].astype(str).tolist()
        target_norm = {norm(c): c for c in cols if norm(c)}
        exact_pairs = []
        used_targets = set()

        # Exact normalized matches are one-to-one.
        for ns, src in source_norm.items():
            tgt = target_norm.get(ns)
            if tgt and tgt not in used_targets:
                exact_pairs.append((src, tgt, 100.0, "Exact"))
                used_targets.add(tgt)

        # Fuzzy matching is also one-to-one, so duplicate source columns cannot inflate score.
        fuzzy_pairs = []
        for src in source_columns:
            if any(src == x[0] for x in exact_pairs):
                continue
            best_t, best_s, _ = best_column_match(src, [t for t in cols if t not in used_targets])
            if best_t and best_s >= 72:
                fuzzy_pairs.append((src, best_t, float(best_s), "Fuzzy"))
                used_targets.add(best_t)

        pairs = exact_pairs + fuzzy_pairs
        exact_ratio = len(exact_pairs) / max(len(source_columns), 1)
        fuzzy_ratio = len(fuzzy_pairs) / max(len(source_columns), 1)
        coverage = len(pairs) / max(len(source_columns), 1)
        avg_pair_score = sum(x[2] for x in pairs) / max(len(pairs), 1)

        # Source filename/table-name similarity helps when column names are abbreviated or generic.
        table_n = norm(table_name)
        name_score = float(fuzz.ratio(source_stem, table_n)) if source_stem and table_n else 0.0
        table_token_score = 0.0
        for src in source_columns:
            ns = norm(src)
            if ns and table_n:
                table_token_score = max(table_token_score, float(fuzz.ratio(ns, table_n)))

        pk = g.loc[g["is_primary_key"], "column_name"].astype(str).tolist()
        pk_norm = {norm(x) for x in pk}
        pk_hits = sum(1 for _, tgt, _, _ in pairs if norm(tgt) in pk_norm)
        pk_ratio = pk_hits / max(len(pk), 1) if pk else 0.0

        confidence = (
            0.50 * exact_ratio * 100
            + 0.18 * fuzzy_ratio * 100
            + 0.17 * coverage * 100
            + 0.10 * avg_pair_score
            + 0.03 * max(name_score, table_token_score)
        )
        # A table with an exact primary/business key deserves a small deterministic boost.
        confidence += min(7.0, pk_ratio * 7.0)
        confidence = round(min(100.0, confidence), 1)

        matched_src = [x[0] for x in pairs]
        unmatched = [c for c in source_columns if c not in matched_src]
        display = ", ".join(f"{s}→{t} ({m})" for s, t, _, m in sorted(pairs, key=lambda x: x[2], reverse=True)[:12])
        reasons = []
        if exact_pairs:
            reasons.append(f"{len(exact_pairs)} exact")
        if fuzzy_pairs:
            reasons.append(f"{len(fuzzy_pairs)} fuzzy")
        if pk_hits:
            reasons.append(f"{pk_hits} PK match")
        if name_score >= 70:
            reasons.append(f"filename/table similarity {round(name_score)}%")
        reason = "; ".join(reasons) if reasons else "low column overlap"

        rows.append({
            "schema": str(schema_name),
            "table": str(table_name),
            "confidence": confidence,
            "exact_matches": len(exact_pairs),
            "matching_columns": display or "—",
            "primary_key": ", ".join(pk) or "",
            "target_columns": len(cols),
            "matched_source_columns": len(matched_src),
            "unmatched_source_columns": len(unmatched),
            "reason": reason,
        })

    return (
        pd.DataFrame(rows, columns=columns)
        .sort_values(["confidence", "exact_matches", "matched_source_columns"], ascending=[False, False, False])
        .head(limit)
        .reset_index(drop=True)
    )


# -----------------------------------------------------------------------------
# Reconciliation / SQL
# -----------------------------------------------------------------------------
def _compare_value(v):
    """Normalize common PostgreSQL/Pandas values so timestamps and nulls compare safely."""
    if pd.isna(v):
        return None
    if isinstance(v, pd.Timestamp):
        if v.tzinfo is not None:
            v = v.tz_convert("UTC").tz_localize(None)
        return v.to_pydatetime()
    if isinstance(v, datetime):
        if v.tzinfo is not None:
            return v.astimezone(timezone.utc).replace(tzinfo=None)
        return v
    if isinstance(v, date):
        return v
    if isinstance(v, (np.integer, np.floating)):
        return v.item()
    return v


def _values_equal(a, b) -> bool:
    a, b = _compare_value(a), _compare_value(b)
    if a is None or b is None:
        return a is None and b is None
    try:
        result = a == b
        if isinstance(result, (bool, np.bool_)):
            return bool(result)
    except Exception:
        pass
    return str(a) == str(b)


def compare(src, tgt, mapping, keys):
    mp = {r.source_column: r.target_column for r in mapping.itertuples() if r.target_column}
    s = src.rename(columns=mp).copy()
    t = tgt.copy()
    common = [c for c in s.columns if c in t.columns]
    keys = [k for k in keys if k in common]
    if not keys:
        raise ValueError("Select at least one valid primary/business key.")
    s = s.drop_duplicates(keys, keep="last")
    t = t.drop_duplicates(keys, keep="last")
    si, ti = s.set_index(keys, drop=False), t.set_index(keys, drop=False)
    sk, tk = set(si.index.tolist()), set(ti.index.tolist())
    inserts = sorted(sk - tk, key=str)
    deletes = sorted(tk - sk, key=str)
    shared = sorted(sk & tk, key=str)
    diffs, updates = [], []
    for key in shared:
        sr, tr = si.loc[key], ti.loc[key]
        if isinstance(sr, pd.DataFrame):
            sr = sr.iloc[-1]
        if isinstance(tr, pd.DataFrame):
            tr = tr.iloc[-1]
        changed = False
        for c in common:
            if c in keys:
                continue
            a, b = sr[c], tr[c]
            if not _values_equal(a, b):
                changed = True
                diffs.append({
                    **{k: _compare_value(sr[k]) for k in keys},
                    "column": c,
                    "source_value": _compare_value(a),
                    "database_value": _compare_value(b),
                    "status": "UPDATE REQUIRED",
                })
        if changed:
            updates.append(key)
    return {
        "source": len(s), "target": len(t), "matched": len(shared) - len(updates),
        "insert": len(inserts), "update": len(updates), "delete": len(deletes),
        "keys": keys, "insert_keys": inserts, "delete_keys": deletes,
        "differences": pd.DataFrame(diffs), "source_df": s, "target_df": t,
    }


def recommendations(diff):
    if diff.empty:
        return diff
    rec = []
    for _, r in diff.iterrows():
        a, b = r.source_value, r.database_value
        if pd.isna(b) and not pd.isna(a):
            rec.append(("Use CSV Value", "DB is null; source has value", 88))
        elif pd.isna(a) and not pd.isna(b):
            rec.append(("Use Database Value", "Source is null; DB has value", 88))
        else:
            rec.append(("Manual Review", "Both values exist; timestamp/business rule required", 55))
    return pd.concat(
        [diff.reset_index(drop=True), pd.DataFrame(rec, columns=["recommendation", "reason", "confidence"])],
        axis=1,
    )


def sql_lit(v):
    if pd.isna(v):
        return "NULL"
    if isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, bool):
        return str(v)
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    return "'" + str(v).replace("'", "''") + "'"


# -----------------------------------------------------------------------------
# Audit / helpers
# -----------------------------------------------------------------------------
AUDIT = DATA / "audit.sqlite3"


def audit_init():
    c = sqlite3.connect(AUDIT)
    c.execute(
        """CREATE TABLE IF NOT EXISTS audit(
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, database_name TEXT,
        schema_name TEXT, table_name TEXT, action TEXT, status TEXT, details TEXT)"""
    )
    c.commit()
    c.close()


def audit(action, status, details=""):
    audit_init()
    c = sqlite3.connect(AUDIT)
    c.execute(
        "INSERT INTO audit(ts,database_name,schema_name,table_name,action,status,details) VALUES(?,?,?,?,?,?,?)",
        (
            datetime.now(timezone.utc).isoformat(),
            (st.session_state.conn or {}).get("database", ""),
            st.session_state.schema or "",
            st.session_state.table or "",
            action,
            status,
            details,
        ),
    )
    c.commit()
    c.close()


def audit_df():
    audit_init()
    c = sqlite3.connect(AUDIT)
    d = pd.read_sql_query("SELECT * FROM audit ORDER BY id DESC LIMIT 2000", c)
    c.close()
    return d


def header(title, subtitle):
    st.title(title)
    st.caption(subtitle)


def helpbox(steps):
    with st.expander("🧭 How to use this page", expanded=True):
        for i, s in enumerate(steps, 1):
            st.markdown(f"**{i}.** {s}")


def metrics(items):
    cs = st.columns(len(items))
    for c, (a, b) in zip(cs, items):
        c.metric(a, b)


def excel_safe_df(df: pd.DataFrame) -> pd.DataFrame:
    """Return an Excel-safe copy; Excel/XLSX cannot store timezone-aware datetimes."""
    out = df.copy()
    for col in out.columns:
        s = out[col]
        try:
            if isinstance(s.dtype, pd.DatetimeTZDtype):
                out[col] = s.dt.tz_convert("UTC").dt.tz_localize(None)
                continue
        except Exception:
            pass
        if s.dtype == "object":
            def clean(v):
                if isinstance(v, pd.Timestamp):
                    return (v.tz_convert("UTC").tz_localize(None) if v.tzinfo is not None else v)
                if isinstance(v, datetime) and v.tzinfo is not None:
                    return v.astimezone(timezone.utc).replace(tzinfo=None)
                return v
            out[col] = s.map(clean)
    return out


def dl(df, label, name, kind="csv"):
    if kind == "csv":
        data, mime = df.to_csv(index=False).encode("utf-8"), "text/csv"
    elif kind == "json":
        data, mime = df.to_json(orient="records", date_format="iso").encode("utf-8"), "application/json"
    elif kind == "xlsx":
        b = io.BytesIO()
        safe = excel_safe_df(df)
        with pd.ExcelWriter(b, engine="xlsxwriter", datetime_format="yyyy-mm-dd hh:mm:ss") as w:
            safe.to_excel(w, index=False, sheet_name="Data")
            ws = w.sheets["Data"]
            ws.freeze_panes(1, 0)
            if len(safe.columns):
                ws.autofilter(0, 0, max(len(safe), 1), len(safe.columns) - 1)
                for i, col in enumerate(safe.columns):
                    sample = safe[col].head(100).fillna("").astype("string").str.len().max() if len(safe) else 0
                    sample = int(sample) if pd.notna(sample) else 0
                    width = min(50, max(10, len(str(col)) + 2, int(sample) + 2))
                    ws.set_column(i, i, width)
        data, mime = b.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    else:
        raise ValueError(f"Unsupported export type: {kind}")
    st.download_button(label, data, name, mime, key=f"dl_{name}_{kind}")


# -----------------------------------------------------------------------------
# Navigation / automatic connection
# -----------------------------------------------------------------------------
PAGES = [
    "🏠 Dashboard", "🔌 Connection Status", "🗄️ Database Explorer", "📊 Table Data Explorer",
    "⌨️ SQL Console", "📁 File Upload", "🔎 Data Profiling", "🎯 Auto Table Prediction",
    "🔗 Column Mapping", "⚖️ CSV ↔ PostgreSQL", "🔄 CSV → Parquet → PostgreSQL",
    "🧩 Difference Viewer", "🤖 AI Recommendations", "🧾 Query Generator", "✅ Approval Center",
    "⚙️ Execution Center", "↩️ Rollback Center", "📜 Audit History", "📑 Reports", "⚙️ Settings",
]

# Connect once automatically so every page has the same working session.
if st.session_state.engine is None:
    ensure_connection()

with st.sidebar:
    st.markdown("## 🔄 Enterprise Reconciliation")
    if st.session_state.conn:
        st.success(
            f"Connected\n{st.session_state.conn.get('host', 'localhost')}:{st.session_state.conn.get('port')}\n"
            f"{st.session_state.conn.get('database', '')}"
        )
    else:
        cfg = target_config()
        probe = endpoint_status(cfg["host"], cfg["port"])
        st.error(f"PostgreSQL unavailable\n{cfg['host']}:{cfg['port']}")
        if st.button("🔄 Retry Connection"):
            st.session_state.engine = None
            st.rerun()
    page = st.radio("Navigation", PAGES, label_visibility="collapsed")
    st.divider()
    st.caption("AWS SSM is external. The framework only uses the local PostgreSQL tunnel.")

# -----------------------------------------------------------------------------
# Pages
# -----------------------------------------------------------------------------
if page == "🏠 Dashboard":
    header("🏠 Dashboard", "Enterprise control center for PostgreSQL reconciliation and governed data changes.")
    helpbox([
        "Start the external SSM/local tunnel before launching the app.",
        "The application automatically connects to OperationsDataMart.",
        "Upload and profile source data.",
        "Predict → map → compare → review → approve → execute → audit.",
    ])
    if st.session_state.engine and st.session_state.conn:
        try:
            ds = list_databases(st.session_state.engine)
            sc = schema_table_counts(st.session_state.engine)
            metrics([
                ("Connected DB", st.session_state.conn["database"]),
                ("Databases", len(ds)),
                ("User Schemas", len(sc)),
                ("Tables", int(sc["tables"].sum()) if not sc.empty else 0),
                ("Uploaded Files", 1 if st.session_state.file_df is not None else 0),
            ])
            st.subheader("Schema Overview")
            st.dataframe(sc, use_container_width=True, hide_index=True)
        except Exception as e:
            st.error(safe_error(e))
    else:
        st.error("PostgreSQL connection is not active.")
    c = st.session_state.comparison
    if c:
        st.subheader("Comparison Metrics")
        metrics([("Matched", c["matched"]), ("Insert", c["insert"]), ("Update", c["update"]), ("Delete", c["delete"])])
    st.subheader("Recent Audit")
    st.dataframe(audit_df().head(10), use_container_width=True, hide_index=True)

elif page == "🔌 Connection Status":
    header("🔌 Connection Status", "Single shared PostgreSQL connection used by every framework page.")
    helpbox([
        "The app automatically checks the configured localhost tunnel.",
        "No credential form is displayed.",
        "Connection Status reuses the same SQLAlchemy engine as Dashboard and the explorers.",
    ])
    if st.button("🔄 Reconnect", type="primary"):
        if st.session_state.engine is not None:
            try:
                st.session_state.engine.dispose()
            except Exception:
                pass
        st.session_state.engine = None
        st.session_state.conn = None
        st.rerun()

    if st.session_state.conn:
        c = st.session_state.conn
        st.success(f"✅ Connected — {c.get('host')}:{c.get('port')} / {c.get('database')}")
        metrics([
            ("Database", c.get("database", "")),
            ("User", c.get("current_user", c.get("configured_username", ""))),
            ("Server Port", c.get("server_port", "")),
            ("Latency", f"{c.get('latency_ms', 0)} ms"),
        ])
        st.code(str(c.get("version", "")), language="text")
        try:
            dbs = list_databases(st.session_state.engine)
            st.session_state.available_databases = dbs
            st.subheader("Available Databases")
            st.dataframe(pd.DataFrame({"Database": dbs}), use_container_width=True, hide_index=True)
        except Exception as e:
            st.error(safe_error(e))
    else:
        cfg = target_config()
        result = st.session_state.last_connection_error or {}
        st.error(f"❌ {cfg['host']}:{cfg['port']} is not connected")
        if result:
            st.warning(result.get("error", "PostgreSQL connection failed."))
            st.info(f"Configured target: {cfg['host']}:{cfg['port']} / {cfg['database']} / {cfg['username']}")

elif page == "🗄️ Database Explorer":
    header("🗄️ Database Explorer", "Browse real PostgreSQL databases → user schemas → tables.")
    helpbox([
        "The current database is shown first.",
        "System schemas are hidden automatically.",
        "Choose a user schema to see its actual tables.",
        "Select a table to continue to Table Data Explorer, Mapping and Reconciliation.",
    ])
    if not st.session_state.engine:
        st.error("Connect to PostgreSQL first.")
    else:
        eng = st.session_state.engine
        ds = list_databases(eng)
        current_db = st.session_state.conn.get("database") if st.session_state.conn else None
        default_db_index = ds.index(current_db) if current_db in ds else 0
        selected_db = st.selectbox("Database", ds, index=default_db_index)
        if selected_db != current_db:
            st.warning(f"You selected {selected_db}, but the active connection is {current_db}.")
            if st.button(f"🔌 Switch connection to {selected_db}", type="primary"):
                if switch_database(selected_db):
                    st.success(f"Connected to {selected_db}.")
                    st.rerun()
                st.error(st.session_state.last_connection_error.get("error", "Database switch failed."))
        counts = schema_table_counts(eng)
        st.subheader("User Schemas")
        st.dataframe(counts, use_container_width=True, hide_index=True)
        ss = user_schemas(eng)
        if not ss:
            st.warning("No user schemas were found in this database.")
        else:
            preferred = st.session_state.schema if st.session_state.schema in ss else ("public" if "public" in ss else ss[0])
            st.session_state.schema = st.selectbox("Schema", ss, index=ss.index(preferred))
            ts = tables(eng, st.session_state.schema)
            search = st.text_input("🔎 Search tables", placeholder="Type part of a table name...")
            filtered = [t for t in ts if search.strip().lower() in t.lower()]
            st.caption(f"{len(filtered)} table(s) in {st.session_state.schema}")
            if filtered:
                current_table = st.session_state.table if st.session_state.table in filtered else filtered[0]
                st.session_state.table = st.selectbox("Table", filtered, index=filtered.index(current_table))
                cols, pk, idx = metadata(eng, st.session_state.schema, st.session_state.table)
                metrics([("Columns", len(cols)), ("Rows", count_rows(eng, st.session_state.schema, st.session_state.table)), ("Primary Keys", ", ".join(pk) or "None"), ("Indexes", len(idx))])
                st.success(f"Selected: {st.session_state.schema}.{st.session_state.table}")
                dl(pd.DataFrame({"schema": [st.session_state.schema] * len(filtered), "table": filtered}), "Export Table List", "tables.csv")
            else:
                st.info("No tables match the search in this schema. Try another schema.")

elif page == "📊 Table Data Explorer":
    header("📊 Table Data Explorer", "Fast, paginated PostgreSQL table browser with metadata and exports.")
    helpbox(["Select a table in Database Explorer.", "Choose page size and page.", "Inspect live rows and metadata.", "Export the visible page."])
    if not st.session_state.engine or not st.session_state.table or not st.session_state.schema:
        st.warning("Select a table first in Database Explorer.")
    else:
        eng, sc, tb = st.session_state.engine, st.session_state.schema, st.session_state.table
        cols, pk, idx = metadata(eng, sc, tb)
        total = count_rows(eng, sc, tb)
        metrics([("Rows", total), ("Columns", len(cols)), ("Primary Keys", ", ".join(pk) or "None"), ("Indexes", len(idx))])
        st.dataframe(pd.DataFrame(cols)[["name", "type", "nullable"]], use_container_width=True, hide_index=True)
        size = st.selectbox("Rows per page", [25, 50, 100, 200, 500], index=1)
        max_page = max(1, (total + size - 1) // size)
        pg = st.number_input("Page", min_value=1, max_value=max_page, value=1, step=1)
        df = read_table(eng, sc, tb, size, (pg - 1) * size, pk or [cols[0]["name"]] if cols else [])
        st.dataframe(df, use_container_width=True, hide_index=True)
        a, b, c = st.columns(3)
        with a:
            dl(df, "Export CSV", "table_page.csv", "csv")
        with b:
            dl(df, "Export Excel", "table_page.xlsx", "xlsx")
        with c:
            dl(df, "Export JSON", "table_page.json", "json")

elif page == "⌨️ SQL Console":
    header("⌨️ SQL Console", "Read-only SQL console for safe investigation.")
    helpbox(["Enter SELECT/WITH SQL.", "Run and inspect results.", "Export results.", "Writes remain blocked here."])
    if not st.session_state.engine:
        st.warning("Connect first.")
    else:
        sql = st.text_area("SQL", "SELECT current_database(), current_user;", height=160)
        if st.button("▶ Run SELECT", type="primary"):
            if not re.match(r"^\s*(select|with)\b", sql, re.I):
                st.error("Only SELECT/WITH is allowed.")
            else:
                try:
                    d = pd.read_sql(text(sql), st.session_state.engine)
                    st.dataframe(d, use_container_width=True)
                    dl(d, "Download CSV", "query.csv")
                    audit("SELECT", "SUCCESS", sql)
                except Exception as e:
                    audit("SELECT", "FAILED", safe_error(e))
                    st.error(safe_error(e))

elif page == "📁 File Upload":
    header("📁 File Upload", "Load one or more source files and combine them for reconciliation.")
    helpbox([
        "Select multiple CSV/Excel/Parquet/JSON files when the source is split across files.",
        "All selected files are combined row-wise into one reconciliation dataset.",
        "Columns missing from one file are preserved as nulls; the original filenames remain available for audit/display.",
    ])
    files = st.file_uploader(
        "Source files",
        type=["csv", "xlsx", "xls", "parquet", "json"],
        accept_multiple_files=True,
        help="You can select multiple files. They will be combined before mapping and comparison.",
    )
    if files:
        try:
            combined, names = load_multiple_uploads(files)
            st.session_state.file_df = combined
            st.session_state.file_names = names
            st.session_state.file_count = len(names)
            st.session_state.file_name = ", ".join(names)
            st.session_state.mapping = None
            st.session_state.comparison = None
            st.session_state.prediction = None
            p = profile(combined)
            metrics([
                ("Files", len(names)),
                ("Combined Records", p["rows"]),
                ("Columns", p["columns"]),
                ("Null Cells", p["nulls"]),
            ])
            st.caption("Combined files: " + " • ".join(names))
            st.dataframe(combined.head(100), use_container_width=True, hide_index=True)
        except Exception as e:
            st.error(safe_error(e))
    elif st.session_state.file_df is not None:
        st.info(f"Current source: {st.session_state.file_count or 1} file(s) • {st.session_state.file_name}")

elif page == "🔎 Data Profiling":
    header("🔎 Data Profiling", "Nulls, duplicates, unique values, types and quality scoring.")
    if st.session_state.file_df is None:
        st.warning("Upload a file first.")
    else:
        p = profile(st.session_state.file_df)
        st.session_state.last_profile = p
        metrics([("Records", p["rows"]), ("Columns", p["columns"]), ("Duplicates", p["duplicates"]), ("Missing %", p["missing_pct"]), ("Quality", f'{p["quality"]}%')])
        st.dataframe(p["columns_df"], use_container_width=True, hide_index=True)
        dl(p["columns_df"], "Download Profiling CSV", "profiling.csv")

elif page == "🎯 Auto Table Prediction":
    header("🎯 Auto Table Prediction", "Find likely PostgreSQL target tables from source-column similarity.")
    helpbox([
        "Upload a source file first.",
        "The predictor scans every non-system schema, not only information_schema/public.",
        "Exact column matches are weighted most strongly; fuzzy matches add coverage.",
        "Select the suggested schema/table manually before continuing.",
    ])
    if st.session_state.file_df is None or not st.session_state.engine:
        st.warning("Upload a source file and connect PostgreSQL first.")
    else:
        if st.button("🎯 Predict Target Tables", type="primary"):
            with st.spinner("Scanning PostgreSQL metadata and scoring candidate tables..."):
                d = predict_target_tables(
                    st.session_state.engine,
                    list(st.session_state.file_df.columns),
                    limit=30,
                    source_name=st.session_state.file_name or "",
                )
            st.session_state.prediction = d
        d = st.session_state.prediction
        if d is not None:
            if d.empty:
                st.warning("No user tables were found in the active database. Check Database Explorer first.")
            else:
                st.dataframe(d, use_container_width=True, hide_index=True)
                best = d.iloc[0]
                st.success(f"Best metadata match: {best['schema']}.{best['table']} • {best['confidence']}% • {best['reason']}")
                choice = st.selectbox(
                    "Target table to use",
                    d.apply(lambda r: f"{r['schema']}.{r['table']}", axis=1).tolist(),
                    index=0,
                )
                if st.button("➡️ Use Selected Target", type="primary"):
                    selected = d.iloc[d.apply(lambda r: f"{r['schema']}.{r['table']}", axis=1).tolist().index(choice)]
                    st.session_state.schema = str(selected["schema"])
                    st.session_state.table = str(selected["table"])
                    st.session_state.mapping = None
                    st.session_state.comparison = None
                    st.success(f"Selected {st.session_state.schema}.{st.session_state.table}. Continue to Column Mapping.")

elif page == "🔗 Column Mapping":
    header("🔗 Column Mapping", "Exact and fuzzy source-to-target mapping with manual override.")
    if st.session_state.file_df is None or not st.session_state.engine or not st.session_state.table:
        st.warning("Need source file, connection and selected target table.")
    else:
        cs, pk, _ = metadata(st.session_state.engine, st.session_state.schema, st.session_state.table)
        targets = [c["name"] for c in cs]
        st.caption(f"Target: {st.session_state.schema}.{st.session_state.table}")
        if st.button("🔗 Auto Map", type="primary"):
            st.session_state.mapping = auto_mapping(st.session_state.file_df.columns, targets)
        if st.session_state.mapping is not None:
            edit = st.data_editor(
                st.session_state.mapping,
                use_container_width=True,
                hide_index=True,
                column_config={"target_column": st.column_config.SelectboxColumn("Target Column", options=[""] + targets)},
            )
            if st.button("💾 Save Mapping"):
                st.session_state.mapping = edit
                st.success("Mapping saved.")

elif page == "⚖️ CSV ↔ PostgreSQL":
    header("⚖️ CSV ↔ PostgreSQL Comparison", "Compare source rows with the selected PostgreSQL table.")
    if st.session_state.file_df is None or not st.session_state.engine or not st.session_state.table or st.session_state.mapping is None:
        st.warning("Complete Upload → Table → Mapping first.")
    else:
        cs, pk, _ = metadata(st.session_state.engine, st.session_state.schema, st.session_state.table)
        target_cols = [c["name"] for c in cs]
        keys = st.multiselect("Primary/business keys", target_cols, default=[x for x in pk if x in target_cols])
        if st.button("⚖️ Run Comparison", type="primary"):
            try:
                total = count_rows(st.session_state.engine, st.session_state.schema, st.session_state.table)
                # No arbitrary 250k-row cutoff. Read the selected PostgreSQL table in
                # chunks so larger tables are handled without one huge DB fetch.
                chunk_size = int(os.getenv("ERF_COMPARE_CHUNK_SIZE", "50000"))
                parts = []
                progress = st.progress(0, text="Reading PostgreSQL rows…")
                if total == 0:
                    target = read_table(st.session_state.engine, st.session_state.schema, st.session_state.table, 1, 0, pk or target_cols[:1])
                else:
                    for offset in range(0, total, chunk_size):
                        parts.append(read_table(
                            st.session_state.engine,
                            st.session_state.schema,
                            st.session_state.table,
                            min(chunk_size, total - offset),
                            offset,
                            pk or target_cols[:1],
                        ))
                        progress.progress(min(1.0, (offset + len(parts[-1])) / total), text=f"Reading PostgreSQL rows… {min(offset + len(parts[-1]), total):,}/{total:,}")
                    target = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=target_cols)
                progress.empty()

                st.session_state.comparison = compare(st.session_state.file_df, target, st.session_state.mapping, keys)
                c = st.session_state.comparison
                metrics([("Source", c["source"]), ("Target", c["target"]), ("Matched", c["matched"]), ("Insert", c["insert"]), ("Update", c["update"]), ("Delete", c["delete"])])
                if not c["differences"].empty:
                    st.dataframe(c["differences"], use_container_width=True, hide_index=True)
                audit("COMPARE", "SUCCESS", json.dumps({k: c[k] for k in ["source", "target", "matched", "insert", "update", "delete"]}))
            except Exception as e:
                audit("COMPARE", "FAILED", safe_error(e))
                st.error(safe_error(e))

elif page == "🔄 CSV → Parquet → PostgreSQL":
    header("🔄 CSV → Parquet → PostgreSQL", "Validate the source → Parquet round-trip and the mapped PostgreSQL target without loading the whole table.")
    if st.session_state.file_df is None or not st.session_state.engine or not st.session_state.table:
        st.warning("Need source, connection and target table.")
    else:
        if st.button("🔄 Validate Pipeline", type="primary"):
            try:
                source = st.session_state.file_df
                b = io.BytesIO()
                source.to_parquet(b, index=False)
                b.seek(0)
                pq = pd.read_parquet(b)
                source_cols = list(map(str, source.columns))
                parquet_cols = list(map(str, pq.columns))
                target_cols = table_columns(st.session_state.engine, st.session_state.schema, st.session_state.table)
                mapping = st.session_state.mapping
                if mapping is not None:
                    mapped_targets = [str(x.target_column) for x in mapping.itertuples() if x.target_column]
                else:
                    mapped_targets = source_cols
                missing_targets = [c for c in mapped_targets if c not in target_cols]
                target_count = count_rows(st.session_state.engine, st.session_state.schema, st.session_state.table)
                # Null counts for mapped target columns are fetched in one aggregate query.
                target_nulls = None
                if mapped_targets and not missing_targets:
                    expr = ", ".join(f"COUNT(*) FILTER (WHERE {qid(c)} IS NULL) AS {qid('__n_' + str(i))}" for i, c in enumerate(mapped_targets))
                    with st.session_state.engine.connect() as con:
                        row = con.execute(text(f"SELECT {expr} FROM {qid(st.session_state.schema)}.{qid(st.session_state.table)}")).mappings().one()
                    target_nulls = sum(int(row.get("__n_" + str(i), 0) or 0) for i in range(len(mapped_targets)))
                csv_parquet = source_cols == parquet_cols and len(source) == len(pq)
                mapped_ok = bool(mapped_targets) and not missing_targets
                metrics([
                    ("Source Rows", len(source)), ("Parquet Rows", len(pq)), ("DB Rows", target_count),
                    ("CSV ↔ Parquet", "MATCH" if csv_parquet else "DRIFT"),
                    ("Mapped Target", "VALID" if mapped_ok else "CHECK"),
                ])
                st.write("Source null cells:", int(source.isna().sum().sum()), "• Parquet null cells:", int(pq.isna().sum().sum()))
                if target_nulls is not None:
                    st.write("Mapped PostgreSQL null cells:", target_nulls)
                if missing_targets:
                    st.error("Mapped target columns missing from PostgreSQL: " + ", ".join(missing_targets))
                else:
                    st.success(f"Target {st.session_state.schema}.{st.session_state.table} is reachable and all mapped columns exist.")
                st.dataframe(pd.DataFrame({"source_column": source_cols, "parquet_column": parquet_cols}), use_container_width=True, hide_index=True)
            except Exception as e:
                audit("PIPELINE_VALIDATE", "FAILED", safe_error(e))
                st.error(safe_error(e))

elif page == "🧩 Difference Viewer":
    header("🧩 Difference Viewer", "Inspect field-level reconciliation differences.")
    c = st.session_state.comparison
    if not c:
        st.warning("Run comparison first.")
    elif c["differences"].empty:
        st.success("No differences.")
    else:
        d = c["differences"]
        col = st.selectbox("Column", ["All"] + sorted(d["column"].astype(str).unique()))
        if col != "All":
            d = d[d.column.astype(str) == col]
        st.dataframe(d, use_container_width=True, hide_index=True)
        dl(d, "Export Differences", "differences.csv")

elif page == "🤖 AI Recommendations":
    header("🤖 AI Recommendation Engine", "Explainable rule-based recommendations for mismatches.")
    c = st.session_state.comparison
    if not c:
        st.warning("Run comparison first.")
    elif st.button("🤖 Generate Recommendations", type="primary"):
        st.session_state.recommendations = recommendations(c["differences"])
    if st.session_state.recommendations is not None:
        st.dataframe(st.session_state.recommendations, use_container_width=True, hide_index=True)
        st.info("Recommendations are conservative. Manual Review is used when business priority cannot be inferred safely.")

elif page == "🧾 Query Generator":
    header("🧾 Query Generator", "Generate reviewable INSERT statements without executing them.")
    c = st.session_state.comparison
    df = st.session_state.file_df
    mp = st.session_state.mapping
    if not c or df is None or mp is None:
        st.warning("Complete comparison and mapping first.")
    elif st.button("🧾 Generate SQL", type="primary"):
        rename = {r.source_column: r.target_column for r in mp.itertuples() if r.target_column}
        src = df.rename(columns=rename)
        sc, tb = st.session_state.schema, st.session_state.table
        statements = []
        for _, r in src.iterrows():
            cols = list(src.columns)
            names = ", ".join(qid(x) for x in cols)
            vals = ", ".join(sql_lit(r[x]) for x in cols)
            statements.append(f"INSERT INTO {qid(sc)}.{qid(tb)} ({names}) VALUES ({vals});")
        st.session_state.sql = statements
        st.session_state.approved = False
        st.success(f"Generated {len(statements)} reviewable INSERT statements.")
    if st.session_state.sql:
        st.code("\n".join(st.session_state.sql[:250]), "sql")
        st.download_button("Download .sql", "\n".join(st.session_state.sql).encode(), "changes.sql", "application/sql")

elif page == "✅ Approval Center":
    header("✅ Approval Center", "Human approval gate before database modification.")
    c = st.session_state.comparison
    if not c or not st.session_state.sql:
        st.warning("No generated changes.")
    else:
        metrics([("Insert", c["insert"]), ("Update", c["update"]), ("Delete", c["delete"]), ("Statements", len(st.session_state.sql))])
        x = st.text_input('Type "APPROVE"')
        st.session_state.approved = x == "APPROVE"
        if st.session_state.approved:
            st.success("✅ Execution unlocked for this session.")
        else:
            st.warning("🔒 Execution locked.")

elif page == "⚙️ Execution Center":
    header("⚙️ Execution Center", "Transactional execution of explicitly approved SQL.")
    if not st.session_state.approved:
        st.error("🔒 Locked. Complete Approval Center.")
    elif not st.session_state.engine or not st.session_state.sql:
        st.warning("Nothing to execute.")
    elif st.button("🚀 EXECUTE APPROVED CHANGES", type="primary"):
        start = time.perf_counter()
        try:
            with st.session_state.engine.begin() as con:
                for statement in st.session_state.sql:
                    con.execute(text(statement))
            duration = round(time.perf_counter() - start, 3)
            st.session_state.execution = {"success": len(st.session_state.sql), "failure": 0, "duration": duration}
            audit("EXECUTION", "SUCCESS", json.dumps(st.session_state.execution))
            st.success(f"✅ {len(st.session_state.sql)} statements committed in {duration}s.")
        except Exception as e:
            result = {"success": 0, "failure": len(st.session_state.sql), "error": safe_error(e)}
            st.session_state.execution = result
            audit("EXECUTION", "FAILED", safe_error(e))
            st.error(f"❌ Transaction failed and was rolled back: {safe_error(e)}")

elif page == "↩️ Rollback Center":
    header("↩️ Rollback Center", "Transaction safety and rollback governance.")
    st.info("Failed transactions automatically roll back because Execution Center uses one PostgreSQL transaction.")
    st.warning("Committed changes are not given an unsafe generic UNDO. Use backups/snapshots for production rollback.")
    st.write("Backup directory:", str(BACKUPS))
    if st.session_state.execution:
        st.json(st.session_state.execution)

elif page == "📜 Audit History":
    header("📜 Audit History", "Searchable local governance audit trail.")
    d = audit_df()
    q = st.text_input("Search")
    if q:
        d = d[d.astype(str).apply(lambda x: x.str.contains(q, case=False, na=False)).any(axis=1)]
    st.dataframe(d, use_container_width=True, hide_index=True)
    dl(d, "Export Audit", "audit.csv")

elif page == "📑 Reports":
    header("📑 Reports", "Before/after reconciliation and execution summary.")
    c = st.session_state.comparison
    if not c:
        st.info("No comparison yet.")
    else:
        summary = {
            "database": st.session_state.conn,
            "schema": st.session_state.schema,
            "table": st.session_state.table,
            "file": st.session_state.file_name,
            "source_count": c["source"],
            "target_count": c["target"],
            "matched": c["matched"],
            "insert": c["insert"],
            "update": c["update"],
            "delete": c["delete"],
            "generated_sql": len(st.session_state.sql),
            "execution": st.session_state.execution,
        }
        st.json(summary)
        raw = json.dumps(summary, indent=2, default=str).encode()
        st.download_button("Download JSON", raw, "before_after_report.json", "application/json")
        pd.DataFrame([summary]).to_csv(REPORTS / "latest_summary.csv", index=False)
        st.success(f"Saved local summary: {REPORTS / 'latest_summary.csv'}")

elif page == "⚙️ Settings":
    header("⚙️ Settings", "Read-only local application configuration.")
    cfg = target_config()
    st.text_input("PostgreSQL host", cfg["host"], disabled=True)
    st.text_input("PostgreSQL port", str(cfg["port"]), disabled=True)
    st.text_input("Database", cfg["database"], disabled=True)
    st.text_input("Username", cfg["username"], disabled=True)
    st.text_input("Password", "Configured" if cfg["password"] else "Not configured", disabled=True)
    st.text_input("Reports", str(REPORTS), disabled=True)
    st.text_input("Backups", str(BACKUPS), disabled=True)
    st.info("Edit the local .env file and restart Streamlit if the connection target changes.")

audit_init()
