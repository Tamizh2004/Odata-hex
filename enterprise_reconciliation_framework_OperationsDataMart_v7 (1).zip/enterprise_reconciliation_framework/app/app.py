from __future__ import annotations
import io, json, os, re, socket, sqlite3, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote_plus

import numpy as np
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from rapidfuzz import fuzz
from sqlalchemy import create_engine, text, inspect

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE / ".env")
DATA = BASE / "data"; REPORTS = BASE / os.getenv("REPORT_DIR","reports"); BACKUPS = BASE / os.getenv("BACKUP_DIR","backups")
for p in (DATA, REPORTS, BACKUPS): p.mkdir(exist_ok=True)

st.set_page_config(page_title="Enterprise Data Reconciliation", page_icon="🔄", layout="wide")

# -------------------- session state --------------------
defaults = {
    "engine":None, "conn":None, "file_df":None, "file_name":None,
    "schema":"public", "table":None, "mapping":None, "comparison":None,
    "recommendations":None, "sql":[], "approved":False, "execution":None,
    "last_profile":None, "last_connection_error":None
}
for k,v in defaults.items():
    if k not in st.session_state: st.session_state[k]=v

# -------------------- postgres --------------------
# This build uses one explicit PostgreSQL target. The values are supplied by
# the local .env file so the UI never asks for credentials.

def _target_config():
    return {
        "host": os.getenv("ERF_PG_HOST", "localhost"),
        "port": int(os.getenv("ERF_PG_PORT", "5434")),
        "database": os.getenv("ERF_PG_DATABASE", "OperationsDataMart"),
        "username": os.getenv("ERF_PG_USER", "dbadmin"),
        "password": os.getenv("ERF_PG_PASSWORD", ""),
    }

def tcp_probe(port, host="127.0.0.1"):
    started=time.perf_counter()
    s=socket.socket(); s.settimeout(float(os.getenv("ERF_CONNECT_TIMEOUT", "0.35")))
    try:
        s.connect((host,port))
        return True, round((time.perf_counter()-started)*1000,2)
    except OSError:
        return False,None
    finally: s.close()

@st.cache_data(ttl=10, show_spinner=False)
def discover():
    cfg=_target_config()
    ok, latency=tcp_probe(cfg["port"], "127.0.0.1" if cfg["host"] in {"localhost","127.0.0.1"} else cfg["host"])
    return [(cfg["port"], latency)] if ok else []

def make_engine(host, port, database, username, password):
    """Create the single configured PostgreSQL connection.

    Credentials are supplied from the local .env file and are never rendered
    in the Streamlit UI or logged. SQLAlchemy URL quoting safely handles special
    characters in the password.
    """
    timeout=int(float(os.getenv("ERF_CONNECT_TIMEOUT", "5.0")))
    user=quote_plus(str(username))
    pwd=quote_plus(str(password), safe="")
    db=quote_plus(str(database))
    url=f"postgresql+psycopg2://{user}:{pwd}@{host}:{int(port)}/{db}"
    return create_engine(url, pool_pre_ping=True, pool_recycle=300,
                         connect_args={"connect_timeout": timeout})

def auto_connect_local_postgres():
    """Connect only to the configured OperationsDataMart PostgreSQL target."""
    cfg=_target_config()
    host=cfg["host"]
    probe_host="127.0.0.1" if host in {"localhost","127.0.0.1"} else host
    ok, latency=tcp_probe(cfg["port"], probe_host)
    if not ok:
        return None, {
            "error": f"PostgreSQL endpoint {host}:{cfg['port']} is not reachable.",
            "target": {k:v for k,v in cfg.items() if k != "password"},
        }
    if not cfg["password"]:
        return None, {
            "error": "ERF_PG_PASSWORD is not configured in the local .env file.",
            "target": {k:v for k,v in cfg.items() if k != "password"},
        }
    try:
        eng=make_engine(cfg["host"],cfg["port"],cfg["database"],cfg["username"],cfg["password"])
        info=pg_info(eng)
        info.update({
            "host": host,
            "port": cfg["port"],
            "configured_database": cfg["database"],
            "configured_username": cfg["username"],
            "latency_ms": info.get("latency_ms", latency),
            "connection_mode": "Dedicated OperationsDataMart configuration",
        })
        return eng, info
    except Exception as exc:
        return None, {
            "error": str(exc),
            "target": {k:v for k,v in cfg.items() if k != "password"},
        }

def local_listening_ports():
    return [_target_config()["port"]]

def pg_info(engine):
    started=time.perf_counter()
    with engine.connect() as c:
        row=dict(c.execute(text("""
            SELECT current_database() AS database,
                   current_user AS current_user,
                   version() AS version,
                   inet_server_addr()::text AS server_addr,
                   inet_server_port() AS server_port
        """)).mappings().one())
    row["latency_ms"]=round((time.perf_counter()-started)*1000,2)
    return row

def dbs(engine):
    return pd.read_sql(text("SELECT datname FROM pg_database WHERE datallowconn=true ORDER BY datname"),engine)["datname"].tolist()

def list_databases(engine):
    return dbs(engine)

def schemas(engine):
    return pd.read_sql(text("""
        SELECT schema_name FROM information_schema.schemata
        WHERE schema_name NOT IN ('pg_toast') ORDER BY schema_name
    """),engine)["schema_name"].tolist()

def tables(engine,schema):
    return pd.read_sql(text("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema=:s AND table_type='BASE TABLE'
        ORDER BY table_name
    """),engine,params={"s":schema})["table_name"].tolist()

def qid(x): return '"' + str(x).replace('"','""') + '"'

def metadata(engine,schema,table):
    ins=inspect(engine)
    cols=ins.get_columns(table,schema=schema)
    pk=ins.get_pk_constraint(table,schema=schema).get("constrained_columns",[])
    idx=ins.get_indexes(table,schema=schema)
    return cols,pk,idx

def count_rows(engine,schema,table):
    with engine.connect() as c:
        return int(c.execute(text(f"SELECT COUNT(*) FROM {qid(schema)}.{qid(table)}")).scalar())

def read_table(engine,schema,table,limit=500000,offset=0):
    return pd.read_sql(text(f"SELECT * FROM {qid(schema)}.{qid(table)} LIMIT :n OFFSET :o"),
                       engine,params={"n":limit,"o":offset})

# -------------------- file/profiling --------------------
def load_upload(f):
    n=f.name.lower()
    if n.endswith(".csv"): return pd.read_csv(f)
    if n.endswith((".xlsx",".xls")): return pd.read_excel(f)
    if n.endswith(".parquet"): return pd.read_parquet(f)
    if n.endswith(".json"): return pd.read_json(f)
    raise ValueError("Unsupported file type.")

def profile(df):
    rows=[]
    for c in df.columns:
        s=df[c]
        rows.append({"column":c,"dtype":str(s.dtype),"null_count":int(s.isna().sum()),
                     "null_pct":round(float(s.isna().mean()*100),2),
                     "unique":int(s.nunique(dropna=True)),
                     "sample":", ".join(map(str,s.dropna().head(3).tolist()))})
    null_pct=100*df.isna().sum().sum()/max(df.size,1)
    dup=int(df.duplicated().sum())
    quality=max(0,100-null_pct-(dup/max(len(df),1))*100)
    return {"rows":len(df),"columns":len(df.columns),"nulls":int(df.isna().sum().sum()),
            "duplicates":dup,"missing_pct":round(null_pct,2),"quality":round(quality,2),
            "columns_df":pd.DataFrame(rows)}

def norm(x): return re.sub(r"[^a-z0-9]","",str(x).lower())

def auto_mapping(src,target):
    used=set(); out=[]
    for s in src:
        best=""; score=0; method="Unmapped"
        for t in target:
            if t in used: continue
            if norm(s)==norm(t): sc,md=100,"Exact Match"
            else: sc,md=fuzz.ratio(norm(s),norm(t)),"Fuzzy Match"
            if sc>score: best,score,method=t,sc,md
        if score<65: best=""; method="Unmapped"
        else: used.add(best)
        out.append({"source_column":s,"target_column":best,"confidence":round(score,1),"method":method})
    return pd.DataFrame(out)

# -------------------- reconciliation --------------------
def compare(src,tgt,mapping,keys):
    mp={r.source_column:r.target_column for r in mapping.itertuples() if r.target_column}
    s=src.rename(columns=mp).copy(); t=tgt.copy()
    common=[c for c in s.columns if c in t.columns]
    keys=[k for k in keys if k in common]
    if not keys: raise ValueError("Select at least one valid primary/business key.")
    s=s.drop_duplicates(keys,keep="last"); t=t.drop_duplicates(keys,keep="last")
    si=s.set_index(keys,drop=False); ti=t.set_index(keys,drop=False)
    sk=set(si.index.tolist()); tk=set(ti.index.tolist())
    ins=sorted(sk-tk,key=str); dele=sorted(tk-sk,key=str); shared=sorted(sk&tk,key=str)
    diffs=[]; updates=[]
    for key in shared:
        sr=si.loc[key]; tr=ti.loc[key]
        if isinstance(sr,pd.DataFrame): sr=sr.iloc[-1]
        if isinstance(tr,pd.DataFrame): tr=tr.iloc[-1]
        changed=False
        for c in common:
            if c in keys: continue
            a,b=sr[c],tr[c]
            eq=(pd.isna(a) and pd.isna(b)) or (a==b)
            if not eq:
                changed=True
                diffs.append({**{k:sr[k] for k in keys},"column":c,
                              "source_value":None if pd.isna(a) else a,
                              "database_value":None if pd.isna(b) else b,
                              "status":"UPDATE REQUIRED"})
        if changed: updates.append(key)
    return {"source":len(s),"target":len(t),"matched":len(shared)-len(updates),
            "insert":len(ins),"update":len(updates),"delete":len(dele),
            "keys":keys,"insert_keys":ins,"delete_keys":dele,
            "differences":pd.DataFrame(diffs),"source_df":s,"target_df":t}

def recommendations(diff):
    if diff.empty: return diff
    out=diff.copy()
    rec=[]
    for _,r in out.iterrows():
        a,b=r.source_value,r.database_value
        if pd.isna(b) and not pd.isna(a): rec.append(("Use CSV Value","DB is null; source has value",88))
        elif pd.isna(a) and not pd.isna(b): rec.append(("Use Database Value","Source is null; DB has value",88))
        else: rec.append(("Manual Review","Both values exist; timestamp/business rule required",55))
    x=pd.DataFrame(rec,columns=["recommendation","reason","confidence"])
    return pd.concat([out.reset_index(drop=True),x],axis=1)

def sql_lit(v):
    if pd.isna(v): return "NULL"
    if isinstance(v,(int,float,np.integer,np.floating)) and not isinstance(v,bool): return str(v)
    if isinstance(v,bool): return "TRUE" if v else "FALSE"
    return "'" + str(v).replace("'","''") + "'"

# -------------------- audit --------------------
AUDIT=DATA/"audit.sqlite3"
def audit_init():
    c=sqlite3.connect(AUDIT)
    c.execute("""CREATE TABLE IF NOT EXISTS audit(
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, database_name TEXT,
        schema_name TEXT, table_name TEXT, action TEXT, status TEXT, details TEXT)""")
    c.commit(); c.close()
def audit(action,status,details=""):
    audit_init(); c=sqlite3.connect(AUDIT)
    c.execute("INSERT INTO audit(ts,database_name,schema_name,table_name,action,status,details) VALUES(?,?,?,?,?,?,?)",
              (datetime.now(timezone.utc).isoformat(),
               (st.session_state.conn or {}).get("database",""),
               st.session_state.schema,st.session_state.table,action,status,details))
    c.commit(); c.close()
def audit_df():
    audit_init(); c=sqlite3.connect(AUDIT)
    d=pd.read_sql_query("SELECT * FROM audit ORDER BY id DESC LIMIT 2000",c); c.close(); return d

# -------------------- connection reuse --------------------
def ensure_existing_connection_info():
    """Populate connection metadata from an already-working session engine.

    This is intentionally metadata-only: it does not authenticate again.
    Connection Status and the Dashboard therefore share exactly the same
    SQLAlchemy engine once one page has connected successfully.
    """
    if st.session_state.engine is None:
        return False
    if st.session_state.conn is not None:
        return True
    try:
        info = pg_info(st.session_state.engine)
        # Port may be available from the SQLAlchemy URL; keep existing state
        # if present, otherwise expose the server port returned by PostgreSQL.
        port = info.get("server_port")
        st.session_state.conn = {
            "host": "127.0.0.1",
            "port": port,
            **info,
        }
        return True
    except Exception:
        return False

def connect_once_from_dashboard():
    """Connect once when the Dashboard has a reachable endpoint.

    The result is stored in session_state and is reused by Connection Status.
    No second authentication attempt is made merely by opening that page.
    """
    if st.session_state.engine is not None:
        ensure_existing_connection_info()
        return True
    if not discover():
        return False
    eng, info = auto_connect_local_postgres()
    st.session_state.last_connection_error = info if eng is None else None
    if eng is None:
        return False
    st.session_state.engine = eng
    st.session_state.conn = info
    audit("CONNECT", "SUCCESS", json.dumps({
        "port": info.get("port"),
        "database": info.get("database"),
        "latency_ms": info.get("latency_ms"),
        "source": "dashboard-auto-connect"
    }))
    return True

# -------------------- UI helpers --------------------
def header(title,subtitle):
    st.title(title); st.caption(subtitle)
def helpbox(steps):
    with st.expander("🧭 How to use this page",expanded=True):
        for i,s in enumerate(steps,1): st.markdown(f"**{i}.** {s}")
def metrics(items):
    cs=st.columns(len(items))
    for c,(a,b) in zip(cs,items): c.metric(a,b)
def dl(df,label,name,kind="csv"):
    if kind=="csv":
        data=df.to_csv(index=False).encode(); mime="text/csv"
    elif kind=="json":
        data=df.to_json(orient="records",date_format="iso").encode(); mime="application/json"
    else:
        b=io.BytesIO()
        with pd.ExcelWriter(b,engine="xlsxwriter") as w: df.to_excel(w,index=False)
        data=b.getvalue(); mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    st.download_button(label,data,name,mime)

# -------------------- navigation --------------------
pages=[
"🏠 Dashboard","🔌 Connection Status","🗄️ Database Explorer","📊 Table Data Explorer",
"⌨️ SQL Console","📁 File Upload","🔎 Data Profiling","🎯 Auto Table Prediction",
"🔗 Column Mapping","⚖️ CSV ↔ PostgreSQL","🔄 CSV → Parquet → PostgreSQL",
"🧩 Difference Viewer","🤖 AI Recommendations","🧾 Query Generator","✅ Approval Center",
"⚙️ Execution Center","↩️ Rollback Center","📜 Audit History","📑 Reports","⚙️ Settings"
]
with st.sidebar:
    st.markdown("## 🔄 Enterprise Reconciliation")
    if st.session_state.conn:
        st.success(f"Connected\n{st.session_state.conn['host']}:{st.session_state.conn['port']}")
    else:
        found=discover()
        st.warning(f"{len(found)} local endpoint(s) detected" if found else "No local PostgreSQL endpoint")
    page=st.radio("Navigation",pages,label_visibility="collapsed")
    st.divider()
    st.caption("AWS SSM is external. No AWS credentials are requested.")

# -------------------- pages --------------------
if page=="🏠 Dashboard":
    header("🏠 Dashboard","Enterprise control center for PostgreSQL reconciliation and governed data changes.")
    helpbox(["Start the external SSM tunnel.","The app uses the configured OperationsDataMart PostgreSQL connection automatically.","Upload and profile source data.","Compare → review → approve → execute → audit."])
    found=discover()
    if found and st.session_state.engine is None:
        connect_once_from_dashboard()
    else:
        ensure_existing_connection_info()
    st.success(f"✅ {len(found)} reachable local PostgreSQL endpoint(s)" if found else "❌ No reachable PostgreSQL endpoint detected")
    if st.session_state.engine and st.session_state.conn:
        try:
            ds=dbs(st.session_state.engine); ss=schemas(st.session_state.engine)
            tc=sum(len(tables(st.session_state.engine,s)) for s in ss[:50])
            metrics([("Databases",len(ds)),("Schemas",len(ss)),("Tables",tc),
                     ("Uploaded Files",1 if st.session_state.file_df is not None else 0),
                     ("Pending Approval",1 if st.session_state.sql and not st.session_state.approved else 0)])
        except Exception as e: st.error(str(e))
    else: metrics([("Databases","—"),("Schemas","—"),("Tables","—"),("Uploaded Files","—"),("Pending Approval","—")])
    c=st.session_state.comparison
    if c:
        st.subheader("Comparison Metrics")
        metrics([("Matched",c["matched"]),("Insert",c["insert"]),("Update",c["update"]),("Delete",c["delete"])])
        st.bar_chart(pd.DataFrame({"Status":["Matched","Insert","Update","Delete"],
                                   "Count":[c["matched"],c["insert"],c["update"],c["delete"]]}).set_index("Status"))
    st.subheader("Recent Audit")
    st.dataframe(audit_df().head(10),use_container_width=True,hide_index=True)

elif page=="🔌 Connection Status":
    header("🔌 Connection Status","Automatic local PostgreSQL endpoint detection and connection.")
    helpbox(["Start the external SSM tunnel in PowerShell.","The app checks the configured OperationsDataMart PostgreSQL listener automatically.","No username, password, database, or SSL form is required.","Once connected, the available database name(s) are shown and the rest of the workflow is unlocked."])

    if st.button("🔄 Re-scan Local Endpoint", type="primary"):
        st.session_state.engine = None
        st.session_state.conn = None
        st.rerun()

    # Connection Status is a VIEW of the shared application connection.
    # It must never perform a second authentication attempt of its own.
    reused = ensure_existing_connection_info()

    if st.session_state.engine is None:
        with st.spinner("Connecting to OperationsDataMart..."):
            connected = connect_once_from_dashboard()
        if not connected:
            found = discover()
            info = st.session_state.last_connection_error or {}
            cfg = _target_config()
            if found:
                st.warning("PostgreSQL endpoint is reachable, but the configured OperationsDataMart authentication did not succeed.")
            else:
                st.warning(f"PostgreSQL endpoint {cfg['host']}:{cfg['port']} is not reachable.")
            st.info(f"Configured target: {cfg['host']}:{cfg['port']} / {cfg['database']} / {cfg['username']}")
            st.caption("The application uses the dedicated local credentials from .env. No credential form is shown, and the password is never displayed or logged.")
            err = (info or {}).get("error", "")
            if err:
                clean=re.sub(r'(?i)(password|user|dbname)=[^\s]+', r'\1=***', str(err))
                st.code(clean[:1500])

    if st.session_state.conn and st.session_state.engine:
        conn = st.session_state.conn
        st.success(f"✅ Connected automatically — localhost:{conn['port']}")
        st.metric("Connected Database", conn["database"])
        try:
            dbs = list_databases(st.session_state.engine)
            st.subheader("Available Databases")
            st.dataframe(pd.DataFrame({"Database":dbs}), use_container_width=True, hide_index=True)
            st.session_state.available_databases = dbs
        except Exception as e:
            st.warning(f"Connected, but database discovery failed: {e}")
        st.info("Connection is ready. Continue with Database Explorer from the sidebar.")
        if st.button("Disconnect"):
            st.session_state.engine = None
            st.session_state.conn = None
            st.rerun()

elif page=="🗄️ Database Explorer":
    header("🗄️ Database Explorer","Database → schema → table browser with search and metadata export.")
    helpbox(["Connect first.","Choose a schema.","Search tables.","Select a table for the rest of the workflow."])
    if not st.session_state.engine: st.warning("Connect first.")
    else:
        eng=st.session_state.engine
        ds=dbs(eng)
        selected_db=st.selectbox("Database",ds,index=ds.index(st.session_state.conn["database"]) if st.session_state.conn["database"] in ds else 0)
        if selected_db!=st.session_state.conn["database"]:
            st.info("The current PostgreSQL connection is to another database. Reconnect with the desired database name.")
        ss=schemas(eng)
        st.session_state.schema=st.selectbox("Schema",ss,index=ss.index(st.session_state.schema) if st.session_state.schema in ss else 0)
        ts=tables(eng,st.session_state.schema)
        search=st.text_input("🔎 Search tables")
        ts=[t for t in ts if search.lower() in t.lower()]
        if ts:
            st.session_state.table=st.selectbox("Table",ts)
            st.success(f"Selected: {st.session_state.schema}.{st.session_state.table}")
            dl(pd.DataFrame({"table":ts}),"Export Metadata","tables.csv")

elif page=="📊 Table Data Explorer":
    header("📊 Table Data Explorer","DBeaver-like paginated PostgreSQL table browser.")
    helpbox(["Select a table in Database Explorer.","Choose page size/page.","Inspect data and metadata.","Export the visible page."])
    if not st.session_state.engine or not st.session_state.table: st.warning("Select a table first.")
    else:
        eng=st.session_state.engine; sc=st.session_state.schema; tb=st.session_state.table
        cols,pk,idx=metadata(eng,sc,tb); total=count_rows(eng,sc,tb)
        metrics([("Rows",total),("Columns",len(cols)),("Primary Keys",", ".join(pk) or "None"),("Indexes",len(idx))])
        size=st.selectbox("Rows per page",[50,100,200,500]); pg=st.number_input("Page",1,100000,1)
        df=read_table(eng,sc,tb,size,(pg-1)*size)
        st.dataframe(df,use_container_width=True,hide_index=True)
        a,b,c=st.columns(3)
        with a: dl(df,"Export CSV","table.csv","csv")
        with b: dl(df,"Export Excel","table.xlsx","xlsx")
        with c: dl(df,"Export JSON","table.json","json")
        with st.expander("SQL Preview"): st.code(f'SELECT * FROM "{sc}"."{tb}" LIMIT {size} OFFSET {(pg-1)*size};',"sql")

elif page=="⌨️ SQL Console":
    header("⌨️ SQL Console","Safe read-only SQL console; writes must go through the approval workflow.")
    helpbox(["Enter SELECT/WITH SQL.","Run and inspect results.","Export results.","Do not use this console for direct UPDATE/INSERT/DELETE."])
    if not st.session_state.engine: st.warning("Connect first.")
    else:
        sql=st.text_area("SQL","SELECT current_database(), current_user;",height=160)
        if st.button("▶ Run SELECT",type="primary"):
            if not re.match(r"^\s*(select|with)\b",sql,re.I): st.error("Only SELECT/WITH is allowed.")
            else:
                try:
                    d=pd.read_sql(text(sql),st.session_state.engine)
                    st.dataframe(d,use_container_width=True); dl(d,"Download CSV","query.csv")
                    audit("SELECT","SUCCESS",sql)
                except Exception as e: audit("SELECT","FAILED",str(e)); st.error(str(e))

elif page=="📁 File Upload":
    header("📁 File Upload","CSV, Excel, Parquet and JSON ingestion for reconciliation.")
    helpbox(["Upload a file.","The file is processed locally by Streamlit.","Review counts.","Continue to Data Profiling."])
    f=st.file_uploader("Source file",type=["csv","xlsx","xls","parquet","json"])
    if f:
        try:
            st.session_state.file_df=load_upload(f); st.session_state.file_name=f.name
            p=profile(st.session_state.file_df)
            metrics([("File",f.name),("Records",p["rows"]),("Columns",p["columns"]),("Null Cells",p["nulls"])])
            st.dataframe(st.session_state.file_df.head(100),use_container_width=True)
        except Exception as e: st.error(str(e))
    elif st.session_state.file_df is not None:
        st.info(f"Current file: {st.session_state.file_name}")

elif page=="🔎 Data Profiling":
    header("🔎 Data Profiling","Nulls, duplicates, unique values, types and quality scoring.")
    helpbox(["Upload a source file.","Review overall quality.","Inspect column-level statistics.","Generate/download the profile."])
    if st.session_state.file_df is None: st.warning("Upload a file first.")
    else:
        p=profile(st.session_state.file_df); st.session_state.last_profile=p
        metrics([("Records",p["rows"]),("Columns",p["columns"]),("Duplicates",p["duplicates"]),("Missing %",p["missing_pct"]),("Quality",f'{p["quality"]}%')])
        st.dataframe(p["columns_df"],use_container_width=True,hide_index=True)
        dl(p["columns_df"],"Download Profiling CSV","profiling.csv")

elif page=="🎯 Auto Table Prediction":
    header("🎯 Auto Table Prediction","Suggest target tables using column overlap and key metadata.")
    helpbox(["Upload a source.","Connect PostgreSQL.","Select schema.","Run prediction and confirm the result manually."])
    if st.session_state.file_df is None or not st.session_state.engine: st.warning("Need source file and PostgreSQL connection.")
    else:
        if st.button("🎯 Predict Target Table",type="primary"):
            src={norm(x) for x in st.session_state.file_df.columns}; out=[]
            for tb in tables(st.session_state.engine,st.session_state.schema):
                cs,pk,_=metadata(st.session_state.engine,st.session_state.schema,tb)
                names={norm(c["name"]) for c in cs}; overlap=len(src&names)
                score=round(overlap/max(len(src),1)*100,1)
                out.append((tb,score,overlap,",".join(pk)))
            out.sort(key=lambda x:x[1],reverse=True)
            d=pd.DataFrame(out,columns=["table","confidence","matching_columns","primary_key"])
            st.dataframe(d.head(15),use_container_width=True,hide_index=True)
            if not d.empty: st.success(f"Suggested: {d.iloc[0]['table']} • {d.iloc[0]['confidence']}% confidence")

elif page=="🔗 Column Mapping":
    header("🔗 Column Mapping","Exact, fuzzy and manual source-to-database mapping.")
    helpbox(["Select a target table.","Run automatic mapping.","Review confidence.","Manually override target columns and save."])
    if st.session_state.file_df is None or not st.session_state.engine or not st.session_state.table:
        st.warning("Need source, connection and selected table.")
    else:
        cs,pk,_=metadata(st.session_state.engine,st.session_state.schema,st.session_state.table)
        targets=[c["name"] for c in cs]
        if st.button("🔗 Auto Map",type="primary"): st.session_state.mapping=auto_mapping(st.session_state.file_df.columns,targets)
        if st.session_state.mapping is not None:
            edit=st.data_editor(st.session_state.mapping,use_container_width=True,hide_index=True,
                column_config={"target_column":st.column_config.SelectboxColumn("Target Column",options=[""]+targets)})
            if st.button("💾 Save Mapping"): st.session_state.mapping=edit; st.success("Mapping saved.")

elif page=="⚖️ CSV ↔ PostgreSQL":
    header("⚖️ CSV ↔ PostgreSQL Comparison","Source-to-database reconciliation.")
    helpbox(["Upload source.","Select target table.","Complete mapping.","Select keys.","Run comparison."])
    if st.session_state.file_df is None or not st.session_state.engine or not st.session_state.table or st.session_state.mapping is None:
        st.warning("Complete upload → table → mapping first.")
    else:
        cs,pk,_=metadata(st.session_state.engine,st.session_state.schema,st.session_state.table)
        target_cols=[c["name"] for c in cs]
        keys=st.multiselect("Primary/business keys",target_cols,default=[x for x in pk if x in target_cols])
        if st.button("⚖️ Run Comparison",type="primary"):
            try:
                target=read_table(st.session_state.engine,st.session_state.schema,st.session_state.table,
                                  count_rows(st.session_state.engine,st.session_state.schema,st.session_state.table))
                st.session_state.comparison=compare(st.session_state.file_df,target,st.session_state.mapping,keys)
                c=st.session_state.comparison
                metrics([("Source",c["source"]),("Target",c["target"]),("Matched",c["matched"]),("Insert",c["insert"]),("Update",c["update"]),("Delete",c["delete"])])
                if not c["differences"].empty: st.dataframe(c["differences"],use_container_width=True,hide_index=True)
                audit("COMPARE","SUCCESS",json.dumps({k:c[k] for k in ["source","target","matched","insert","update","delete"]}))
            except Exception as e: audit("COMPARE","FAILED",str(e)); st.error(str(e))

elif page=="🔄 CSV → Parquet → PostgreSQL":
    header("🔄 CSV → Parquet → PostgreSQL","Validate the complete ingestion chain.")
    helpbox(["Upload source.","Select target table.","Convert source to Parquet in memory.","Compare counts, columns and nulls."])
    if st.session_state.file_df is None or not st.session_state.engine or not st.session_state.table:
        st.warning("Need source, connection and table.")
    else:
        if st.button("🔄 Validate Pipeline",type="primary"):
            b=io.BytesIO(); st.session_state.file_df.to_parquet(b,index=False); b.seek(0)
            pq=pd.read_parquet(b)
            db=read_table(st.session_state.engine,st.session_state.schema,st.session_state.table,
                          count_rows(st.session_state.engine,st.session_state.schema,st.session_state.table))
            a=set(map(str,st.session_state.file_df.columns)); p=set(map(str,pq.columns)); d=set(map(str,db.columns))
            metrics([("CSV Rows",len(st.session_state.file_df)),("Parquet Rows",len(pq)),("DB Rows",len(db)),
                     ("CSV/Parquet Schema","MATCH" if a==p else "DRIFT"),("Parquet/DB Schema","MATCH" if p==d else "DRIFT")])
            st.write("CSV null cells:",int(st.session_state.file_df.isna().sum().sum()),
                     "• Parquet null cells:",int(pq.isna().sum().sum()),
                     "• DB null cells:",int(db.isna().sum().sum()))

elif page=="🧩 Difference Viewer":
    header("🧩 Difference Viewer","Field-level differences from the latest comparison.")
    helpbox(["Run a comparison.","Filter by column.","Review source and database values."])
    c=st.session_state.comparison
    if not c: st.warning("Run comparison first.")
    elif c["differences"].empty: st.success("No differences.")
    else:
        d=c["differences"]; col=st.selectbox("Column",["All"]+sorted(d["column"].astype(str).unique()))
        if col!="All": d=d[d.column.astype(str)==col]
        st.dataframe(d,use_container_width=True,hide_index=True)

elif page=="🤖 AI Recommendations":
    header("🤖 AI Recommendation Engine","Explainable recommendations for mismatched values.")
    helpbox(["Run comparison.","Generate recommendations.","Review each row.","Manual Review means a business rule is required."])
    c=st.session_state.comparison
    if not c: st.warning("Run comparison first.")
    elif st.button("🤖 Generate Recommendations",type="primary"):
        st.session_state.recommendations=recommendations(c["differences"])
    if st.session_state.recommendations is not None:
        st.dataframe(st.session_state.recommendations,use_container_width=True,hide_index=True)
        st.info("This default engine is conservative and rule-based. It never pretends that timestamp/business priority can be inferred when it cannot.")

elif page=="🧾 Query Generator":
    header("🧾 Query Generator","Generate INSERT/UPDATE/DELETE SQL for review; nothing executes here.")
    helpbox(["Complete comparison and mapping.","Generate statements.","Inspect SQL.","Send it to Approval Center."])
    c=st.session_state.comparison; df=st.session_state.file_df; mp=st.session_state.mapping
    if not c or df is None or mp is None: st.warning("Complete comparison and mapping first.")
    elif st.button("🧾 Generate SQL",type="primary"):
        rename={r.source_column:r.target_column for r in mp.itertuples() if r.target_column}
        src=df.rename(columns=rename); sc=st.session_state.schema; tb=st.session_state.table; keys=c["keys"]
        statements=[]
        for _,r in src.iterrows():
            cols=list(src.columns); names=", ".join(qid(x) for x in cols); vals=", ".join(sql_lit(r[x]) for x in cols)
            statements.append(f'INSERT INTO {qid(sc)}.{qid(tb)} ({names}) VALUES ({vals});')
        st.session_state.sql=statements; st.session_state.approved=False
        st.success(f"Generated {len(statements)} reviewable INSERT statements.")
    if st.session_state.sql:
        st.code("\n".join(st.session_state.sql[:250]),"sql")
        st.download_button("Download .sql","\n".join(st.session_state.sql).encode(),"changes.sql","application/sql")

elif page=="✅ Approval Center":
    header("✅ Approval Center","Human approval gate before database modification.")
    helpbox(["Review comparison counts.","Review generated SQL.","Type exactly APPROVE.","Execution becomes enabled only after the exact phrase."])
    c=st.session_state.comparison
    if not c or not st.session_state.sql: st.warning("No generated changes.")
    else:
        metrics([("Insert",c["insert"]),("Update",c["update"]),("Delete",c["delete"]),("Statements",len(st.session_state.sql))])
        x=st.text_input('Type "APPROVE"')
        st.session_state.approved=(x=="APPROVE")
        if st.session_state.approved: st.success("✅ Execution unlocked for this session.")
        else: st.warning("🔒 Execution locked.")

elif page=="⚙️ Execution Center":
    header("⚙️ Execution Center","Transactional execution of explicitly approved SQL.")
    helpbox(["Approve first.","Verify database/table.","Execution runs in one PostgreSQL transaction.","A failure rolls back the entire transaction."])
    if not st.session_state.approved: st.error("🔒 Locked. Complete Approval Center.")
    elif not st.session_state.engine or not st.session_state.sql: st.warning("Nothing to execute.")
    elif st.button("🚀 EXECUTE APPROVED CHANGES",type="primary"):
        start=time.perf_counter()
        try:
            with st.session_state.engine.begin() as con:
                for s in st.session_state.sql: con.execute(text(s))
            duration=round(time.perf_counter()-start,3)
            st.session_state.execution={"success":len(st.session_state.sql),"failure":0,"duration":duration}
            audit("EXECUTION","SUCCESS",json.dumps(st.session_state.execution))
            st.success(f"✅ {len(st.session_state.sql)} statements committed in {duration}s.")
        except Exception as e:
            result={"success":0,"failure":len(st.session_state.sql),"error":str(e)}
            st.session_state.execution=result; audit("EXECUTION","FAILED",str(e))
            st.error(f"❌ Transaction failed and was rolled back: {e}")

elif page=="↩️ Rollback Center":
    header("↩️ Rollback Center","Rollback governance and execution safety.")
    helpbox(["Failed transactions automatically roll back.","For committed changes, use a verified snapshot before enabling production UNDO.","Review audit history and backups."])
    st.info("The framework guarantees transactional rollback on failed execution.")
    st.warning("A generic application cannot safely invent a universal post-commit UNDO for every PostgreSQL schema, FK cascade, trigger, generated column and sequence. Production UNDO should be snapshot-backed.")
    st.write("Backup directory:",str(BACKUPS))
    if st.session_state.execution: st.json(st.session_state.execution)

elif page=="📜 Audit History":
    header("📜 Audit History","Searchable application audit trail.")
    helpbox(["Search actions/status/details.","Export the audit table for governance."])
    d=audit_df(); q=st.text_input("Search")
    if q: d=d[d.astype(str).apply(lambda x:x.str.contains(q,case=False,na=False)).any(axis=1)]
    st.dataframe(d,use_container_width=True,hide_index=True); dl(d,"Export Audit","audit.csv")

elif page=="📑 Reports":
    header("📑 Reports","Before/after reconciliation and execution report.")
    helpbox(["Run comparison.","Review report summary.","Download JSON/CSV/Excel artifacts.","Use audit history for detailed execution trace."])
    c=st.session_state.comparison
    if not c: st.info("No comparison yet.")
    else:
        summary={"database":st.session_state.conn,"schema":st.session_state.schema,"table":st.session_state.table,
                 "file":st.session_state.file_name,"source_count":c["source"],"target_count":c["target"],
                 "matched":c["matched"],"insert":c["insert"],"update":c["update"],"delete":c["delete"],
                 "generated_sql":len(st.session_state.sql),"execution":st.session_state.execution}
        st.json(summary)
        raw=json.dumps(summary,indent=2,default=str).encode()
        st.download_button("Download JSON",raw,"before_after_report.json","application/json")
        pd.DataFrame([summary]).to_csv(REPORTS/"latest_summary.csv",index=False)
        st.success(f"Saved local summary: {REPORTS/'latest_summary.csv'}")

elif page=="⚙️ Settings":
    header("⚙️ Settings","Local application configuration.")
    helpbox(["The application uses the dedicated OperationsDataMart connection from .env.","AWS settings are intentionally not present.","Restart after editing .env."])
    cfg=_target_config()
    st.text_input("PostgreSQL host",cfg["host"],disabled=True)
    st.text_input("PostgreSQL port",str(cfg["port"]),disabled=True)
    st.text_input("Database",cfg["database"],disabled=True)
    st.text_input("Username",cfg["username"],disabled=True)
    st.text_input("Password", "Configured" if cfg["password"] else "Not configured", disabled=True)
    st.text_input("Reports",str(REPORTS),disabled=True)
    st.text_input("Backups",str(BACKUPS),disabled=True)
    st.info("This build intentionally connects only to the configured OperationsDataMart target. Edit .env and restart Streamlit if the connection details change.")

audit_init()
