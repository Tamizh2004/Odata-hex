# Enterprise Streamlit Data Reconciliation & Data Management Framework

## Architecture

External PowerShell/AWS SSM
        |
        v
Local TCP PostgreSQL tunnel
        |
        v
Streamlit auto-discovery
        |
        v
PostgreSQL
        |
        +--> Database Explorer
        +--> Table Browser
        +--> File Upload
        +--> Profiling
        +--> Table Prediction
        +--> Column Mapping
        +--> Reconciliation
        +--> Difference Viewer
        +--> Recommendations
        +--> SQL Generator
        +--> Approval
        +--> Transactional Execution
        +--> Audit
        +--> Reports

The application does NOT request, store, or manage AWS credentials, bastion
IDs, AWS region, or remote RDS endpoint. AWS SSM remains an external concern.

It does NOT assume localhost:13391. It probes configured local ports and
allows you to add any local tunnel port through .env.

## Start

Double-click:

    setup_and_run.bat

After first setup, use the same file every time. VS Code is not required.

## PostgreSQL authentication

This build uses one dedicated PostgreSQL target configured in the local `.env`:
`localhost:5434`, database `OperationsDataMart`, user `dbadmin`. The password is
kept in `.env` and is never shown in the Streamlit UI or logged. The application
does not read or decrypt DBeaver credentials.

When the Dashboard establishes a working PostgreSQL connection, that same
SQLAlchemy engine is reused by Connection Status and the rest of the app.
Opening Connection Status does not perform a second authentication attempt.

## Workflow

1. Start external SSM tunnel in PowerShell.
2. Double-click setup_and_run.bat.
3. Connection Status -> Refresh Detection.
4. Select any detected local PostgreSQL endpoint.
5. Connect.
6. Database Explorer -> schema -> table.
7. File Upload -> CSV/Excel/Parquet/JSON.
8. Data Profiling.
9. Auto Table Prediction.
10. Column Mapping.
11. CSV <-> PostgreSQL Comparison.
12. Difference Viewer / AI Recommendations.
13. Query Generator.
14. Approval Center: type APPROVE.
15. Execution Center.
16. Reports / Audit / Rollback.

## Security

Never place AWS access keys, secret keys or session tokens in this project.
If temporary AWS credentials were exposed publicly or to an unintended party,
revoke/rotate them.


## Automatic Local PostgreSQL Connection

The application now detects local TCP listeners and automatically attempts PostgreSQL authentication. The Connection Status page no longer asks for username, password, database, or SSL mode. It uses the existing PostgreSQL/libpq authentication available to the process, then displays the connected database and available databases. AWS/SSM remains external to the application.


## PostgreSQL authentication note

Connection Status and Dashboard share the same SQLAlchemy engine in the Streamlit session. The `pg_info(engine)` helper is intentionally **not** decorated with `st.cache_data`, because SQLAlchemy `Engine` objects are not safely hashable by Streamlit's data cache.

The app reads non-secret PostgreSQL connection metadata from DBeaver (host, port, database, username) but does not decrypt DBeaver's saved password. If the PostgreSQL server requires password authentication, provide the password to libpq through `PGPASSWORD`, `PGPASSFILE`/Windows `pgpass.conf`, `PGSERVICE`, or another configured libpq credential source.


## Dedicated OperationsDataMart build

The included `.env` is preconfigured for the PostgreSQL connection supplied for this build.
The UI does not request credentials. If the password is changed later, update only `.env`
(or use the `.env.example` template) and restart Streamlit.
