# iFly → ODH Reconciliation Automation

Minimal Streamlit framework for the required flow only.

## Process

1. Load **Step 1 iFly** CSV/Parquet.
2. Normalize it to **Step 1 Parquet**.
3. Load **Step 3 ODH** CSV/Parquet.
4. Normalize it to **Step 3 Parquet**.
5. Compare **Step 1 Parquet vs Step 3 Parquet**.
6. Generate **Step 4** summary and detailed reconciliation reports.
7. Generate **Step 5** Match/Missed ODH report and changes-only report.

The CSV files supplied with the project are reference samples only. They are **not bundled as required application input data**.

## Default match key

The framework uses the business key observed in the supplied reference outputs:

- `membershipNumber`
- `uniqueAccountID`
- `cardType`
- `cardHolderType`
- `updateTime`

The Streamlit page allows the key to be changed when another automation has a different key.

## Outputs

- `step1_ifly.parquet`
- `step3_odh.parquet`
- `step4_recon_stats_summary.csv`
- `step4_recon_detailed_results.csv`
- `step5_match_and_missed_odh_report.csv`
- `step5_odh_changes_only.csv`

## Windows

Run **`setup_and_run.bat`**.

The launcher supports Python 3.10–3.14 and installs **PyArrow as a prebuilt binary wheel only**. This prevents the C++/CMake build failure seen with older PyArrow constraints on Python 3.14.

## Important

Do not install the old `pyarrow>=16,<22` requirement from the previous package. The current package pins PyArrow to the current 3.14-compatible wheel line (`25.x`). PyPI publishes Windows CPython 3.14 wheels for PyArrow 25.0.1.
