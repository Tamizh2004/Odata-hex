from pathlib import Path
import tempfile
import zipfile
import pandas as pd
import streamlit as st
from reconcile import DEFAULT_KEY_COLUMNS, read_table, run_reconciliation

st.set_page_config(page_title="iFly → ODH Reconciliation", page_icon="🔎", layout="centered")
st.title("iFly → ODH Reconciliation")
st.caption("Step 1 + Step 3 → Parquet comparison → Step 4 + Step 5")

step1 = st.file_uploader("Step 1 — iFly", type=["csv", "parquet"])
step3 = st.file_uploader("Step 3 — ODH", type=["csv", "parquet"])

if not (step1 and step3):
    st.info("Upload the Step 1 iFly file and Step 3 ODH file to begin.")
    st.stop()

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    p1 = td / step1.name
    p3 = td / step3.name
    p1.write_bytes(step1.getbuffer())
    p3.write_bytes(step3.getbuffer())

    try:
        d1 = read_table(p1)
        d3 = read_table(p3)
    except Exception as e:
        st.error(f"Could not read the input files: {e}")
        st.stop()

    common = [c for c in d1.columns if c in d3.columns]
    default_keys = [c for c in DEFAULT_KEY_COLUMNS if c in common]
    if not default_keys and common:
        default_keys = [common[0]]

    keys = st.multiselect("Match key", common, default=default_keys)
    event_type = st.text_input("Event type", value=Path(step1.name).stem.split()[0].upper() or "RECONCILIATION")

    if st.button("Run reconciliation", type="primary", use_container_width=True):
        if not keys:
            st.error("Select at least one match-key column.")
            st.stop()
        out = td / "output"
        try:
            files = run_reconciliation(p1, p3, out, key_columns=keys, event_type=event_type)
            summary = pd.read_csv(files["step4_summary"])
            st.success("Reconciliation completed successfully.")
            st.dataframe(summary, use_container_width=True, hide_index=True)

            bundle = td / "iFly_ODH_reconciliation_results.zip"
            with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as z:
                for f in out.iterdir():
                    z.write(f, arcname=f.name)
            st.download_button(
                "Download all results",
                bundle.read_bytes(),
                bundle.name,
                "application/zip",
                use_container_width=True,
            )
        except Exception as e:
            st.error(str(e))
