$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$py = Get-Command py -ErrorAction SilentlyContinue
if (-not $py) { throw 'Python Launcher (py) is not installed. Install Python 3.10 - 3.14.' }

if (-not (Test-Path '.venv')) {
    $created = $false
    foreach ($v in @('3.14','3.13','3.12','3.11','3.10')) {
        try { & py "-$v" -m venv .venv; $created = $true; break } catch {}
    }
    if (-not $created) { throw 'Python 3.10 - 3.14 is required.' }
}

$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $python -m pip install --upgrade pip
& $python -m pip install --only-binary=:all: --prefer-binary -r requirements.txt
& $python -m streamlit run app.py
