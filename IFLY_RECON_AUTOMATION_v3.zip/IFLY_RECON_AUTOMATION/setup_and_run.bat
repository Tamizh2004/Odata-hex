@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ========================================
echo   iFly - ODH Reconciliation Automation
echo ========================================
echo.

where py >nul 2>nul || (
  echo ERROR: Python Launcher ^(py^) is not installed.
  echo Install Python 3.10 - 3.14 from python.org and try again.
  pause
  exit /b 1
)

if not exist .venv (
  echo Creating virtual environment...
  py -3.14 -m venv .venv 2>nul || py -3.13 -m venv .venv 2>nul || py -3.12 -m venv .venv 2>nul || py -3.11 -m venv .venv 2>nul || py -3.10 -m venv .venv 2>nul || (
    echo ERROR: Python 3.10-3.14 is required.
    pause
    exit /b 1
  )
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
  echo ERROR: Could not activate the virtual environment.
  pause
  exit /b 1
)

python -m pip install --upgrade pip
if errorlevel 1 goto INSTALL_ERROR

rem IMPORTANT: binary-only install prevents pip from attempting to compile PyArrow/C++.
python -m pip install --only-binary=:all: --prefer-binary -r requirements.txt
if errorlevel 1 goto INSTALL_ERROR

echo.
echo Starting Streamlit...
echo Open http://localhost:8501 if it does not open automatically.
echo.
python -m streamlit run app.py
exit /b %errorlevel%

:INSTALL_ERROR
echo.
echo ERROR: Dependency installation failed.
echo PyArrow is required for Parquet files and this script only accepts prebuilt wheels.
echo Check your internet connection and Python version, then run setup_and_run.bat again.
pause
exit /b 1
