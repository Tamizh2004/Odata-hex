# IFLY_RECON_AUTOMATION v7

Minimal Streamlit iFly → ODH reconciliation automation.

## Comparison logic
- Records are matched by the selected business key; default: membershipNumber + referenceNumber + ticketNumber when available.
- Duplicate business keys stop the run rather than producing false matches.
- Both sides are blank when the value is None, pd.NA, NaN, NaT, empty, or whitespace-only. Any two blank representations compare equal.
- Literal text NULL, NaN, and NaT are real values and are not blank.
- Exact ISO date/datetime representations compare by their temporal value, preventing false mismatches caused only by Parquet schema types.
- Numeric schema differences (for example int vs float) compare by numeric value. Unambiguous numeric strings can match numeric values; leading-zero identifiers are kept strict.
- Other strings are strict: no trimming, case folding, or arbitrary normalization.
- Same record + no field differences = MATCH.
- Same record + genuine field differences = UPDATE.
- iFly-only = INSERT (missing in ODH).
- ODH-only = DELETE (missing in iFly).
- MismatchedFields contains only genuinely different fields.

## Outputs
- step1_ifly.parquet
- step3_odh.parquet
- step4_recon_stats_summary.csv
- step4_recon_detailed_results.csv
- step5_match_and_missed_odh_report.csv

All counts are whole numbers.

Run with setup_and_run.bat on Windows.
