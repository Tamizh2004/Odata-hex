from __future__ import annotations

import io
import json
import os
import re
import socket
import tempfile
import time
from datetime import date, datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import URL

BASE = Path(__file__).resolve().parents[1]
load_dotenv(BASE / ".env")
DATA = BASE / "data"
REPORTS = BASE / os.getenv("REPORT_DIR", "reports")
BACKUPS = BASE / os.getenv("BACKUP_DIR", "backups")
DATA.mkdir(exist_ok=True)
REPORTS.mkdir(exist_ok=True)
BACKUPS.mkdir(exist_ok=True)
MAPPING_FILE = DATA / "persistent_mappings.json"

st.set_page_config(page_title="Enterprise CSV ↔ PostgreSQL Reconciliation", page_icon="🔄", layout="wide")

# -----------------------------------------------------------------------------
# Scope: only the requested business schemas/tables are ever inspected/read.
# -----------------------------------------------------------------------------
ALLOWED_TABLES = {
    "CustomerProfile": ["LoyaltyProfile", "LoyaltyMember"],
    "LoyaltyDataStore": [
        "LoyaltyCertificate",
        "LoyaltyCobrandedCard",
        "LoyaltyPoolMember",
        "LoyaltyPartnerAccount",
        "LoyaltyClaim",
    ],
}
TABLE_OPTIONS = [f"{s}.{t}" for s, ts in ALLOWED_TABLES.items() for t in ts]
# The requested tables live in two separate PostgreSQL databases.
SCHEMA_DATABASES = {
    "CustomerProfile": "CustomerProfileDataStore",
    "LoyaltyDataStore": "LoyaltyDataStore",
}


DEFAULTS = {
    "engine": None,
    "engines": {},
    "conn": None,
    "last_connection_error": None,
    "files": [],
    "file_df": None,
    "file_names": [],
    "selected_tables": [],
    "mappings": {},
    "comparisons": {},
    "last_comparison": None,
    "resolved_tables": {},
    "right_panel": False,
}
for k, v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v


def target_config() -> dict:
    return {
        "host": os.getenv("ERF_PG_HOST", "localhost"),
        "port": int(os.getenv("ERF_PG_PORT", "5434")),
        "database": os.getenv("ERF_PG_DATABASE", "OperationsDataMart"),
        "username": os.getenv("ERF_PG_USER", "dbadmin"),
        "password": os.getenv("ERF_PG_PASSWORD", ""),
    }


def tcp_probe(host: str, port: int) -> tuple[bool, float | None]:
    started = time.perf_counter()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(float(os.getenv("ERF_PROBE_TIMEOUT", "0.45")))
    try:
        s.connect(("127.0.0.1" if host in {"localhost", "127.0.0.1"} else host, int(port)))
        return True, round((time.perf_counter() - started) * 1000, 2)
    except OSError:
        return False, None
    finally:
        s.close()


@st.cache_data(ttl=5, show_spinner=False)
def endpoint_status(host: str, port: int) -> dict:
    ok, latency = tcp_probe(host, port)
    return {"reachable": ok, "latency_ms": latency, "host": host, "port": port}


def database_for_schema(schema: str) -> str:
    return SCHEMA_DATABASES.get(schema, target_config().get("database", "OperationsDataMart"))


def target_databases() -> list[str]:
    raw = os.getenv("ERF_PG_DATABASES", "CustomerProfileDataStore,LoyaltyDataStore")
    names = [x.strip() for x in raw.split(",") if x.strip()]
    # Preserve the explicit application routing order and remove duplicates.
    ordered = []
    for name in [SCHEMA_DATABASES.get("CustomerProfile"), SCHEMA_DATABASES.get("LoyaltyDataStore"), *names]:
        if name and name not in ordered:
            ordered.append(name)
    return ordered


def engine_for_target(schema: str, table: str):
    db = database_for_schema(schema)
    engines = st.session_state.get("engines") or {}
    eng = engines.get(db)
    if eng is None:
        raise ValueError(f"Database connection for {db} is not available.")
    return eng


def make_engine(cfg: dict, database: str | None = None):
    database = database or cfg["database"]
    url = URL.create(
        drivername="postgresql+psycopg2",
        username=str(cfg["username"]),
        password=str(cfg["password"]),
        host=str(cfg["host"]),
        port=int(cfg["port"]),
        database=str(database),
    )
    return create_engine(
        url,
        pool_pre_ping=True,
        pool_recycle=300,
        pool_size=2,
        max_overflow=3,
        connect_args={"connect_timeout": int(float(os.getenv("ERF_CONNECT_TIMEOUT", "5")))},
    )


def safe_error(exc: Exception) -> str:
    msg = str(exc)
    pw = target_config().get("password", "")
    if pw:
        msg = msg.replace(pw, "***")
    return msg[:3500]


def pg_info(engine) -> dict:
    started = time.perf_counter()
    with engine.connect() as c:
        row = dict(c.execute(text("""
            SELECT current_database() AS database,
                   current_user AS current_user,
                   version() AS version,
                   inet_server_addr()::text AS server_addr,
                   inet_server_port() AS server_port
        """)).mappings().one())
    row["latency_ms"] = round((time.perf_counter() - started) * 1000, 2)
    return row


def connect_to_database(database: str | None = None):
    cfg = target_config()
    probe = endpoint_status(cfg["host"], cfg["port"])
    if not probe["reachable"]:
        return None, {"ok": False, "stage": "network", "error": f"PostgreSQL endpoint {cfg['host']}:{cfg['port']} is not reachable.", "probe": probe}
    if not cfg["username"] or not cfg["password"]:
        return None, {"ok": False, "stage": "credentials", "error": "PostgreSQL username/password is not configured in the local .env file.", "probe": probe}
    database = database or cfg["database"]
    engine = None
    try:
        engine = make_engine(cfg, database)
        info = pg_info(engine)
        info.update({
            "host": cfg["host"], "port": cfg["port"], "configured_database": database,
            "configured_username": cfg["username"], "connection_mode": "Routed multi-database configuration",
        })
        return engine, {"ok": True, **info}
    except Exception as exc:
        if engine is not None:
            engine.dispose()
        return None, {"ok": False, "stage": "authentication_or_postgres", "error": safe_error(exc), "probe": probe, "database": database, "username": cfg["username"]}


def ensure_connection() -> bool:
    cfg = target_config()
    if not endpoint_status(cfg["host"], cfg["port"])["reachable"]:
        st.session_state.last_connection_error = {"ok": False, "stage": "network", "error": f"PostgreSQL endpoint {cfg['host']}:{cfg['port']} is not reachable."}
        return False

    existing = st.session_state.get("engines") or {}
    healthy = {}
    errors = []
    for database in target_databases():
        eng = existing.get(database)
        if eng is not None:
            try:
                pg_info(eng)
                healthy[database] = eng
                continue
            except Exception:
                try: eng.dispose()
                except Exception: pass
        eng, result = connect_to_database(database)
        if eng is not None and result.get("ok"):
            healthy[database] = eng
        else:
            errors.append(result)

    st.session_state.engines = healthy
    # Keep the legacy single-engine slot populated for compatibility with older UI paths.
    st.session_state.engine = healthy.get(target_databases()[0]) if healthy else None
    st.session_state.resolved_tables = {}
    if errors and not healthy:
        st.session_state.last_connection_error = errors[0]
        st.session_state.conn = None
        return False
    st.session_state.last_connection_error = None if not errors else {"ok": True, "partial": True, "errors": errors}
    st.session_state.conn = {
        "host": cfg["host"], "port": cfg["port"],
        "databases": list(healthy.keys()),
        "database": ", ".join(healthy.keys()),
        "username": cfg["username"],
    }
    return bool(healthy)


# -----------------------------------------------------------------------------
# Persistent mapping configuration. Nothing is auto-remapped after a save.
# -----------------------------------------------------------------------------
def load_mappings() -> dict:
    if not MAPPING_FILE.exists():
        return {}
    try:
        data = json.loads(MAPPING_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_mappings(data: dict) -> None:
    tmp = MAPPING_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(MAPPING_FILE)


if not st.session_state.mappings:
    st.session_state.mappings = load_mappings()


def table_key(schema: str, table: str) -> str:
    return f"{schema}.{table}"


def qid(value: str) -> str:
    return '"' + str(value).replace('"', '""') + '"'


def allowed_table(schema: str, table: str) -> bool:
    return schema in ALLOWED_TABLES and table in ALLOWED_TABLES[schema]


def discover_dataset_tables(engine) -> dict[str, tuple[str, str]]:
    """Find the configured tables in the correct PostgreSQL database and schema.
    The database itself is selected by SCHEMA_DATABASES; within that database we
    inspect PostgreSQL catalogs for the requested schema/table names. No table
    rows are read during discovery."""
    current_db = pg_info(engine).get("database")
    desired = [(s, t) for s, ts in ALLOWED_TABLES.items() if database_for_schema(s) == current_db for t in ts]
    if not desired:
        return {}
    names = [t.lower() for _, t in desired]
    params = {f"t{i}": name for i, name in enumerate(names)}
    binds = ",".join(f":t{i}" for i in range(len(names)))
    with engine.connect() as c:
        rows = c.execute(text(f"""
            SELECT n.nspname AS schema_name, c.relname AS table_name, c.relkind
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.relkind IN ('r','p')
              AND n.nspname NOT LIKE 'pg_%'
              AND n.nspname <> 'information_schema'
              AND lower(n.nspname) IN ({','.join(':s'+str(i) for i in range(len(set(s.lower() for s,_ in desired))))})
              AND lower(c.relname) IN ({binds})
        """), {**params, **{f"s{i}": schema.lower() for i, schema in enumerate(dict.fromkeys(s for s,_ in desired))}}).mappings().all()
    resolved = {}
    for logical_schema, logical_table in desired:
        candidates = [r for r in rows if str(r['schema_name']).lower() == logical_schema.lower() and str(r['table_name']).lower() == logical_table.lower()]
        if candidates:
            r = sorted(candidates, key=lambda r: (str(r['schema_name']).lower(), str(r['table_name']).lower()))[0]
            resolved[f'{logical_schema}.{logical_table}'] = (str(r['schema_name']), str(r['table_name']))
    return resolved


def resolve_table(engine, schema: str, table: str) -> tuple[str, str] | None:
    if not allowed_table(schema, table):
        return None
    cache = st.session_state.get('resolved_tables') or {}
    key = table_key(schema, table)
    if key not in cache:
        cache.update(discover_dataset_tables(engine))
        st.session_state.resolved_tables = cache
    return cache.get(key)


def metadata(engine, schema: str, table: str):
    actual = resolve_table(engine, schema, table)
    if not actual:
        raise ValueError(f"Required table {schema}.{table} was not found in database {database_for_schema(schema)}.")
    actual_schema, actual_table = actual
    ins = inspect(engine)
    cols = ins.get_columns(actual_table, schema=actual_schema)
    pk = ins.get_pk_constraint(actual_table, schema=actual_schema).get("constrained_columns", []) or []
    indexes = ins.get_indexes(actual_table, schema=actual_schema) or []
    return cols, pk, indexes


def table_exists(engine, schema: str, table: str) -> bool:
    return resolve_table(engine, schema, table) is not None


def count_rows(engine, schema: str, table: str) -> int:
    actual = resolve_table(engine, schema, table)
    if not actual:
        raise ValueError("Table is not available in the connected database.")
    actual_schema, actual_table = actual
    with engine.connect() as c:
        return int(c.execute(text(f"SELECT COUNT(*) FROM {qid(actual_schema)}.{qid(actual_table)}")).scalar())


def table_columns(engine, schema: str, table: str) -> list[str]:
    cols, _, _ = metadata(engine, schema, table)
    return [str(c["name"]) for c in cols]


def table_types(engine, schema: str, table: str) -> dict[str, str]:
    if not allowed_table(schema, table):
        raise ValueError("Table is outside the configured dataset scope.")
    sql = text("""
        SELECT a.attname AS column_name, format_type(a.atttypid, a.atttypmod) AS type_sql
        FROM pg_attribute a
        JOIN pg_class c ON c.oid=a.attrelid
        JOIN pg_namespace n ON n.oid=c.relnamespace
        WHERE n.nspname=:schema AND c.relname=:table AND a.attnum>0 AND NOT a.attisdropped
        ORDER BY a.attnum
    """)
    with engine.connect() as c:
        rows = c.execute(sql, {"schema": schema, "table": table}).mappings().all()
    return {str(r["column_name"]): str(r["type_sql"]) for r in rows}


# -----------------------------------------------------------------------------
# Source files
# -----------------------------------------------------------------------------
def load_one_file(f) -> pd.DataFrame:
    name = f.name.lower()
    if name.endswith(".csv"):
        df = pd.read_csv(f)
    elif name.endswith((".xlsx", ".xls")):
        df = pd.read_excel(f)
    elif name.endswith(".parquet"):
        df = pd.read_parquet(f)
    else:
        raise ValueError("Only CSV, Excel and Parquet files are supported.")
    df.columns = [str(c).strip() for c in df.columns]
    if df.columns.duplicated().any():
        raise ValueError(f"Duplicate source column names in {f.name}; rename them before comparison.")
    return df


def load_multiple(files):
    frames, names = [], []
    for f in files:
        df = load_one_file(f)
        frames.append(df)
        names.append(f.name)
    if not frames:
        raise ValueError("Select at least one source file.")
    combined = pd.concat(frames, ignore_index=True, sort=False)
    return combined, names


# -----------------------------------------------------------------------------
# Mapping helpers
# -----------------------------------------------------------------------------
def mapping_df_for_table(schema: str, table: str, source_columns: list[str], target_columns: list[str]) -> pd.DataFrame:
    key = table_key(schema, table)
    saved = st.session_state.mappings.get(key, {})
    pairs = saved.get("mapping", {}) if isinstance(saved, dict) else {}
    rows = []
    for source in source_columns:
        target = pairs.get(source, "")
        if target not in target_columns:
            target = ""
        rows.append({"csv_column": source, "postgres_column": target})
    return pd.DataFrame(rows)


def mapping_valid(mapping: pd.DataFrame, source_columns: list[str], target_columns: list[str]) -> tuple[bool, str]:
    if mapping is None or mapping.empty:
        return False, "No mapping has been saved."
    rows = [(str(r.csv_column), str(r.postgres_column).strip()) for r in mapping.itertuples() if str(r.postgres_column).strip()]
    if not rows:
        return False, "Map at least one CSV column to PostgreSQL."
    targets = [t for _, t in rows]
    if len(targets) != len(set(targets)):
        return False, "A PostgreSQL column can be mapped only once per target table."
    bad_source = [s for s, _ in rows if s not in source_columns]
    bad_target = [t for _, t in rows if t not in target_columns]
    if bad_source or bad_target:
        return False, "Saved mapping contains columns that are no longer available. Edit and save the mapping."
    return True, ""


def saved_key_config(schema: str, table: str) -> dict:
    x = st.session_state.mappings.get(table_key(schema, table), {})
    return x if isinstance(x, dict) else {}


def source_key_options(mapping: pd.DataFrame) -> list[str]:
    return [str(r.csv_column) for r in mapping.itertuples() if str(r.postgres_column).strip()]


def target_key_options(mapping: pd.DataFrame, target_columns: list[str]) -> list[str]:
    return [str(r.postgres_column) for r in mapping.itertuples() if str(r.postgres_column).strip() in target_columns]


def build_key_pairs(mapping: pd.DataFrame, source_keys: list[str], target_keys: list[str]) -> list[tuple[str, str]]:
    mp = {str(r.csv_column): str(r.postgres_column) for r in mapping.itertuples() if str(r.postgres_column).strip()}
    pairs = [(s, mp[s]) for s in source_keys if s in mp and mp[s] in target_keys]
    return pairs


# -----------------------------------------------------------------------------
# Database-side, key-only reconciliation.
# -----------------------------------------------------------------------------
def normalize_for_db(v):
    if pd.isna(v):
        return None
    if isinstance(v, pd.Timestamp):
        if v.tzinfo is not None:
            return v.tz_convert("UTC").tz_localize(None).to_pydatetime()
        return v.to_pydatetime()
    if isinstance(v, datetime):
        return v.astimezone(timezone.utc).replace(tzinfo=None) if v.tzinfo else v
    if isinstance(v, (np.integer, np.floating)):
        return v.item()
    return v


def excel_safe_df(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        try:
            if isinstance(out[col].dtype, pd.DatetimeTZDtype):
                out[col] = out[col].dt.tz_convert("UTC").dt.tz_localize(None)
                continue
        except Exception:
            pass
        if out[col].dtype == "object":
            def clean(v):
                if isinstance(v, pd.Timestamp):
                    return v.tz_convert("UTC").tz_localize(None) if v.tzinfo else v
                if isinstance(v, datetime) and v.tzinfo:
                    return v.astimezone(timezone.utc).replace(tzinfo=None)
                return v
            out[col] = out[col].map(clean)
    return out


def download_df(df: pd.DataFrame, label: str, filename: str, kind: str = "csv"):
    if kind == "csv":
        data, mime = df.to_csv(index=False).encode("utf-8"), "text/csv"
    elif kind == "xlsx":
        b = io.BytesIO()
        safe = excel_safe_df(df)
        with pd.ExcelWriter(b, engine="xlsxwriter") as w:
            safe.to_excel(w, index=False, sheet_name="Data")
            ws = w.sheets["Data"]
            ws.freeze_panes(1, 0)
            if len(safe.columns):
                ws.autofilter(0, 0, max(len(safe), 1), len(safe.columns)-1)
                for i, col in enumerate(safe.columns):
                    sample = safe[col].head(100).fillna("").astype("string").str.len().max() if len(safe) else 0
                    sample = int(sample) if pd.notna(sample) else 0
                    ws.set_column(i, i, min(50, max(10, len(str(col))+2, sample+2)))
        data, mime = b.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    else:
        raise ValueError(kind)
    st.download_button(label, data, filename, mime, key=f"dl_{filename}_{kind}_{len(df)}")


def pg_copy_temp(raw, df: pd.DataFrame, temp_name: str, target_columns: list[str], column_types: dict[str, str] | None = None):
    # Staging columns are text. Casts happen only for join/updates. This keeps COPY tolerant
    # of mixed CSV representations while PostgreSQL remains the source of type validation.
    defs = ", ".join(f"{qid(c)} text" for c in target_columns)
    cols = ", ".join(qid(c) for c in target_columns)
    cur = raw.cursor()
    cur.execute(f"CREATE TEMP TABLE {qid(temp_name)} ({defs}) ON COMMIT DROP")
    with tempfile.NamedTemporaryFile(mode="w+b", suffix=".csv", delete=True) as fh:
        export = df[target_columns].copy()
        export = export.map(normalize_for_db)
        export.to_csv(fh, index=False, na_rep=r"\N", date_format="%Y-%m-%d %H:%M:%S%z")
        fh.flush(); fh.seek(0)
        cur.copy_expert(f"COPY {qid(temp_name)} ({cols}) FROM STDIN WITH (FORMAT CSV, HEADER TRUE, NULL '\\N')", fh)
    cur.execute(f"ANALYZE {qid(temp_name)}")
    cur.close()


def compare_one_table(schema: str, table: str, source: pd.DataFrame, mapping: pd.DataFrame, source_keys: list[str], target_keys: list[str]) -> dict:
    eng = engine_for_target(schema, table)
    target_cols = table_columns(eng, schema, table)
    valid, msg = mapping_valid(mapping, list(source.columns), target_cols)
    if not valid:
        raise ValueError(msg)
    key_pairs = build_key_pairs(mapping, source_keys, target_keys)
    if not key_pairs:
        raise ValueError("Select matching CSV and PostgreSQL key columns. The key pairs must be mapped to each other.")
    if len(key_pairs) != len(source_keys) or len(key_pairs) != len(target_keys):
        raise ValueError("CSV and PostgreSQL key selections must contain the same number of mapped key columns, in the same logical order.")
    if len(set(t for _, t in key_pairs)) != len(key_pairs):
        raise ValueError("PostgreSQL key columns must be unique.")

    # Only columns selected in the saved mapping are staged. No unrelated DB table columns are fetched.
    pairs = [(str(r.csv_column), str(r.postgres_column)) for r in mapping.itertuples() if str(r.postgres_column).strip()]
    src_cols = [s for s, _ in pairs]
    tgt_cols = [t for _, t in pairs]
    src = source[src_cols].copy()
    src.columns = tgt_cols
    # Duplicate source keys are ambiguous for row-level writes; stop rather than silently changing data.
    dup_mask = src.duplicated(target_keys, keep=False)
    duplicate_count = int(dup_mask.sum())
    if duplicate_count:
        raise ValueError(f"CSV contains {duplicate_count:,} rows with duplicate selected primary-key values. Remove duplicates before comparison.")

    types = table_types(eng, schema, table)
    for k in target_keys:
        if k not in types:
            raise ValueError(f"PostgreSQL key column {k} does not exist in {schema}.{table}.")

    temp_name = "erf_csv_stage"
    raw = None
    try:
        raw = eng.raw_connection()
        raw.autocommit = False
        pg_copy_temp(raw, src, temp_name, tgt_cols, types)
        cur = raw.cursor()
        actual = resolve_table(eng, schema, table)
        if not actual:
            raise ValueError(f"Required table {schema}.{table} was not found in the connected database.")
        actual_schema, actual_table = actual
        target_ref = f"{qid(actual_schema)}.{qid(actual_table)}"
        key_join = " AND ".join(f"s.{qid(t)}::{types[t]} IS NOT DISTINCT FROM t.{qid(t)}" for _, t in key_pairs)
        # A deterministic string key is useful for the UI and avoids returning the whole target table.
        source_count = int(cur.execute(f"SELECT COUNT(*) FROM {qid(temp_name)}") or 0) if False else None
        cur.execute(f"SELECT COUNT(*) FROM {qid(temp_name)}")
        source_count = int(cur.fetchone()[0])

        # Only rows whose keys occur in the CSV are read from PostgreSQL.
        select_cols = ", ".join(f"t.{qid(c)}" for c in tgt_cols)
        cur.execute(f"""
            SELECT {select_cols}
            FROM {target_ref} t
            JOIN {qid(temp_name)} s ON {key_join}
        """)
        rows = cur.fetchall()
        db_df = pd.DataFrame(rows, columns=tgt_cols)
        matched_count = len(db_df)
        target_missing_count = max(0, source_count - matched_count)

        # Build a row-level comparison from only CSV-key-matched DB rows.
        source_work = src.copy()
        if not db_df.empty:
            source_work = source_work.set_index(target_keys, drop=False)
            db_work = db_df.set_index(target_keys, drop=False)
        else:
            db_work = db_df
        insert_df = src.copy()
        if matched_count:
            matched_index = db_df[target_keys].apply(tuple, axis=1)
            source_index = src[target_keys].apply(tuple, axis=1)
            matched_set = set(matched_index)
            insert_df = src[~source_index.isin(matched_set)].copy()
        diff_rows = []
        update_keys = []
        matched_rows = []
        db_key_set = set(db_df[target_keys].apply(tuple, axis=1)) if not db_df.empty else set()
        for _, srow in src.iterrows():
            key = tuple(srow[k] for k in target_keys)
            if key not in db_key_set:
                continue
            drow = db_work.loc[key]
            if isinstance(drow, pd.DataFrame):
                drow = drow.iloc[0]
            changed = False
            record = {"_key": " | ".join(str(normalize_for_db(srow[k])) for k in target_keys)}
            for _, t in pairs:
                sv = srow[t]
                dv = drow[t]
                equal = (pd.isna(sv) and pd.isna(dv)) or (not pd.isna(sv) and not pd.isna(dv) and str(normalize_for_db(sv)) == str(normalize_for_db(dv)))
                if not equal:
                    changed = True
                    diff_rows.append({
                        "key": record["_key"], "column": t,
                        "csv_value": normalize_for_db(sv), "postgres_value": normalize_for_db(dv),
                        "action": "UPDATE",
                    })
            if changed:
                update_keys.append(key)
            matched_rows.append(record)

        differences = pd.DataFrame(diff_rows)
        updates = len(update_keys)
        result = {
            "schema": schema, "table": table, "source": source_count, "matched": matched_count,
            "insert": len(insert_df), "update": updates,
            "delete": 0, "target_key_scope": matched_count,
            "differences": differences, "insert_rows": insert_df,
            "matched_db": db_df, "source_mapped": src,
            "source_keys": source_keys, "target_keys": target_keys,
            "key_pairs": key_pairs, "mapping": pairs,
            "full_db_scan": False,
            "delete_note": "Delete is manual and key-scoped; no whole-table DB scan is performed.",
            "db_rows_read": matched_count,
        }
        raw.rollback()  # SELECT-only staging transaction; temp table is discarded.
        return result
    finally:
        if raw is not None:
            try: raw.close()
            except Exception: pass


def sql_value(v):
    v = normalize_for_db(v)
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "NULL"
    if isinstance(v, bool): return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, bool): return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def where_from_key_values(keys: list[str], row: dict, types: dict[str, str]) -> tuple[str, dict]:
    clauses, params = [], {}
    for i, k in enumerate(keys):
        p = f"p{i}"
        val = normalize_for_db(row.get(k))
        if val is None:
            clauses.append(f"{qid(k)} IS NULL")
        else:
            clauses.append(f"{qid(k)}::{types[k]} = :{p}")
            params[p] = val
    return " AND ".join(clauses) or "FALSE", params


def apply_inserts(result: dict, selected_indices: list[int]) -> int:
    if not selected_indices: return 0
    schema, table = result["schema"], result["table"]
    eng = engine_for_target(schema, table)
    actual = resolve_table(eng, schema, table)
    if not actual:
        raise ValueError(f"Required table {schema}.{table} was not found in the connected database.")
    actual_schema, actual_table = actual
    types = table_types(eng, schema, table)
    rows = result["insert_rows"].iloc[selected_indices]
    cols = [t for _, t in result["mapping"]]
    key_targets = result["target_keys"]
    inserted = 0
    with eng.begin() as con:
        for _, row in rows.iterrows():
            names = ", ".join(qid(c) for c in cols)
            vals = {f"v{i}": normalize_for_db(row[t]) for i, t in enumerate(cols)}
            binds = ", ".join(f":v{i}" for i in range(len(cols)))
            con.execute(text(f"INSERT INTO {qid(actual_schema)}.{qid(actual_table)} ({names}) VALUES ({binds})"), vals)
            inserted += 1
    return inserted


def apply_updates(result: dict, selected_keys: list[str]) -> int:
    if not selected_keys: return 0
    schema, table = result["schema"], result["table"]
    eng = engine_for_target(schema, table)
    actual = resolve_table(eng, schema, table)
    if not actual:
        raise ValueError(f"Required table {schema}.{table} was not found in the connected database.")
    actual_schema, actual_table = actual
    types = table_types(eng, schema, table)
    src = result["source_mapped"]
    db = result["matched_db"]
    target_keys = result["target_keys"]
    pairs = result["mapping"]
    key_to_source = {" | ".join(str(normalize_for_db(row[k])) for k in target_keys): row for _, row in src.iterrows()}
    updated = 0
    with eng.begin() as con:
        for key_text in selected_keys:
            row = key_to_source.get(key_text)
            if row is None: continue
            set_cols = [t for _, t in pairs if t not in target_keys]
            if not set_cols: continue
            params = {}
            sets = []
            for i, c in enumerate(set_cols):
                params[f"v{i}"] = normalize_for_db(row[c])
                sets.append(f"{qid(c)} = :v{i}")
            where, key_params = where_from_key_values(target_keys, row.to_dict(), types)
            params.update(key_params)
            res = con.execute(text(f"UPDATE {qid(actual_schema)}.{qid(actual_table)} SET {', '.join(sets)} WHERE {where}"), params)
            updated += int(res.rowcount or 0)
    return updated


def apply_deletes(result: dict, selected_keys: list[str]) -> int:
    if not selected_keys: return 0
    schema, table = result["schema"], result["table"]
    eng = engine_for_target(schema, table)
    actual = resolve_table(eng, schema, table)
    if not actual:
        raise ValueError(f"Required table {schema}.{table} was not found in the connected database.")
    actual_schema, actual_table = actual
    types = table_types(eng, schema, table)
    db = result["matched_db"]
    target_keys = result["target_keys"]
    key_texts = []
    for _, row in db.iterrows():
        key_text = " | ".join(str(normalize_for_db(row[k])) for k in target_keys)
        if key_text in selected_keys:
            key_texts.append(row.to_dict())
    deleted = 0
    with eng.begin() as con:
        for row in key_texts:
            where, params = where_from_key_values(target_keys, row, types)
            res = con.execute(text(f"DELETE FROM {qid(actual_schema)}.{qid(actual_table)} WHERE {where}"), params)
            deleted += int(res.rowcount or 0)
    return deleted


# -----------------------------------------------------------------------------
# UI
# -----------------------------------------------------------------------------
def header(title, subtitle=""):
    st.title(title)
    if subtitle: st.caption(subtitle)


def metrics(items):
    cols = st.columns(len(items))
    for c, (label, value) in zip(cols, items): c.metric(label, value)


if st.session_state.engine is None:
    ensure_connection()

# Slider-style right utility panel. The main workspace remains full width when closed.
top_left, top_right = st.columns([0.86, 0.14])
with top_right:
    st.session_state.right_panel = st.toggle("⚙ Right panel", value=st.session_state.right_panel, help="Open or close the quick controls.")
if st.session_state.right_panel:
    with st.container(border=True):
        st.markdown("### Quick panel")
        st.caption("Full-screen controls")
        if st.session_state.engines:
            st.success(f"Connected: {target_config()['host']}:{target_config()['port']}")
            st.caption("Connected databases: " + ", ".join(st.session_state.engines.keys()))
            st.caption("CustomerProfile tables → CustomerProfileDataStore; LoyaltyDataStore tables → LoyaltyDataStore")
        else:
            st.error("Required databases are not connected")
        st.caption(f"CSV files: {len(st.session_state.file_names)}")
        st.caption(f"Selected tables: {len(st.session_state.selected_tables)}")

with st.sidebar:
    st.markdown("## 🔄 Enterprise Reconciliation")
    if st.session_state.conn:
        st.success(f"Connected\n{st.session_state.conn.get('host')}:{st.session_state.conn.get('port')}\n{st.session_state.conn.get('database')}")
    else:
        cfg = target_config()
        st.error(f"PostgreSQL unavailable\n{cfg['host']}:{cfg['port']}")
        if st.button("🔄 Retry Connection"):
            for _eng in (st.session_state.get("engines") or {}).values():
                try: _eng.dispose()
                except Exception: pass
            st.session_state.engines = {}
            st.session_state.engine = None
            st.session_state.resolved_tables = {}
            st.rerun()
    page = st.radio("Navigation", ["🏠 Dashboard", "📁 CSV Upload", "🗂️ Select Tables", "🔗 Mapping & Keys", "⚖️ Compare", "✏️ DB Changes", "🔌 Connection"], label_visibility="collapsed")
    st.divider()
    st.caption("AWS SSM/SSH tunnel is external. This app uses only the local PostgreSQL endpoint.")


if page == "🏠 Dashboard":
    header("Enterprise CSV ↔ PostgreSQL Reconciliation", "Focused workflow for the approved CustomerProfileDataStore and LoyaltyDataStore datasets only.")
    st.info("Only the 7 configured dataset tables below are accessible. The app routes each table to its correct PostgreSQL database, verifies the exact schema/table, and reads data only from the selected tables.")
    rows = []
    if st.session_state.engines:
        for schema, tbls in ALLOWED_TABLES.items():
            for table in tbls:
                try:
                    exists = table_exists(engine_for_target(schema, table), schema, table)
                    if exists:
                        cols, pk, idx = metadata(engine_for_target(schema, table), schema, table)
                        actual = resolve_table(engine_for_target(schema, table), schema, table)
                        rows.append({"schema": actual[0] if actual else schema, "table": actual[1] if actual else table, "logical target": f"{schema}.{table}", "columns": len(cols), "DB primary key": ", ".join(pk) or "None", "indexes": len(idx), "rows": count_rows(engine_for_target(schema, table), schema, table)})
                    else:
                        rows.append({"schema": schema, "table": table, "columns": "—", "DB primary key": "—", "indexes": "—", "rows": "Not found"})
                except Exception as e:
                    rows.append({"schema": schema, "table": table, "columns": "Error", "DB primary key": safe_error(e), "indexes": "—", "rows": "—"})
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    if st.session_state.file_df is not None:
        metrics([("CSV files", len(st.session_state.file_names)), ("Combined CSV rows", len(st.session_state.file_df)), ("CSV columns", len(st.session_state.file_df.columns)), ("Mapped tables", len(st.session_state.mappings))])
    else:
        st.warning("Upload one or more CSV files to start.")
    st.markdown("### Workflow")
    st.markdown("**1. CSV Upload → 2. Select Tables → 3. Mapping & Keys → 4. Compare → 5. DB Changes**")

elif page == "📁 CSV Upload":
    header("📁 CSV Upload", "Upload one or more CSV files. They are combined row-wise and used as the only comparison source.")
    files = st.file_uploader("CSV files", type=["csv"], accept_multiple_files=True)
    if files:
        try:
            df, names = load_multiple(files)
            st.session_state.file_df = df
            st.session_state.file_names = names
            # Do not clear mappings: saved mappings remain fixed until the user edits them.
            st.session_state.comparisons = {}
            st.success(f"Loaded {len(names)} CSV file(s) → {len(df):,} combined rows × {len(df.columns)} columns.")
            st.caption("Files: " + " • ".join(names))
            st.dataframe(df.head(100), use_container_width=True, hide_index=True)
            st.download_button("Download combined CSV", df.to_csv(index=False).encode("utf-8"), "combined_source.csv", "text/csv")
        except Exception as e:
            st.error(safe_error(e))
    elif st.session_state.file_df is not None:
        st.info(f"Current source: {len(st.session_state.file_names)} CSV file(s), {len(st.session_state.file_df):,} combined rows.")
        st.dataframe(st.session_state.file_df.head(50), use_container_width=True, hide_index=True)

elif page == "🗂️ Select Tables":
    header("🗂️ Select Dataset Tables", "The app follows the database tree: CustomerProfileDataStore → CustomerProfile → LoyaltyProfile/LoyaltyMember, and LoyaltyDataStore → LoyaltyDataStore → the five loyalty tables. It connects to the correct database for each table and then verifies the schema/table from PostgreSQL catalogs.")
    if not st.session_state.engines:
        st.warning("Connect to the required PostgreSQL databases first.")
    else:
        current = set(st.session_state.selected_tables)
        for schema, tbls in ALLOWED_TABLES.items():
            st.subheader(f"{schema}  ·  Database: {database_for_schema(schema)}")
            for table in tbls:
                key = table_key(schema, table)
                try:
                    exists = table_exists(engine_for_target(schema, table), schema, table)
                except Exception:
                    exists = False
                checked = st.checkbox(f"{table}  ({schema})", value=(key in current), disabled=not exists, key=f"select_{key}")
                if checked: current.add(key)
                else: current.discard(key)
                if exists:
                    try:
                        cols, pk, idx = metadata(engine_for_target(schema, table), schema, table)
                        actual = resolve_table(engine_for_target(schema, table), schema, table)
                        st.caption(f"Found at {actual[0]}.{actual[1]} • Database: {database_for_schema(schema)} • {len(cols)} columns • DB PK: {', '.join(pk) or 'None'} • {count_rows(engine_for_target(schema, table), schema, table):,} rows")
                    except Exception as e:
                        st.caption(safe_error(e))
                else:
                    st.caption("Required table not found in the routed database/schema. Expected path: CustomerProfileDataStore → CustomerProfile or LoyaltyDataStore → LoyaltyDataStore.")
        st.session_state.selected_tables = [x for x in TABLE_OPTIONS if x in current]
        st.success(f"Selected {len(st.session_state.selected_tables)} table(s).")
        if st.session_state.selected_tables:
            st.write(st.session_state.selected_tables)

elif page == "🔗 Mapping & Keys":
    header("🔗 Mapping & Keys", "Mapping is persistent. Once saved, it is reused after closing/reopening the application until you manually change it.")
    if st.session_state.file_df is None:
        st.warning("Upload CSV files first.")
    elif not st.session_state.selected_tables:
        st.warning("Select one or more target tables first.")
    elif not st.session_state.engines:
        st.warning("Connect to the required PostgreSQL databases first.")
    else:
        for target in st.session_state.selected_tables:
            schema, table = target.split(".", 1)
            st.subheader(target)
            cols, db_pk, idx = metadata(engine_for_target(schema, table), schema, table)
            target_cols = [str(c["name"]) for c in cols]
            existing = mapping_df_for_table(schema, table, list(st.session_state.file_df.columns), target_cols)
            with st.expander(f"Configure {target}", expanded=True):
                if saved_key_config(schema, table):
                    st.success("Saved mapping exists and will not be auto-changed.")
                edited = st.data_editor(
                    existing,
                    use_container_width=True,
                    hide_index=True,
                    key=f"mapping_editor_{target}",
                    column_config={
                        "csv_column": st.column_config.TextColumn("CSV column", disabled=True),
                        "postgres_column": st.column_config.SelectboxColumn("PostgreSQL column", options=[""] + target_cols, required=False),
                    },
                )
                if st.button(f"💾 Save mapping — {target}", key=f"save_map_{target}", type="primary"):
                    pairs = {str(r.csv_column): str(r.postgres_column).strip() for r in edited.itertuples() if str(r.postgres_column).strip()}
                    if len(pairs.values()) != len(set(pairs.values())):
                        st.error("A PostgreSQL column can be mapped only once.")
                    else:
                        all_maps = dict(st.session_state.mappings)
                        old = all_maps.get(target, {})
                        all_maps[target] = {"mapping": pairs, "source_columns": list(st.session_state.file_df.columns), "saved_at": datetime.now(timezone.utc).isoformat(), "source_files_at_save": list(st.session_state.file_names), "source_keys": old.get("source_keys", []), "target_keys": old.get("target_keys", [])}
                        save_mappings(all_maps)
                        st.session_state.mappings = all_maps
                        st.success("Mapping saved permanently for this target table.")
                        st.rerun()
                saved = mapping_df_for_table(schema, table, list(st.session_state.file_df.columns), target_cols)
                valid, msg = mapping_valid(saved, list(st.session_state.file_df.columns), target_cols)
                if valid:
                    opts_s = source_key_options(saved)
                    opts_t = target_key_options(saved, target_cols)
                    conf = saved_key_config(schema, table)
                    old_s = [x for x in conf.get("source_keys", []) if x in opts_s]
                    old_t = [x for x in conf.get("target_keys", []) if x in opts_t]
                    st.markdown("**Primary key selection**")
                    st.caption("Choose the CSV key and the PostgreSQL key independently. They are paired by the order shown below and must be mapped to each other.")
                    c1, c2 = st.columns(2)
                    with c1:
                        source_keys = st.multiselect("CSV primary key", opts_s, default=old_s, key=f"src_keys_{target}")
                    with c2:
                        target_keys = st.multiselect("PostgreSQL primary key", opts_t, default=old_t, key=f"tgt_keys_{target}")
                    if len(source_keys) != len(target_keys):
                        st.warning("Select the same number of key columns on both sides.")
                    else:
                        st.dataframe(pd.DataFrame({"CSV key": source_keys, "PostgreSQL key": target_keys}), use_container_width=True, hide_index=True)
                    if st.button(f"💾 Save mapping + keys — {target}", key=f"save_keys_{target}"):
                        all_maps = dict(st.session_state.mappings)
                        current = all_maps.get(target, {})
                        current.update({"mapping": {str(r.csv_column): str(r.postgres_column).strip() for r in saved.itertuples() if str(r.postgres_column).strip()}, "source_columns": list(st.session_state.file_df.columns), "source_keys": source_keys, "target_keys": target_keys, "saved_at": datetime.now(timezone.utc).isoformat()})
                        all_maps[target] = current
                        save_mappings(all_maps)
                        st.session_state.mappings = all_maps
                        st.success("Mapping and primary keys saved.")
                else:
                    st.warning(msg)

elif page == "⚖️ Compare":
    header("⚖️ CSV ↔ PostgreSQL Comparison", "Cost-efficient key-scoped reconciliation. Only PostgreSQL rows whose primary keys occur in the CSV are fetched.")
    if st.session_state.file_df is None:
        st.warning("Upload CSV files first.")
    elif not st.session_state.selected_tables:
        st.warning("Select target tables first.")
    else:
        st.info("For a table with 4,722,752 PostgreSQL rows, the comparison does NOT read all 4,722,752 rows. It stages the mapped CSV columns and joins only on the selected primary key. This avoids OFFSET/large-table tunnel failures.")
        if st.button("▶ Compare all selected tables", type="primary"):
            results = {}
            progress = st.progress(0, text="Starting…")
            try:
                for i, target in enumerate(st.session_state.selected_tables):
                    schema, table = target.split(".", 1)
                    mapping = mapping_df_for_table(schema, table, list(st.session_state.file_df.columns), table_columns(engine_for_target(schema, table), schema, table))
                    cfg = saved_key_config(schema, table)
                    valid, msg = mapping_valid(mapping, list(st.session_state.file_df.columns), table_columns(engine_for_target(schema, table), schema, table))
                    if not valid: raise ValueError(f"{target}: {msg}")
                    sk, tk = cfg.get("source_keys", []), cfg.get("target_keys", [])
                    if not sk or not tk: raise ValueError(f"{target}: save CSV and PostgreSQL primary keys first.")
                    progress.progress(i / max(len(st.session_state.selected_tables), 1), text=f"Comparing {target}…")
                    results[target] = compare_one_table(schema, table, st.session_state.file_df, mapping, sk, tk)
                st.session_state.comparisons = results
                progress.progress(1.0, text="Comparison complete")
            except Exception as e:
                st.error(safe_error(e))
                progress.empty()
        if st.session_state.comparisons:
            st.subheader("Results")
            summary = []
            for target, r in st.session_state.comparisons.items():
                summary.append({"table": target, "CSV rows": r["source"], "DB rows read by key": r["db_rows_read"], "Matched": r["matched"], "Insert": r["insert"], "Update": r["update"], "Delete": r["delete"]})
            st.dataframe(pd.DataFrame(summary), use_container_width=True, hide_index=True)
            target = st.selectbox("Inspect table", list(st.session_state.comparisons.keys()))
            r = st.session_state.comparisons[target]
            metrics([("CSV", r["source"]), ("DB rows fetched by key", r["db_rows_read"]), ("Matched", r["matched"]), ("Insert", r["insert"]), ("Update", r["update"]), ("Delete", r["delete"])])
            st.caption("Delete count is intentionally 0 during comparison: detecting DB-only rows would require scanning the full target table, which this cost-efficient workflow explicitly avoids. Delete is available manually for key-scoped DB rows in DB Changes.")
            if r["differences"].empty:
                st.success("No mapped value differences found for the selected CSV primary keys.")
            else:
                st.subheader("Values that can be changed in PostgreSQL")
                st.dataframe(r["differences"], use_container_width=True, hide_index=True)
                download_df(r["differences"], "Download differences CSV", f"{target.replace('.', '_')}_differences.csv")
            if not r["insert_rows"].empty:
                st.subheader("CSV rows whose keys are not present in PostgreSQL")
                st.dataframe(r["insert_rows"].head(500), use_container_width=True, hide_index=True)

elif page == "✏️ DB Changes":
    header("✏️ DB Changes", "Explicit insert/update/delete operations using the selected primary keys. Changes are transactional.")
    if not st.session_state.comparisons:
        st.warning("Run a comparison first.")
    else:
        target = st.selectbox("Target table", list(st.session_state.comparisons.keys()), key="change_target")
        r = st.session_state.comparisons[target]
        schema, table = r["schema"], r["table"]
        tab1, tab2, tab3 = st.tabs(["➕ Insert", "✏️ Update", "🗑️ Delete"])
        with tab1:
            rows = r["insert_rows"]
            st.write(f"{len(rows):,} CSV row(s) have keys missing in PostgreSQL.")
            if rows.empty: st.success("Nothing to insert.")
            else:
                view = rows.copy()
                view.insert(0, "_select", False)
                edited = st.data_editor(view.head(5000), use_container_width=True, hide_index=True, key=f"insert_editor_{target}")
                selected = edited.index[edited["_select"] == True].tolist()
                if len(rows) > 5000: st.warning("UI shows the first 5,000 insert candidates. The full CSV remains in memory; narrow the source if you need more than 5,000 simultaneous selections.")
                confirm = st.checkbox("I confirm these CSV rows should be inserted", key=f"insert_confirm_{target}")
                if st.button("➕ Insert selected rows", type="primary", key=f"insert_btn_{target}", disabled=not confirm):
                    try:
                        n = apply_inserts(r, selected)
                        st.success(f"Inserted {n:,} row(s) into {target}.")
                        st.session_state.comparisons = {}
                    except Exception as e: st.error(safe_error(e))
        with tab2:
            d = r["differences"]
            if d.empty: st.success("No updates are required.")
            else:
                st.caption("For an update, the PostgreSQL value is replaced by the corresponding CSV value for that mapped column.")
                keys = sorted(d["key"].astype(str).unique())
                selected = st.multiselect("Select key(s) to update", keys)
                preview = d[d["key"].astype(str).isin(selected)] if selected else d.head(100)
                st.dataframe(preview, use_container_width=True, hide_index=True)
                confirm = st.checkbox("I confirm the selected PostgreSQL values should be changed to the CSV values", key=f"upd_confirm_{target}")
                if st.button("✏️ Apply selected updates", type="primary", key=f"upd_btn_{target}", disabled=not confirm or not selected):
                    try:
                        n = apply_updates(r, selected)
                        st.success(f"Updated {n:,} PostgreSQL row(s) in {target}.")
                        st.session_state.comparisons = {}
                    except Exception as e: st.error(safe_error(e))
        with tab3:
            db = r["matched_db"]
            if db.empty: st.info("No PostgreSQL rows were fetched for the selected CSV keys, so there are no key-scoped delete candidates.")
            else:
                st.warning("Delete is deliberately key-scoped. This list contains only PostgreSQL rows whose selected primary keys were present in the CSV; the application does not scan the full 4.7M-row table.")
                keys = [" | ".join(str(normalize_for_db(row[k])) for k in r["target_keys"]) for _, row in db.iterrows()]
                selected = st.multiselect("Select PostgreSQL key(s) to delete", keys)
                if selected:
                    st.dataframe(db[db.apply(lambda row: " | ".join(str(normalize_for_db(row[k])) for k in r["target_keys"]) in selected, axis=1)], use_container_width=True, hide_index=True)
                confirm = st.checkbox("I understand this permanently deletes the selected PostgreSQL rows", key=f"del_confirm_{target}")
                if st.button("🗑️ Delete selected rows", type="primary", key=f"del_btn_{target}", disabled=not confirm or not selected):
                    try:
                        n = apply_deletes(r, selected)
                        st.success(f"Deleted {n:,} PostgreSQL row(s) from {target}.")
                        st.session_state.comparisons = {}
                    except Exception as e: st.error(safe_error(e))

elif page == "🔌 Connection":
    header("🔌 Connection Status", "The existing local PostgreSQL connection method is retained.")
    cfg = target_config()
    probe = endpoint_status(cfg["host"], cfg["port"])
    metrics([("Endpoint", f"{cfg['host']}:{cfg['port']}"), ("Reachable", "YES" if probe["reachable"] else "NO"), ("Databases", len(st.session_state.engines)), ("User", cfg["username"])])
    if st.session_state.conn:
        st.success(f"Connected to {st.session_state.conn.get('database')} as {st.session_state.conn.get('current_user')} • {st.session_state.conn.get('latency_ms')} ms")
        st.write("Only these dataset tables are used:")
        st.dataframe(pd.DataFrame([{"schema": s, "table": t} for s, ts in ALLOWED_TABLES.items() for t in ts]), use_container_width=True, hide_index=True)
    else:
        st.error(st.session_state.last_connection_error.get("error") if st.session_state.last_connection_error else "Not connected.")
    if st.button("🔄 Refresh connection"):
        for _eng in (st.session_state.get("engines") or {}).values():
            try: _eng.dispose()
            except Exception: pass
        st.session_state.engines = {}
        st.session_state.engine = None
        st.session_state.conn = None
        st.session_state.resolved_tables = {}
        st.rerun()
