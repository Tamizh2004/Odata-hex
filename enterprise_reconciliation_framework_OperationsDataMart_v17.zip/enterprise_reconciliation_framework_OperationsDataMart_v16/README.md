# Enterprise CSV ↔ PostgreSQL Reconciliation — OperationsDataMart Focused Build

This build is intentionally reduced to the required CSV-to-PostgreSQL workflow.

## PostgreSQL scope
Only these tables are accessible:

### CustomerProfile
- LoyaltyProfile
- LoyaltyMember

### LoyaltyDataStore
- LoyaltyCertificate
- LoyaltyCobrandedCard
- LoyaltyPoolMember
- LoyaltyPartnerAccount
- LoyaltyClaim

No other schema/table metadata or data is fetched by the application.

## Workflow
1. Keep the existing AWS SSM/SSH local PostgreSQL tunnel running.
2. Run `setup_and_run.bat`.
3. Upload one or more CSV files. They are combined row-wise.
4. Select one or more allowed PostgreSQL tables with checkboxes.
5. For each selected table, manually map CSV columns to PostgreSQL columns.
6. Select CSV primary-key columns and PostgreSQL primary-key columns independently. They must be mapped to each other.
7. Save mapping + keys. They are persisted in `data/persistent_mappings.json` and are not auto-remapped when the application is restarted. They change only when the user saves a new mapping/key selection.
8. Run comparison.
9. The comparison stages only the mapped CSV columns into a temporary PostgreSQL table and joins using the selected primary key. It does **not** use LIMIT/OFFSET and does not read the whole target table into Streamlit.
10. Review CSV-vs-PostgreSQL values.
11. Use DB Changes for explicit insert/update/delete operations.

## Large-table behavior
For a table such as `CustomerProfile.LoyaltyProfile` with millions of rows, the app does not paginate through the entire PostgreSQL table. It sends the mapped CSV source to a temporary staging table and asks PostgreSQL to return only rows whose selected keys exist in the CSV.

This means the expensive part is scoped to the CSV keys rather than a full-table transfer through the SSM/SSH tunnel.

### Delete behavior
Automatic DB-only delete detection would require scanning the entire target table, which conflicts with the requested cost-efficient key-scoped workflow. Therefore comparison reports `Delete = 0`; the DB Changes page provides explicit key-scoped deletion for rows fetched by the selected CSV keys.

## Connection
The dedicated `.env` PostgreSQL connection method from the previous working build is retained. The UI does not request AWS credentials or database credentials.
