# IFLY_RECON_AUTOMATION_v12

Minimal Streamlit iFly → ODH reconciliation framework.

## Flow
Step 1 iFly → Step 3 ODH → generated Parquet stages → reconciliation → formatted report.

## Comparison logic
The existing reconciliation logic is retained. Records are matched using the selected business key, then compared field-by-field. Blank representations such as None/NaN/NaT/empty/whitespace-only are treated as equal when both sides are blank. Literal `NULL`, `NaN`, and `NaT` strings remain values. Semantic value comparison is used; the separate datatype-comparison output has been removed.

## Downloaded report
The Streamlit download contains exactly two files:

- `iFly_ODH_Reconciliation_Report.xlsx`
- `iFly_ODH_Reconciliation_Report.html`

### Excel sheets
1. **Summary** — metadata, result, and whole-number counts.
2. **Record Results** — complete Step 5 record-level output.
3. **Field Comparison** — field-by-field comparison with the exact columns `attribute_ifly` and `attribute_ODH` plus Status.
4. **Field Summary** — Step 4 field-level statistics.

The workbook is created with a visible `Summary` worksheet first, so Excel never opens with all worksheets hidden.

### HTML report
Report-style HTML with navigation, PASS/FAIL, metadata, whole-number summary cards, field comparison, record results, field summary, and print support.

## Run
Windows: double-click `setup_and_run.bat`.

PowerShell: `./setup_and_run.ps1`

Linux/macOS: `./setup_and_run.sh`
