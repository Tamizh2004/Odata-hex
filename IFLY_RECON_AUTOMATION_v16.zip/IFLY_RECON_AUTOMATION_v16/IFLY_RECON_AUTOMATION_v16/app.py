from pathlib import Path
import tempfile, zipfile
import pandas as pd
import streamlit as st
from reconcile import read_table, clean_columns, choose_default_keys, get_compare_columns, run_reconciliation
from reporting import build_excel, build_html, build_field_comparison

st.set_page_config(page_title="iFly → ODH Reconciliation", page_icon="🔎", layout="centered")
st.title("iFly → ODH Reconciliation")

MAX_UPLOAD_BYTES = 500 * 1024 * 1024

@st.cache_data(show_spinner=False)
def load_uploaded_file(file_bytes: bytes, suffix: str) -> pd.DataFrame:
    import io
    bio = io.BytesIO(file_bytes)
    if suffix.lower() == ".parquet":
        return clean_columns(pd.read_parquet(bio, engine="pyarrow"))
    return clean_columns(pd.read_csv(bio, low_memory=False, keep_default_na=False, na_filter=False))
st.caption("Step 1 iFly → Step 3 ODH → Parquet comparison → Step 4 + Step 5")

step1 = st.file_uploader("Step 1 — iFly", type=["csv", "parquet"])
step3 = st.file_uploader("Step 3 — ODH", type=["csv", "parquet"])

if not step1 or not step3:
    st.info("Upload the Step 1 iFly file and Step 3 ODH file.")
    st.stop()

with tempfile.TemporaryDirectory() as tmp:
    td = Path(tmp)
    p1, p3 = td / step1.name, td / step3.name
    p1.write_bytes(step1.getbuffer()); p3.write_bytes(step3.getbuffer())
    if step1.size > MAX_UPLOAD_BYTES or step3.size > MAX_UPLOAD_BYTES:
        st.error("Each input file must be 500 MB or smaller to protect memory during reconciliation.")
        st.stop()
    if step1.size > 200 * 1024 * 1024 or step3.size > 200 * 1024 * 1024:
        st.warning("Large input detected. Reconciliation may require substantial memory and time.")
    try:
        d1 = load_uploaded_file(step1.getvalue(), Path(step1.name).suffix)
        d3 = load_uploaded_file(step3.getvalue(), Path(step3.name).suffix)
    except Exception as e:
        st.error(f"Unable to read input: {e}"); st.stop()

    common = [c for c in d1.columns if c in d3.columns]
    default = choose_default_keys(common)
    with st.expander("Match key", expanded=False):
        keys = st.multiselect("Select the business key used to identify the same record", common, default=default)
        st.caption("The key must identify exactly one record in each file. The framework will stop rather than create false many-to-many matches.")

    event_type = st.text_input("Event type", value=Path(step1.name).stem.upper())

    if st.button("Run reconciliation", type="primary", use_container_width=True):
        if not keys:
            st.error("Select at least one match-key field."); st.stop()
        try:
            out = td / "output"
            with st.status("Running reconciliation and building reports…", expanded=True) as progress:
                progress.write("Matching records and comparing fields…")
                files, summary, detail, changes = run_reconciliation(p1, p3, out, keys, event_type)
            st.success("Comparison completed.")
            st.dataframe(summary, use_container_width=True, hide_index=True)

            compare_columns = get_compare_columns(d1, d3, keys)
            field_comparison = build_field_comparison(changes, keys, compare_columns)

            excel_path = td / "iFly_ODH_Reconciliation_Report.xlsx"
            html_path = td / "iFly_ODH_Reconciliation_Report.html"
            progress.write("Formatting Excel and HTML validation reports…")
            build_excel(excel_path, summary, detail, changes, field_comparison, keys, step1.name, step3.name, compare_columns)
            build_html(html_path, summary, detail, changes, field_comparison, keys, step1.name, step3.name, d1, d3, compare_columns)

            # Exactly one Excel report and one HTML report in the download ZIP.
            bundle = td / "iFly_ODH_Reconciliation_Report.zip"
            with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as z:
                z.write(excel_path, arcname=excel_path.name)
                z.write(html_path, arcname=html_path.name)
            st.download_button("Download comparison report", bundle.read_bytes(), bundle.name, "application/zip", use_container_width=True)
            st.caption("Download contains one formatted Excel report and one HTML report. Datatype comparison output has been removed.")
        except Exception as e:
            st.error(str(e))
