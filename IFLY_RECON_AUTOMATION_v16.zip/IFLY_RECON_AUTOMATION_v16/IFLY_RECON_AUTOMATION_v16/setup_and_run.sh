#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  PY=""
  for v in python3.14 python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$v" >/dev/null 2>&1; then PY="$v"; break; fi
  done
  [ -n "$PY" ] || { echo "Python 3.10-3.14 is required."; exit 1; }
  "$PY" -m venv .venv
fi
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install --only-binary=:all: --prefer-binary -r requirements.txt
python -m streamlit run app.py
