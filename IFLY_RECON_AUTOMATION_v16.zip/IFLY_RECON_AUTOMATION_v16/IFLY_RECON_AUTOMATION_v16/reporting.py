from __future__ import annotations
from pathlib import Path
from html import escape
import json
import base64
import gzip
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from reconcile import get_compare_columns


def _status(summary):
    r = summary.iloc[0]
    return "PASS" if int(r["UPDATE"]) == 0 and int(r["INSERT"]) == 0 and int(r["DELETE"]) == 0 else "FAIL"


def build_field_comparison(changes: pd.DataFrame, key_columns: list[str], compare_columns: list[str]) -> pd.DataFrame:
    rows = []
    for _, rec in changes.iterrows():
        ctype = rec.get("ChangeType", "")
        keyvals = {k: rec.get(k, "") for k in key_columns}
        mismatch_fields = str(rec.get("MismatchedFields", ""))
        mismatch_set = {x.strip() for x in mismatch_fields.split(",") if x.strip()}
        for c in compare_columns:
            iv = rec.get(c, pd.NA)
            ov = rec.get(f"{c}_ODH", pd.NA)
            if ctype == "MATCH": status = "MATCH"
            elif ctype == "UPDATE": status = "MISMATCH" if c in mismatch_set else "MATCH"
            else: status = ctype
            rows.append({
                "ChangeType": ctype,
                **keyvals,
                "FieldName": c,
                "attribute_ifly": "" if pd.isna(iv) else iv,
                "attribute_ODH": "" if pd.isna(ov) else ov,
                "Status": status,
            })
    return pd.DataFrame(rows)


def build_record_results(changes: pd.DataFrame, key_columns: list[str], compare_columns: list[str]) -> pd.DataFrame:
    """Report every business/key field as paired _Ifly and _ODH columns."""
    rows = []
    all_fields = list(dict.fromkeys([*key_columns, *compare_columns]))
    for _, rec in changes.iterrows():
        row = {"ChangeType": rec.get("ChangeType", "")}
        ctype = rec.get("ChangeType", "")
        for c in all_fields:
            if c in key_columns:
                ifly_value = rec.get(c, pd.NA) if ctype != "DELETE" else pd.NA
                odh_value = rec.get(c, pd.NA) if ctype != "INSERT" else pd.NA
            else:
                ifly_value = rec.get(c, pd.NA)
                odh_value = rec.get(f"{c}_ODH", pd.NA)
            row[f"{c}_Ifly"] = ifly_value
            row[f"{c}_ODH"] = odh_value
        row["MismatchedFields"] = rec.get("MismatchedFields", "")
        rows.append(row)
    return pd.DataFrame(rows)


def _write_df(ws, df: pd.DataFrame, start_row=1, header=True):
    r = start_row
    if header:
        for j, col in enumerate(df.columns, 1):
            ws.cell(r, j, str(col))
        r += 1
    for row in df.itertuples(index=False, name=None):
        for j, value in enumerate(row, 1):
            if pd.isna(value): value = ""
            ws.cell(r, j, value)
        r += 1
    return r


def _apply_table_borders(ws, min_row, max_row, min_col, max_col, color="BFBFBF"):
    """Draw a full thin border (all 4 sides) around every cell in the given range."""
    side = Side(style="thin", color=color)
    full = Border(left=side, right=side, top=side, bottom=side)
    for row in ws.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col):
        for cell in row:
            cell.border = full


def style_sheet(ws, freeze="A2", widths=None, borders=True):
    ws.freeze_panes = freeze
    thin = Side(style="thin", color="BFBFBF")
    full = Border(left=thin, right=thin, top=thin, bottom=thin)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="2F66B3")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        if borders:
            cell.border = full
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if borders:
                cell.border = full
    if widths:
        for col, width in widths.items(): ws.column_dimensions[col].width = width
    else:
        for idx, col in enumerate(ws.columns, 1):
            letter = get_column_letter(idx)
            maxlen = max((len(str(c.value)) if c.value is not None else 0 for c in col[:1000]), default=10)
            ws.column_dimensions[letter].width = min(max(maxlen + 2, 10), 45)


def build_excel(path: str | Path, summary: pd.DataFrame, detail: pd.DataFrame,
                changes: pd.DataFrame, field_comparison: pd.DataFrame,
                key_columns: list[str], step1_name: str, step3_name: str,
                compare_columns: list[str]):
    path = Path(path)
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    r = summary.iloc[0]
    metadata = pd.DataFrame([
        ["Event Type", r.get("EventType", "")],
        ["Step 1 iFly File", step1_name],
        ["Step 3 ODH File", step3_name],
        ["Match Key", " + ".join(key_columns)],
        ["Run Timestamp", r.get("RunTimestamp", "")],
        ["Result", _status(summary)],
    ], columns=["Attribute", "Value"])
    _write_df(ws, metadata)
    start = len(metadata) + 3
    counts = pd.DataFrame([{
        "MATCH": int(r["MATCH"]), "UPDATE": int(r["UPDATE"]),
        "INSERT": int(r["INSERT"]), "DELETE": int(r["DELETE"]),
        "MissingInODH": int(r["MissingInODH"]), "MissingInIFly": int(r["MissingInIFly"]),
        "Step1_iFly_Records": int(r["Step1_iFly_Records"]), "Step3_ODH_Records": int(r["Step3_ODH_Records"]),
        "TotalComparedRecords": int(r["TotalComparedRecords"]), "TotalOutputRecords": int(r["TotalOutputRecords"])
    }])
    for j, c in enumerate(counts.columns, 1): ws.cell(start, j, c)
    for j, c in enumerate(counts.columns, 1): ws.cell(start+1, j, int(counts.iloc[0][c]))
    style_sheet(ws, freeze="A2", borders=False)  # no borders on the blank gap/area
    # borders only around the two real tables
    _apply_table_borders(ws, 1, len(metadata) + 1, 1, len(metadata.columns))
    _apply_table_borders(ws, start, start + 1, 1, len(counts.columns))
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 28; ws.column_dimensions["B"].width = 65

    record_results = build_record_results(changes, key_columns, compare_columns)

    ws2 = wb.create_sheet("Record Results")
    _write_df(ws2, record_results)
    style_sheet(ws2)
    ws2.sheet_view.showGridLines = False

    ws3 = wb.create_sheet("Field Comparison")
    _write_df(ws3, field_comparison)
    style_sheet(ws3)
    ws3.sheet_view.showGridLines = False

    ws4 = wb.create_sheet("Field Summary")
    _write_df(ws4, detail)
    style_sheet(ws4)
    ws4.sheet_view.showGridLines = False

    for wsn in ["Record Results", "Field Comparison"]:
        wsx = wb[wsn]
        headers = {c.value: c.column for c in wsx[1]}
        if "Status" in headers:
            for rr in range(2, wsx.max_row + 1):
                v = wsx.cell(rr, headers["Status"]).value
                if v == "MATCH": wsx.cell(rr, headers["Status"]).fill = PatternFill("solid", fgColor="C6EFCE")
                elif v == "MISMATCH": wsx.cell(rr, headers["Status"]).fill = PatternFill("solid", fgColor="FFC7CE")
        if "ChangeType" in headers:
            for rr in range(2, wsx.max_row + 1):
                v = wsx.cell(rr, headers["ChangeType"]).value
                if v == "MATCH": wsx.cell(rr, headers["ChangeType"]).fill = PatternFill("solid", fgColor="C6EFCE")
                elif v == "UPDATE": wsx.cell(rr, headers["ChangeType"]).fill = PatternFill("solid", fgColor="FFC7CE")
                elif v == "INSERT": wsx.cell(rr, headers["ChangeType"]).fill = PatternFill("solid", fgColor="DDEBFF")
                elif v == "DELETE": wsx.cell(rr, headers["ChangeType"]).fill = PatternFill("solid", fgColor="FFF2CC")
    wb.save(path)


def _html_table(df, max_rows=None):
    x = df.copy()
    if max_rows is not None: x = x.head(max_rows)
    return x.to_html(index=False, classes="report-table", border=0, na_rep="", escape=True)


def _csv_text(df: pd.DataFrame) -> str:
    return df.to_csv(index=False)


def build_html(path: str | Path, summary: pd.DataFrame, detail: pd.DataFrame,
               changes: pd.DataFrame, field_comparison: pd.DataFrame,
               key_columns: list[str], step1_name: str, step3_name: str,
               step1_df: pd.DataFrame, step3_df: pd.DataFrame,
               compare_columns: list[str]):
    """Build the single-file interactive HTML report.

    This function is presentation-only: it consumes reconciliation output without
    recalculating MATCH/UPDATE/INSERT/DELETE decisions.
    """
    path = Path(path)
    r = summary.iloc[0]
    status = _status(summary)
    counts = {k: int(r[k]) for k in [
        "MATCH", "UPDATE", "INSERT", "DELETE", "MissingInODH", "MissingInIFly"
    ]}
    status_color = "#0ea67a" if status == "PASS" else "#ef5350"

    matched = changes[changes["ChangeType"] == "MATCH"].copy()
    updated = changes[changes["ChangeType"] == "UPDATE"].copy()
    inserted = changes[changes["ChangeType"] == "INSERT"].copy()
    deleted = changes[changes["ChangeType"] == "DELETE"].copy()


    meta = [
        ("Event Type", r.get("EventType", "")),
        ("Step 1 iFly", step1_name),
        ("Step 3 ODH", step3_name),
        ("Match Key", " + ".join(key_columns)),
        ("Run Timestamp", r.get("RunTimestamp", "")),
    ]
    meta_html = "".join(
        f"<div class='meta-row'><span>{escape(str(a))}</span><b>{escape(str(b))}</b></div>"
        for a, b in meta
    )

    cards = "".join(
        f"<div class='metric {k.lower()}'><div>{escape(k)}</div><strong>{v}</strong></div>"
        for k, v in counts.items()
    )

    # Comparison views. The existing change classifications are not recalculated here.
    comp_map = [
        ("all", "All", changes, "#3977c9"),
        ("match", "MATCH", matched, "#0ea67a"),
        ("update", "UPDATE / MISMATCH", updated, "#ef5350"),
        ("insert", "INSERT", inserted, "#3977c9"),
        ("delete", "DELETE", deleted, "#e0a000"),
    ]

    # Keep tables usable even with large datasets; all data remains in the HTML,
    # while the table viewport scrolls instead of truncating the report.
    def table_html(df: pd.DataFrame) -> str:
        paired = build_record_results(df, key_columns, compare_columns)
        return _html_table(paired)

    css = r"""
:root{--nav:#17263d;--nav2:#223a5b;--accent:#3977c9;--bg:#f3f6fa;--text:#172033;--muted:#667085;--line:#e5eaf0}
*{box-sizing:border-box}
html,body{margin:0;min-height:100%;font-family:Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--text)}
body{overflow-x:hidden}

/* LEFT NAVIGATION: the hamburger tab belongs to the sidebar itself. */
.sidebar{position:fixed;z-index:100;left:0;top:0;bottom:0;width:280px;background:var(--nav);color:#fff;padding:24px 16px;transition:width .22s ease;overflow:visible;box-shadow:2px 0 12px rgba(0,0,0,.08)}
.sidebar.closed{width:48px;padding-left:0;padding-right:0;box-shadow:2px 0 12px rgba(0,0,0,.08)}
.sidebar .brand,.sidebar .nav{transition:opacity .15s ease;overflow:hidden}
.sidebar.closed .brand,.sidebar.closed .nav{opacity:0;pointer-events:none}
.brand{font-size:19px;font-weight:700;line-height:1.35;padding:7px 60px 24px 12px;white-space:nowrap}
.nav{padding-right:32px}.nav button{display:block;width:100%;border:0;background:transparent;color:#fff;text-align:left;padding:13px 12px;border-radius:8px;margin:4px 0;font-size:14px;cursor:pointer;white-space:nowrap}
.nav button:hover,.nav button.active{background:var(--nav2)}
.input-subnav{margin:0 0 6px 10px;padding-left:8px;border-left:1px solid rgba(255,255,255,.18)}.input-subnav .input-subtab{font-size:13px;padding:9px 10px;margin:2px 0;color:#dfe7f4}.input-subnav .input-subtab.active{background:#2b466d;color:#fff}.input-nav-parent{font-weight:700}
.menu-tab{position:absolute;z-index:101;right:0;top:16px;width:48px;height:48px;border:0;border-radius:8px 0 0 8px;background:#3977c9;color:#fff;font-size:22px;line-height:48px;text-align:center;cursor:pointer;box-shadow:-2px 3px 10px rgba(0,0,0,.14)}

.main{margin-left:280px;padding:32px 38px;transition:margin-left .22s ease;min-height:100vh}
.sidebar.closed~.main{margin-left:48px}
.page{display:none;max-width:1600px;margin:0 auto}.page.active{display:block}
.top{display:flex;justify-content:space-between;align-items:center;gap:15px;margin-bottom:20px}.title{font-size:30px;font-weight:700}.subtitle{color:var(--muted);margin-top:5px}
.status{display:inline-block;padding:9px 20px;border-radius:22px;color:#fff;font-weight:700}

.panel{background:#fff;border-radius:13px;padding:22px;margin:18px 0;box-shadow:0 2px 12px rgba(15,23,42,.06)}
.panel h2{margin:0 0 18px}.meta-row{display:grid;grid-template-columns:230px 1fr;padding:10px 0;border-bottom:1px solid #edf0f4}.meta-row:last-child{border-bottom:0}
.metrics{display:grid;grid-template-columns:repeat(6,minmax(130px,1fr));gap:12px;margin:18px 0}
.metric{background:#fff;border-radius:11px;padding:16px;box-shadow:0 2px 9px rgba(15,23,42,.06);border-top:4px solid var(--accent)}
.metric.match{border-top-color:#0ea67a}.metric.update{border-top-color:#ef5350}.metric.insert{border-top-color:#3977c9}.metric.delete{border-top-color:#e0a000}.metric.missinginodh{border-top-color:#7c5ac7}.metric.missinginifly{border-top-color:#7c5ac7}
.metric div{font-size:12px;color:var(--muted)}.metric strong{display:block;font-size:26px;margin-top:4px}

.report-table{border-collapse:collapse;width:100%;font-size:13px}.table-wrap{overflow:auto;max-height:calc(100vh - 230px);border:1px solid var(--line);border-radius:8px}
.report-table th{background:var(--accent);color:#fff;position:sticky;top:0;padding:9px;text-align:left;white-space:nowrap;z-index:2}
.report-table td{padding:8px;border-bottom:1px solid var(--line);vertical-align:top;white-space:pre-wrap;max-width:500px}.report-table tr:nth-child(even){background:#f8fafc}

.input-tabs{display:flex;gap:8px;margin-bottom:18px}.input-tab{border:1px solid #d4dce8;background:#f7f9fc;color:#26364f;border-radius:9px;padding:10px 16px;font-weight:700;cursor:pointer}.input-tab.active{background:var(--nav);color:#fff;border-color:var(--nav)}.input-panel{display:none}.input-panel.active{display:block}
.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.controls label{font-weight:600}select{padding:10px 12px;border:1px solid #cfd6e0;border-radius:8px;background:#fff;min-width:320px;font-size:14px}
.copy{padding:10px 15px;border:0;border-radius:8px;background:var(--nav);color:#fff;cursor:pointer;font-weight:600}.copy:hover{background:#263d60}
.textbox{width:100%;min-height:480px;font-family:Consolas,monospace;font-size:12px;border:1px solid #d8dee8;border-radius:8px;padding:12px;resize:vertical;background:#fbfcfe;line-height:1.45}

.legend{display:flex;gap:9px;flex-wrap:wrap;margin-bottom:14px}.pill{display:inline-block;padding:7px 13px;border-radius:18px;color:#fff;font-weight:700;font-size:12px}
.p-match{background:#0ea67a}.p-update{background:#ef5350}.p-insert{background:#3977c9}.p-delete{background:#e0a000}
.comparison-filter{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}.comparison-filter button{border:0;border-radius:20px;padding:9px 15px;color:#fff;font-weight:700;cursor:pointer}.comparison-filter button:hover{filter:brightness(.94)}
.comp-panel{display:none}.comp-panel.active{display:block}

.copy-note{color:var(--muted);font-size:13px;margin-top:7px}.empty{padding:35px;text-align:center;color:var(--muted);border:1px dashed #cfd6e0;border-radius:8px;background:#fafbfd}
@media(max-width:1000px){.metrics{grid-template-columns:repeat(3,1fr)}.main{padding:25px 16px}.sidebar{width:250px}.sidebar.closed{width:48px}.sidebar.closed~.main{margin-left:48px}}
@media(max-width:650px){.metrics{grid-template-columns:repeat(2,1fr)}.meta-row{grid-template-columns:1fr;gap:4px}.title{font-size:24px}}
"""

    js = f"""
const sidebar = document.getElementById('sidebar');

function toggleMenu() {{
  sidebar.classList.toggle('closed');
}}

function showPage(id, button) {{
  document.querySelectorAll('.page').forEach(function(page) {{ page.classList.remove('active'); }});
  const target = document.getElementById(id);
  if (target) target.classList.add('active');
  document.querySelectorAll('.nav button').forEach(function(btn) {{ btn.classList.remove('active'); }});
  if (button) button.classList.add('active');
  if (id === 'input') document.querySelector('.input-nav-parent').classList.add('active');
  window.scrollTo({{top:0, behavior:'smooth'}});
}}

function showInputTab(kind, button) {{
  document.querySelectorAll('.input-panel').forEach(function(panel) {{ panel.classList.remove('active'); }});
  const target = document.getElementById('input-' + kind);
  if (target) target.classList.add('active');
  document.querySelectorAll('.input-tab').forEach(function(btn) {{ btn.classList.remove('active'); }});
  document.querySelectorAll('.input-subtab').forEach(function(btn) {{ btn.classList.remove('active'); }});
  if (button) button.classList.add('active');
  const side = document.querySelector('.input-subtab.' + kind);
  if (side) side.classList.add('active');
  const parent = document.querySelector('.input-nav-parent');
  if (parent) parent.classList.add('active');
}}


async function copyText(id) {{
  const el = document.getElementById(id);
  const text = el.value;
  try {{
    if (navigator.clipboard && navigator.clipboard.writeText) {{
      await navigator.clipboard.writeText(text);
      return;
    }}
  }} catch(e) {{}}
  el.focus(); el.select();
  try {{ document.execCommand('copy'); }} catch(e) {{}}
}}

function filterComparison(kind) {{
  document.querySelectorAll('.comp-panel').forEach(function(panel) {{ panel.classList.remove('active'); }});
  const target = document.getElementById('comp-' + kind);
  if (target) target.classList.add('active');
  document.querySelectorAll('.comparison-filter button').forEach(function(btn) {{ btn.classList.remove('selected'); }});
  const btn = document.querySelector('.comparison-filter button[data-kind="' + kind + '"]');
  if (btn) btn.classList.add('selected');
}}

"""

    html = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>iFly → ODH Validation Report</title><style>" + css + "</style></head><body>"

    # Sidebar and hamburger tab are one component. The tab is on the sidebar's right edge.
    html += "<aside id='sidebar' class='sidebar'>"
    html += "<div class='brand'>📊 iFly → ODH<br>Validation Report</div>"
    html += "<nav class='nav'>"
    html += "<button type='button' class='active' onclick=\"showPage('summary',this)\">Summary</button>"
    html += "<button type='button' class='input-nav-parent' onclick=\"showPage('input',this); showInputTab('step1', document.querySelector('.input-subtab.step1'))\">Input CSV/Parquet</button>"
    html += "<div class='input-subnav'>"
    html += "<button type='button' class='input-subtab step1 active' onclick=\"showPage('input',this); showInputTab('step1',this)\">↳ Step 1 — iFly</button>"
    html += "<button type='button' class='input-subtab step3' onclick=\"showPage('input',this); showInputTab('step3',this)\">↳ Step 3 — ODH</button>"
    html += "</div>"
    html += "<button type='button' onclick=\"showPage('comparisons',this)\">Comparisons</button>"
    html += "</nav><button type='button' class='menu-tab' onclick='toggleMenu()' aria-label='Open or close navigation' title='Open / close navigation'>☰</button></aside>"

    html += "<main id='main' class='main'>"

    # Summary page: no print button by request.
    html += (
        f"<section id='summary' class='page active'>"
        f"<div class='top'><div><div class='title'>Validation Report</div><div class='subtitle'>iFly → ODH Reconciliation</div></div>"
        f"<span class='status' style='background:{status_color}'>{escape(status)}</span></div>"
        f"<div class='panel'><h2>Run Metadata</h2>{meta_html}</div>"
        f"<div class='metrics'>{cards}</div>"
        f"<div class='panel'><h2>Overall Result</h2>"
        f"<p><b>{escape(status)}</b> — MATCH: {counts['MATCH']}, UPDATE: {counts['UPDATE']}, INSERT: {counts['INSERT']}, DELETE: {counts['DELETE']}.</p>"
        f"<p class='copy-note'>Missing in ODH: {counts['MissingInODH']} &nbsp; | &nbsp; Missing in iFly: {counts['MissingInIFly']}</p>"
        f"</div></section>"
    )

    # Input page: subtabs keep Step 1 and Step 3 on separate views.
    step1_text = escape(_csv_text(step1_df))
    step3_text = escape(_csv_text(step3_df))
    html += (
        f"<section id='input' class='page'><div class='top'><div><div class='title'>Input CSV/Parquet</div>"
        f"<div class='subtitle'>Select an input subtab to view and copy its data.</div></div></div>"
        f"<div class='panel'><div class='input-tabs'>"
        f"<div id='input-step1' class='input-panel active'><h2>Step 1 — iFly</h2><p><b>{escape(step1_name)}</b></p>"
        f"<textarea id='step1Text' class='textbox' readonly>{step1_text}</textarea><br>"
        f"<button type='button' class='copy' onclick=\"copyText('step1Text')\">Copy Step 1</button></div>"
        f"<div id='input-step3' class='input-panel'><h2>Step 3 — ODH</h2><p><b>{escape(step3_name)}</b></p>"
        f"<textarea id='step3Text' class='textbox' readonly>{step3_text}</textarea><br>"
        f"<button type='button' class='copy' onclick=\"copyText('step3Text')\">Copy Step 3</button></div></div></section>"
    )

    # Comparisons page: status buttons + separate comparison panels.
    html += (
        "<section id='comparisons' class='page'><div class='top'><div><div class='title'>Comparisons</div>"
        "<div class='subtitle'>All comparison classifications generated by the reconciliation engine.</div></div></div>"
        "<div class='panel'><div class='comparison-filter'>"
    )
    for key, label, df, color in comp_map:
        html += f"<button type='button' data-kind='{key}' style='background:{color}' onclick=\"filterComparison('{key}')\">{escape(label)} ({len(df)})</button>"
    html += "</div>"
    for idx, (key, label, df, _) in enumerate(comp_map):
        if len(df):
            body = f"<div class='table-wrap'>{table_html(df)}</div>"
        else:
            body = "<div class='empty'>No records in this category.</div>"
        html += f"<div id='comp-{key}' class='comp-panel {'active' if idx == 0 else ''}'><h2>{escape(label)} <small>({len(df)})</small></h2>{body}</div>"
    html += "</div></section>"

    html += "</main><script>" + js + "</script></body></html>"
    path.write_text(html, encoding="utf-8")