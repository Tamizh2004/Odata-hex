$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = $null
foreach ($v in @('3.14','3.13','3.12','3.11','3.10')) {
    py -$v -c "import sys; print(sys.version)" 2>$null
    if ($LASTEXITCODE -eq 0) { $python = "py -$v"; break }
}
if (-not $python) { throw 'Python 3.10-3.14 is required.' }
if (-not (Test-Path '.venv')) { Invoke-Expression "$python -m venv .venv" }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install --only-binary=:all: --prefer-binary -r requirements.txt
& .\.venv\Scripts\python.exe -m streamlit run app.py
