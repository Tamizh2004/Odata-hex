# Enterprise Streamlit Data Reconciliation & Data Management Framework

## Architecture

External PowerShell/AWS SSM
        |
        v
Local TCP PostgreSQL tunnel
        |
        v
Streamlit auto-discovery
        |
        v
PostgreSQL
        |
        +--> Database Explorer
        +--> Table Browser
        +--> File Upload
        +--> Profiling
        +--> Table Prediction
        +--> Column Mapping
        +--> Reconciliation
        +--> Difference Viewer
        +--> Recommendations
        +--> SQL Generator
        +--> Approval
        +--> Transactional Execution
        +--> Audit
        +--> Reports

The application does NOT request, store, or manage AWS credentials, bastion
IDs, AWS region, or remote RDS endpoint. AWS SSM remains an external concern.

It does NOT assume localhost:13391. It probes configured local ports and
allows you to add any local tunnel port through .env.

## Start

Double-click:

    setup_and_run.bat

After first setup, use the same file every time. VS Code is not required.

## PostgreSQL authentication

The SSM tunnel gives network access, but PostgreSQL authentication is still
required. Put PGUSER/PGPASSWORD/PGDATABASE in a local .env file or enter them
once on Connection Status. Passwords are held only in the current Streamlit
session and are not written by the application.

## Workflow

1. Start external SSM tunnel in PowerShell.
2. Double-click setup_and_run.bat.
3. Connection Status -> Refresh Detection.
4. Select any detected local PostgreSQL endpoint.
5. Connect.
6. Database Explorer -> schema -> table.
7. File Upload -> CSV/Excel/Parquet/JSON.
8. Data Profiling.
9. Auto Table Prediction.
10. Column Mapping.
11. CSV <-> PostgreSQL Comparison.
12. Difference Viewer / AI Recommendations.
13. Query Generator.
14. Approval Center: type APPROVE.
15. Execution Center.
16. Reports / Audit / Rollback.

## Security

Never place AWS access keys, secret keys or session tokens in this project.
If temporary AWS credentials were exposed publicly or to an unintended party,
revoke/rotate them.
