@echo off
setlocal
cd /d "%~dp0"
title Enterprise Data Reconciliation Framework

echo ============================================================
echo   Enterprise Streamlit Data Reconciliation Framework
echo ============================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating Python environment...
    py -3 -m venv .venv
    if errorlevel 1 (
        echo Python 3.10+ is required.
        pause
        exit /b 1
    )
) else (
    echo [1/3] Python environment already exists.
)

echo [2/3] Installing dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo Dependency installation failed.
    pause
    exit /b 1
)

echo [3/3] Starting Streamlit...
echo.
echo Keep your external AWS SSM PowerShell tunnel running.
echo The application will auto-detect reachable local PostgreSQL ports.
echo.
".venv\Scripts\python.exe" -m streamlit run app\app.py
pause
