import pandas as pd
def compare(source,target,keys):
    if not keys: raise ValueError('Select at least one primary/business key.')
    s=source.copy(); t=target.copy(); common=[c for c in s.columns if c in t.columns]; non=[c for c in common if c not in keys]
    if any(k not in s.columns for k in keys) or any(k not in t.columns for k in keys): raise ValueError('Selected key is missing from source or target.')
    for k in keys: s[k]=s[k].astype('string'); t[k]=t[k].astype('string')
    sd=int(s.duplicated(keys,keep=False).sum()); td=int(t.duplicated(keys,keep=False).sum()); sm=s.drop_duplicates(keys,keep=False).set_index(keys); tm=t.drop_duplicates(keys,keep=False).set_index(keys); sk=set(sm.index); tk=set(tm.index); both=sk&tk; changed=[]
    for k in both:
        a=sm.loc[k]; b=tm.loc[k]; dif={}
        for c in non:
            if not(pd.isna(a[c]) and pd.isna(b[c])) and str(a[c])!=str(b[c]): dif[c]={'source':a[c],'target':b[c]}
        if dif: changed.append({'key':str(k),'differences':str(dif)})
    return {'source_rows':len(s),'target_rows':len(t),'matched':len(both),'missing_in_target':len(sk-tk),'missing_in_source':len(tk-sk),'changed_rows':len(changed),'duplicate_source_key_rows':sd,'duplicate_target_key_rows':td,'differences':pd.DataFrame(changed)}
