$env:PGHOST="localhost"
$env:PGPORT="5434"
$env:PGDATABASE="OperationsDataMart"
$env:PGUSER="dbadmin"
$env:PGPASSWORD="YOUR_PASSWORD"
python -m pip install -r requirements.txt
python -m streamlit run app.py
