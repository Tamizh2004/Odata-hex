import io, os
import pandas as pd
import streamlit as st
from db import PG
from prediction import predict
from comparison import compare
from exports import excel_bytes, csv_bytes

st.set_page_config(page_title='Enterprise Data Reconciliation',page_icon='🔄',layout='wide')
st.markdown('<style>.block-container{padding-top:1.2rem}.kpi{border:1px solid #ddd;border-radius:10px;padding:12px}</style>',unsafe_allow_html=True)

if 'db' not in st.session_state: st.session_state.db=None
if 'src' not in st.session_state: st.session_state.src=None
if 'pred' not in st.session_state: st.session_state.pred=None
if 'cmp' not in st.session_state: st.session_state.cmp=None

st.title('🔄 Enterprise Data Reconciliation')
st.caption('PostgreSQL explorer • profiling • target prediction • mapping • reconciliation • exports')

env_host=os.getenv('PGHOST','localhost'); env_port=int(os.getenv('PGPORT','5434')); env_db=os.getenv('PGDATABASE','OperationsDataMart'); env_user=os.getenv('PGUSER','dbadmin'); env_pw=os.getenv('PGPASSWORD','')
with st.sidebar:
    st.header('🔌 PostgreSQL')
    host=st.text_input('Host',env_host); port=st.number_input('Port',1,65535,env_port); database=st.text_input('Database',env_db); user=st.text_input('Username',env_user); password=st.text_input('Password',env_pw,type='password')
    if st.button('Connect / Refresh',type='primary',use_container_width=True):
        x=PG(host,int(port),database,user,password); ok,msg=x.test(); st.session_state.db=x if ok else None
        (st.success if ok else st.error)(msg)
    if st.session_state.db: st.success(f'Connected {host}:{port}/{database}')
    else: st.warning('Not connected')
    page=st.radio('Navigation',['🏠 Dashboard','🔌 Connection Status','🗄️ Database Explorer','📊 Table Data Explorer','🧾 SQL Console','📁 File Upload','🔬 Data Profiling','🎯 Auto Table Prediction','🔗 Column Mapping','⚖️ CSV ↔ PostgreSQL','🔄 CSV → Parquet → PostgreSQL','🔎 Difference Viewer','🤖 AI Recommendations','📝 Query Generator','✅ Approval Center','▶️ Execution Center','↩️ Rollback Center','📜 Audit History','📈 Reports','⚙️ Settings'])

db=st.session_state.db
def need():
    if not db: st.error('Connect to PostgreSQL first.'); return False
    return True

if page=='🏠 Dashboard':
    st.header('Dashboard')
    if db:
        schemas=db.schemas(); tables=sum(len(db.tables(s)) for s in schemas); a,b,c,d=st.columns(4); a.metric('Database',db.database); b.metric('Schemas',len(schemas)); c.metric('Tables / Views',tables); d.metric('Status','ONLINE'); st.dataframe(pd.DataFrame({'schema':schemas}),use_container_width=True,hide_index=True)
    else: st.info('Default target: localhost:5434 / OperationsDataMart / dbadmin. Password is not bundled in the ZIP.')

elif page=='🔌 Connection Status':
    st.header('Connection Status')
    if need():
        ok,msg=db.test(); (st.success if ok else st.error)(msg)
        if ok: st.json({'host':db.host,'port':db.port,'database':db.database,'user':db.user,'status':'connected'}); st.write(db.version())

elif page=='🗄️ Database Explorer':
    st.header('Database Explorer')
    if need():
        ss=db.schemas(); s=st.selectbox('Schema',ss); ts=db.tables(s); q=st.text_input('🔎 Search tables / views'); ts=[t for t in ts if not q or q.lower() in t.lower()]; st.write(f'{len(ts)} matching objects')
        if ts:
            t=st.selectbox('Table / View',ts); st.dataframe(db.meta(s,t),use_container_width=True,hide_index=True)
            if st.button('Open Table Data',type='primary'): st.session_state.table=(s,t); st.rerun()

elif page=='📊 Table Data Explorer':
    st.header('Table Data Explorer')
    if need():
        ss=db.schemas(); s=st.selectbox('Schema',ss); ts=db.tables(s); t=st.selectbox('Table / View',ts); total=db.count(s,t); m=db.meta(s,t); a,b,c,d=st.columns(4); a.metric('Rows',f'{total:,}'); b.metric('Columns',len(m)); c.metric('Primary Keys',int(m.is_primary_key.sum())); d.metric('Indexes',db.indexes(s,t)); size=st.selectbox('Rows per page',[25,50,100,250,500],index=1); pg=st.number_input('Page',1,max(1,(total+size-1)//size),1); df=db.fetch(s,t,int(size),(pg-1)*int(size)); st.dataframe(df,use_container_width=True,height=520); x,y=st.columns(2); x.download_button('Export CSV',csv_bytes(df),'table_page.csv','text/csv',use_container_width=True); y.download_button('Export Excel',excel_bytes(df),'table_page.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',use_container_width=True)

elif page=='🧾 SQL Console':
    st.header('SQL Console (read-only)')
    if need():
        q=st.text_area('SQL',height=200,placeholder='SELECT * FROM public.my_table LIMIT 100;')
        if st.button('Run SQL',type='primary'):
            try: df=db.query(q); st.dataframe(df,use_container_width=True); st.download_button('Export CSV',csv_bytes(df),'sql_result.csv','text/csv')
            except Exception as e: st.error(str(e))

elif page=='📁 File Upload':
    st.header('File Upload'); f=st.file_uploader('CSV / Excel / Parquet',type=['csv','xlsx','xls','parquet'])
    if f:
        try:
            df=pd.read_csv(f) if f.name.lower().endswith('.csv') else pd.read_parquet(f) if f.name.lower().endswith('.parquet') else pd.read_excel(f); st.session_state.src=df; st.success(f'Loaded {len(df):,} rows × {len(df.columns)} columns'); st.dataframe(df.head(100),use_container_width=True)
        except Exception as e: st.error(str(e))

elif page=='🔬 Data Profiling':
    st.header('Data Profiling'); df=st.session_state.src
    if df is None: st.info('Upload a source file first.')
    else: st.dataframe(pd.DataFrame({'column':df.columns,'dtype':[str(df[c].dtype) for c in df.columns],'nulls':[int(df[c].isna().sum()) for c in df.columns],'null_%':[round(df[c].isna().mean()*100,2) for c in df.columns],'unique':[int(df[c].nunique()) for c in df.columns]}),use_container_width=True,hide_index=True)

elif page=='🎯 Auto Table Prediction':
    st.header('Auto Table Prediction'); df=st.session_state.src
    if not need(): pass
    elif df is None: st.info('Upload a source file first.')
    else:
        s=st.selectbox('Target schema',db.schemas())
        if st.button('🎯 Predict Target Table',type='primary'): st.session_state.pred=predict(db,s,df)
        if st.session_state.pred is not None:
            r=st.session_state.pred; st.dataframe(r,use_container_width=True,hide_index=True)
            if len(r): st.success(f"Suggested: {r.iloc[0]['table']} • {r.iloc[0]['confidence']:.1f}% confidence")

elif page=='🔗 Column Mapping':
    st.header('Column Mapping'); df=st.session_state.src
    if not need(): pass
    elif df is None: st.info('Upload a source file first.')
    else:
        s=st.selectbox('Schema',db.schemas()); t=st.selectbox('Target table',db.tables(s)); tc=db.columns(s,t); rows=[]
        for c in df.columns: rows.append({'source_column':c,'target_column':next((x for x in tc if x.lower()==c.lower()),'')})
        st.data_editor(pd.DataFrame(rows),use_container_width=True,hide_index=True,disabled=['source_column'])

elif page=='⚖️ CSV ↔ PostgreSQL':
    st.header('CSV ↔ PostgreSQL Comparison'); df=st.session_state.src
    if not need(): pass
    elif df is None: st.info('Upload a source file first.')
    else:
        s=st.selectbox('Schema',db.schemas()); t=st.selectbox('Target table',db.tables(s)); tc=db.columns(s,t); common=[c for c in df.columns if c.lower() in {x.lower() for x in tc}]; keys=st.multiselect('Primary / business keys',common,default=common[:1]); limit=st.number_input('Maximum target rows',1000,1000000,250000,1000)
        if st.button('⚖️ Run Comparison',type='primary'):
            try: st.session_state.cmp=compare(df,db.fetch(s,t,int(limit)),keys)
            except Exception as e: st.error(str(e))
        r=st.session_state.cmp
        if r:
            a,b,c,d,e,f=st.columns(6); a.metric('Source',r['source_rows']); b.metric('Target',r['target_rows']); c.metric('Matched',r['matched']); d.metric('Missing target',r['missing_in_target']); e.metric('Missing source',r['missing_in_source']); f.metric('Changed',r['changed_rows']); st.dataframe(r['differences'],use_container_width=True)

elif page=='🔄 CSV → Parquet → PostgreSQL':
    st.header('CSV → Parquet → PostgreSQL'); df=st.session_state.src
    if df is None: st.info('Upload a source file first.')
    elif st.button('🔄 Validate Pipeline',type='primary'):
        b=io.BytesIO(); df.to_parquet(b,index=False); out=pd.read_parquet(io.BytesIO(b.getvalue())); rep=pd.DataFrame({'check':['row_count','column_count','null_count','column_order'],'source':[len(df),len(df.columns),int(df.isna().sum().sum()),list(df.columns)],'parquet':[len(out),len(out.columns),int(out.isna().sum().sum()),list(out.columns)]}); rep['status']=['PASS' if rep.iloc[i,1]==rep.iloc[i,2] else 'FAIL' for i in range(4)]; st.dataframe(rep,use_container_width=True)

elif page=='🔎 Difference Viewer':
    st.header('Difference Viewer'); r=st.session_state.cmp
    if not r: st.info('Run a comparison first.')
    else: st.dataframe(r['differences'],use_container_width=True); st.download_button('Export differences',excel_bytes(r['differences']),'differences.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

elif page=='🤖 AI Recommendations':
    st.header('AI Recommendations'); df=st.session_state.src
    if df is None: st.info('Upload source data first.')
    else:
        rec=[]
        for c in df.columns:
            p=df[c].isna().mean()*100
            if p>20: rec.append(f'`{c}` has {p:.1f}% nulls; review completeness.')
            if len(df)>10 and df[c].nunique(dropna=True)==len(df): rec.append(f'`{c}` is unique across the source and may be a business-key candidate.')
        if rec:
            for x in rec: st.write('•',x)
        else: st.success('No basic data-quality recommendations triggered.')

elif page=='📝 Query Generator':
    st.header('Query Generator')
    if need():
        s=st.selectbox('Schema',db.schemas()); t=st.selectbox('Table',db.tables(s)); cols=db.columns(s,t); chosen=st.multiselect('Columns',cols,default=cols[:10]); lim=st.number_input('LIMIT',1,100000,100); where=st.text_input('Optional WHERE clause'); q='SELECT '+(', '.join('"'+x.replace('"','""')+'"' for x in chosen) if chosen else '*')+f' FROM "{s.replace(chr(34),chr(34)*2)}"."{t.replace(chr(34),chr(34)*2)}"'+((' WHERE '+where) if where.strip() else '')+f' LIMIT {int(lim)};'; st.code(q,language='sql')

elif page=='✅ Approval Center': st.header('Approval Center'); st.info('Read-only safety build. Production write actions are not enabled.')
elif page=='▶️ Execution Center': st.header('Execution Center'); st.warning('Write operations are disabled in this build.'); st.code('READ-ONLY MODE')
elif page=='↩️ Rollback Center': st.header('Rollback Center'); st.info('No write operations are executed by this build.')
elif page=='📜 Audit History': st.header('Audit History'); st.info('Session-only audit placeholder; no database credentials are logged.')
elif page=='📈 Reports':
    st.header('Reports'); r=st.session_state.cmp
    if r:
        x=pd.DataFrame([{k:r[k] for k in ['source_rows','target_rows','matched','missing_in_target','missing_in_source','changed_rows']}]); st.dataframe(x,use_container_width=True); st.download_button('Download report',excel_bytes(x),'reconciliation_report.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    else: st.info('Run a comparison first.')
elif page=='⚙️ Settings':
    st.header('Settings'); st.code('PGHOST=localhost\nPGPORT=5434\nPGDATABASE=OperationsDataMart\nPGUSER=dbadmin\nPGPASSWORD=YOUR_PASSWORD'); st.warning('Do not commit real database passwords to GitHub.')
