import re,pandas as pd
def n(x): return re.sub(r'[^a-z0-9]','',str(x).lower())
def predict(db,schema,df):
    src={n(x) for x in df.columns}; rows=[]
    for t in db.tables(schema):
        m=db.meta(schema,t); tc=list(m.column_name); tar={n(x) for x in tc}; match=src&tar; pk=set(n(x) for x in m.loc[m.is_primary_key.fillna(False),'column_name']); hits=len(src&pk); overlap=len(match)/max(len(src),1); coverage=len(match)/max(len(tar),1); score=.60*overlap+.25*coverage+.15*min(hits,1)
        rows.append({'table':t,'confidence':round(score*100,1),'matching_columns':len(match),'matched_columns':', '.join(sorted(match)[:20]),'primary_key_columns':len(pk),'source_pk_hits':hits})
    return pd.DataFrame(rows).sort_values(['confidence','matching_columns','primary_key_columns'],ascending=False).reset_index(drop=True) if rows else pd.DataFrame()
