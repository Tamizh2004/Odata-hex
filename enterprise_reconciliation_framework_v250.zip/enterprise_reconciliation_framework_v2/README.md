# Enterprise Reconciliation Framework v2

Built to address the screenshot issues:
- real PostgreSQL authentication against OperationsDataMart
- real schema/table/view discovery
- paginated table data
- read-only SQL console
- deterministic target-table prediction with non-zero confidence when metadata matches
- CSV/Excel/Parquet upload and profiling
- CSV ↔ PostgreSQL comparison with multiple keys
- CSV → Parquet validation
- timezone-safe Excel export (fixes the shown pandas Excel ValueError)
- no hard-coded database password

Default target: localhost:5434 / OperationsDataMart / dbadmin.

## Windows
```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:PGHOST="localhost"
$env:PGPORT="5434"
$env:PGDATABASE="OperationsDataMart"
$env:PGUSER="dbadmin"
$env:PGPASSWORD="YOUR_PASSWORD"
.\.venv\Scripts\python.exe -m streamlit run app.py
```

If your SSH tunnel exposes the database on another local port (for example 13391), change only PGPORT.

The application checks `SELECT current_database(), current_user` before reporting Connected, so a reachable port alone is never treated as a successful authentication.

The database write/execute screens are intentionally read-only in this build.
