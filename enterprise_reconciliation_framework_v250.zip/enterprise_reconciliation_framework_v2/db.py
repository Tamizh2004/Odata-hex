import os
import pandas as pd
import psycopg2
from psycopg2 import sql

class PG:
    def __init__(self,host,port,database,user,password): self.host,self.port,self.database,self.user,self.password=host,port,database,user,password
    def conn(self): return psycopg2.connect(host=self.host,port=self.port,dbname=self.database,user=self.user,password=self.password,connect_timeout=5,application_name='EnterpriseReconciliationFramework')
    def test(self):
        try:
            with self.conn() as c:
                with c.cursor() as cur: cur.execute('select current_database(), current_user'); cur.fetchone()
            return True,'PostgreSQL authentication successful.'
        except Exception as e: return False,str(e)
    def version(self):
        with self.conn() as c:
            with c.cursor() as cur: cur.execute('select version()'); return cur.fetchone()[0]
    def schemas(self):
        q="""select schema_name from information_schema.schemata where schema_name not in ('pg_catalog','information_schema') and schema_name not like 'pg_toast%' order by schema_name"""
        with self.conn() as c: return pd.read_sql_query(q,c).schema_name.tolist()
    def tables(self,s):
        q="""select table_name from information_schema.tables where table_schema=%s union all select table_name from information_schema.views where table_schema=%s order by table_name"""
        with self.conn() as c: return pd.read_sql_query(q,c,params=[s,s]).table_name.tolist()
    def columns(self,s,t):
        q="select column_name from information_schema.columns where table_schema=%s and table_name=%s order by ordinal_position"
        with self.conn() as c: return pd.read_sql_query(q,c,params=[s,t]).column_name.tolist()
    def meta(self,s,t):
        q="""select c.column_name,c.data_type,c.udt_name,c.is_nullable,c.ordinal_position,case when tc.constraint_type='PRIMARY KEY' then true else false end is_primary_key from information_schema.columns c left join information_schema.key_column_usage kcu on kcu.table_schema=c.table_schema and kcu.table_name=c.table_name and kcu.column_name=c.column_name left join information_schema.table_constraints tc on tc.constraint_schema=kcu.constraint_schema and tc.constraint_name=kcu.constraint_name and tc.table_name=kcu.table_name and tc.constraint_type='PRIMARY KEY' where c.table_schema=%s and c.table_name=%s order by c.ordinal_position"""
        with self.conn() as c: return pd.read_sql_query(q,c,params=[s,t])
    def count(self,s,t):
        q=sql.SQL('select count(*) from {}.{}').format(sql.Identifier(s),sql.Identifier(t))
        with self.conn() as c:
            with c.cursor() as cur: cur.execute(q); return int(cur.fetchone()[0])
    def indexes(self,s,t):
        with self.conn() as c:
            with c.cursor() as cur: cur.execute('select count(*) from pg_indexes where schemaname=%s and tablename=%s',[s,t]); return int(cur.fetchone()[0])
    def fetch(self,s,t,limit=100,offset=0):
        q=sql.SQL('select * from {}.{} limit %s offset %s').format(sql.Identifier(s),sql.Identifier(t))
        with self.conn() as c: return pd.read_sql_query(q.as_string(c),c,params=[int(limit),int(offset)])
    def query(self,q):
        if not q.strip().lower().startswith(('select','with','show','explain')): raise ValueError('SQL Console is read-only. Use SELECT/WITH/SHOW/EXPLAIN.')
        with self.conn() as c: return pd.read_sql_query(q,c)
