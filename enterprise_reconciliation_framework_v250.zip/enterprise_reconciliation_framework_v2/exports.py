import io,pandas as pd
def safe(df):
    x=df.copy()
    for c in x.columns:
        if pd.api.types.is_datetime64tz_dtype(x[c]): x[c]=x[c].dt.tz_localize(None)
        elif x[c].dtype=='object': x[c]=x[c].map(lambda v:v.tz_localize(None) if isinstance(v,pd.Timestamp) and v.tzinfo else v)
    return x
def excel_bytes(df):
    b=io.BytesIO();
    with pd.ExcelWriter(b,engine='openpyxl') as w: safe(df).to_excel(w,index=False,sheet_name='Data')
    return b.getvalue()
def csv_bytes(df): return df.to_csv(index=False).encode('utf-8-sig')
