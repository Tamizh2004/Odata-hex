@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ========================================
echo   iFly - ODH Reconciliation Automation
echo ========================================
echo.
where py >nul 2>nul || (echo ERROR: Python Launcher is not installed.& pause& exit /b 1)
if not exist .venv (
  echo Creating virtual environment...
  py -3.14 -m venv .venv 2>nul || py -3.13 -m venv .venv 2>nul || py -3.12 -m venv .venv 2>nul || py -3.11 -m venv .venv 2>nul || py -3.10 -m venv .venv 2>nul || (echo ERROR: Python 3.10-3.14 is required.& pause& exit /b 1)
)
call .venv\Scripts\activate.bat || (echo ERROR: Could not activate virtual environment.& pause& exit /b 1)
python -m pip install --upgrade pip || goto INSTALL_ERROR
python -m pip install --only-binary=:all: --prefer-binary -r requirements.txt || goto INSTALL_ERROR
echo.
echo Starting Streamlit at http://localhost:8501 ...
python -m streamlit run app.py
exit /b %errorlevel%
:INSTALL_ERROR
echo.
echo Dependency installation failed. Check internet access and Python version.
pause
exit /b 1
