$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.venv')) { py -3.14 -m venv .venv 2>$null; if ($LASTEXITCODE -ne 0) { py -3.13 -m venv .venv } }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install --only-binary=:all: --prefer-binary -r requirements.txt
& .\.venv\Scripts\python.exe -m streamlit run app.py
