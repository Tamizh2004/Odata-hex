# IFLY_RECON_AUTOMATION v5

Minimal Streamlit automation for:

**Step 1 iFly → Step 3 ODH → Step 1/Step 3 Parquet → logical comparison → Step 4 + Step 5**

## Comparison rules
- Same business key = same record.
- Default key preference: `membershipNumber + referenceNumber + ticketNumber` when available.
- Blank values are equal only when both sides are blank. Blank means null/NaN/None, empty string, or whitespace-only string.
- Literal `NULL` is a real value and is NOT blank.
- Real strings are strict: spaces inside/around a real value remain significant.
- Common record with all fields equal = `MATCH`.
- Common record with one or more different fields = `UPDATE`.
- Exists in iFly but not ODH = `MissingInODH` and `INSERT` (record needs to be added to ODH).
- Exists in ODH but not iFly = `MissingInIFly` and `DELETE` (record needs to be removed from ODH).
- Duplicate business keys stop the run instead of silently pairing unrelated rows.

## Outputs
- `step1_ifly.parquet`
- `step3_odh.parquet`
- `step4_recon_stats_summary.csv`
- `step4_recon_detailed_results.csv`
- `step5_match_and_missed_odh_report.csv`

No `step5_odh_changes_only.csv` is produced.

All record counts are whole numbers. No decimal/percentage values are used for MATCH/UPDATE/INSERT/DELETE counts.

## Run
Windows: `setup_and_run.bat`
PowerShell: `setup_and_run.ps1`
Linux/macOS: `setup_and_run.sh`


### Blank-value reconciliation rule

During field comparison, all genuine missing/blank representations are considered the same when both sides are blank: `None`, `pd.NA`, `NaN`, `NaT`, empty string, and whitespace-only string. Literal strings such as `NULL`, `NaN`, and `NaT` remain actual values and are not treated as blank. Real values are compared without trimming or normalization.
